local L0_0, L1_1
function L0_0(A0_2)
  Message_WindowOpen(A0_2)
  Wait_MessageWindow()
end
Message_WindowOpenEx = L0_0
function L0_0()
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
Message_WindowCloseEx = L0_0
