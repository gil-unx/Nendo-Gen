cool_type = {
  0,
  2,
  7,
  12,
  5,
  -1
}
motion_set = {
  {
    0,
    255,
    255,
    0,
    0
  },
  {
    8,
    255,
    255,
    0,
    0
  },
  {
    16777329,
    255,
    255,
    0,
    0
  },
  {
    16777401,
    9,
    0,
    0,
    0
  },
  {
    16777404,
    1,
    0,
    2,
    2
  },
  {
    16777405,
    255,
    255,
    0,
    0
  },
  {
    16777406,
    255,
    255,
    0,
    0
  },
  {
    16777407,
    255,
    255,
    0,
    0
  },
  {
    16777408,
    3,
    3,
    2,
    2
  },
  {
    16777409,
    255,
    255,
    0,
    0
  },
  {
    16777410,
    9,
    6,
    2,
    2
  },
  {
    16777411,
    255,
    255,
    0,
    0
  },
  {
    16777414,
    255,
    255,
    2,
    2
  },
  {
    16777412,
    255,
    255,
    2,
    2
  },
  {
    16777415,
    255,
    255,
    2,
    2
  },
  {
    16777413,
    255,
    255,
    2,
    2
  },
  {
    16777399,
    255,
    255,
    0,
    0
  },
  {
    16777402,
    255,
    255,
    2,
    2
  },
  {
    16777403,
    255,
    255,
    0,
    0
  },
  {
    16777418,
    0,
    1,
    2,
    0
  },
  {
    16777419,
    255,
    255,
    0,
    0
  },
  {
    16777420,
    0,
    1,
    2,
    2
  },
  {
    16777314,
    0,
    0,
    2,
    2
  },
  {
    16777315,
    2,
    0,
    2,
    2
  },
  {
    16777423,
    2,
    3,
    0,
    0
  },
  {
    16777424,
    255,
    255,
    0,
    0
  },
  {
    16777427,
    2,
    2,
    0,
    0
  },
  {
    16777428,
    255,
    255,
    0,
    0
  },
  {
    16777429,
    2,
    2,
    2,
    2
  },
  {
    16777430,
    255,
    255,
    0,
    0
  },
  {
    16777431,
    255,
    255,
    0,
    0
  },
  {
    16777432,
    255,
    255,
    0,
    0
  },
  {
    16777433,
    2,
    4,
    2,
    2
  },
  {
    -1,
    -1,
    -1,
    -1,
    -1
  }
}
motion_cool_set = {
  {
    0,
    255,
    255,
    0,
    0
  },
  {
    8,
    255,
    255,
    0,
    0
  },
  {
    16777329,
    255,
    255,
    0,
    0
  },
  {
    16777401,
    255,
    255,
    0,
    0
  },
  {
    16777404,
    255,
    255,
    2,
    2
  },
  {
    16777405,
    255,
    255,
    0,
    0
  },
  {
    16777406,
    255,
    255,
    0,
    0
  },
  {
    16777407,
    255,
    255,
    0,
    0
  },
  {
    16777408,
    1,
    0,
    2,
    2
  },
  {
    16777409,
    255,
    255,
    0,
    0
  },
  {
    16777410,
    1,
    0,
    2,
    2
  },
  {
    16777411,
    255,
    255,
    0,
    0
  },
  {
    16777414,
    255,
    255,
    2,
    2
  },
  {
    16777412,
    255,
    255,
    2,
    2
  },
  {
    16777415,
    255,
    255,
    2,
    2
  },
  {
    16777413,
    255,
    255,
    2,
    2
  },
  {
    16777399,
    255,
    255,
    0,
    0
  },
  {
    16777402,
    255,
    255,
    2,
    2
  },
  {
    16777403,
    255,
    255,
    0,
    0
  },
  {
    16777418,
    0,
    1,
    2,
    0
  },
  {
    16777419,
    255,
    255,
    0,
    0
  },
  {
    16777420,
    0,
    1,
    2,
    2
  },
  {
    16777314,
    0,
    0,
    2,
    2
  },
  {
    16777315,
    2,
    0,
    2,
    2
  },
  {
    16777423,
    2,
    3,
    0,
    0
  },
  {
    16777424,
    255,
    255,
    0,
    0
  },
  {
    16777427,
    2,
    2,
    0,
    0
  },
  {
    16777428,
    255,
    255,
    0,
    0
  },
  {
    16777429,
    2,
    2,
    2,
    2
  },
  {
    16777430,
    255,
    255,
    0,
    0
  },
  {
    16777431,
    255,
    255,
    0,
    0
  },
  {
    16777432,
    255,
    255,
    0,
    0
  },
  {
    16777433,
    2,
    4,
    2,
    2
  },
  {
    -1,
    -1,
    -1,
    -1,
    -1
  }
}
char_set = {
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      10,
      0,
      1,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      12,
      2,
      4,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      14,
      9,
      6,
      2,
      2
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      9,
      8,
      3,
      2,
      2
    }
  },
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      16,
      2,
      1,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      18,
      2,
      4,
      0,
      3
    }
  },
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      20,
      2,
      2,
      0,
      0
    }
  },
  {
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      22,
      2,
      0,
      0,
      0
    }
  }
}
char_reset = {
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      11,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      13,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      15,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      0,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      17,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      19,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      21,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      23,
      255,
      255,
      0,
      0
    }
  }
}
function fc_TreasureFunc(A0_0)
  local L1_1, L2_2
  L1_1 = DPRINT
  L2_2 = "fc_TreasureFunc()"
  L1_1(L2_2)
  L1_1 = AddTreasure
  L2_2 = A0_0
  L1_1 = L1_1(L2_2)
  L2_2 = A0_0
  Model_SetMotion(L2_2, 1, 0, false)
  Wait_ModelMotion(L2_2)
  Message_WindowOpen(1)
  Wait_MessageWindow()
  if L1_1 == true then
    PlaySE(16777222)
    SetMes("TRE_000", "[COL SYS_NAM][STR TREASURE_NAME][COL SYS_DEF]\227\130\146\230\137\139\227\129\171\229\133\165\227\130\140\227\129\190\227\129\151\227\129\159\227\128\130\n")
  else
    SetMes("TRE_001", "[COL SYS_NAM][STR TREASURE_NAME][COL SYS_DEF]\227\130\146\232\166\139\227\129\164\227\129\145\227\129\190\227\129\151\227\129\159\227\128\130\n\226\128\166\227\129\151\227\129\139\227\129\151\227\128\129\227\129\147\227\129\174\227\130\162\227\130\164\227\131\134\227\131\160\227\129\175\227\130\130\227\129\134\230\140\129\227\129\161\229\136\135\227\130\140\227\129\190\227\129\155\227\130\147\227\128\130")
  end
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if L1_1 == false then
    Model_SetMotion(L2_2, 0, 1, false)
    Wait_ModelMotion(L2_2)
  end
end
function fc_ExitFunc()
  Message_WindowOpen(1)
  Wait_MessageWindow()
  SetMes("EXT_000", "\227\131\158\227\131\131\227\131\151\227\129\174\229\164\150\227\129\171\229\135\186\227\129\190\227\129\153\227\129\140\227\130\136\227\130\141\227\129\151\227\129\132\227\129\167\227\129\153\227\129\139\239\188\159")
  Message_SetBranch("\227\129\175\227\129\132", "\227\129\132\227\129\132\227\129\136", 1)
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if Message_GetBranchResult() == 0 then
    OffSystemFlag(0)
    OffSystemFlag(2)
    OffSystemFlag(1)
    OffSystemFlag(1)
    Map_ExitToIntermission()
  elseif Message_GetBranchResult() == 1 then
  end
end
function fc_EscapeDungeonFunc()
  local L0_3, L1_4, L2_5, L3_6, L4_7, L5_8, L6_9, L7_10, L8_11, L9_12, L10_13, L11_14, L12_15, L13_16, L14_17, L15_18, L16_19
  L0_3 = {
    L1_4,
    L2_5,
    L3_6,
    L4_7,
    L5_8,
    L6_9,
    L7_10,
    L8_11
  }
  L1_4 = -90
  L2_5 = -45
  L3_6 = 0
  L4_7 = 45
  L5_8 = 90
  L6_9 = 135
  L1_4 = {
    L2_5,
    L3_6,
    L4_7,
    L5_8,
    L6_9,
    L7_10
  }
  L2_5 = -90
  L3_6 = -30
  L4_7 = 30
  L5_8 = 90
  L6_9 = 150
  L2_5 = {
    L3_6,
    L4_7,
    L5_8,
    L6_9
  }
  L3_6 = -90
  L4_7 = 0
  L5_8 = 90
  L6_9 = 180
  L3_6 = 10
  L4_7 = 0
  L5_8 = 0
  L6_9 = 0
  for L10_13 = 4, L3_6 - 1 do
    if L10_13 == 4 then
      L14_17 = 1
      L11_14(L12_15, L13_16, L14_17)
      L11_14(L12_15)
      L14_17 = Particle_SetPosition
      L15_18 = 20
      L16_19 = L11_14
      L14_17(L15_18, L16_19, L12_15, L13_16)
    end
    if L10_13 < 2 then
      for L14_17 = 0, 3 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L2_5[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L0_3[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = 0.1 * L10_13
        L16_19 = 0.3 - L16_19
        L15_18(L16_19)
      end
    elseif L10_13 < 4 then
      for L14_17 = 0, 5 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = L10_13 - 2
        L16_19 = 0.05 * L16_19
        L16_19 = 0.1 - L16_19
        L15_18(L16_19)
      end
    elseif L10_13 < 8 then
      for L14_17 = 0, 7 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L0_3[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L0_3[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = L10_13 - 8
        L16_19 = 0.0025 * L16_19
        L16_19 = 0.01 - L16_19
        L15_18(L16_19)
      end
    else
      for L14_17 = 0, 5 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = 0.01
        L15_18(L16_19)
      end
    end
    L5_8 = L11_14 + L12_15
    L14_17 = L6_9
    L11_14(L12_15, L13_16, L14_17)
  end
  L7_10(L8_11)
  L10_13 = 1
  L7_10(L8_11, L9_12, L10_13, L11_14)
  L7_10()
  L7_10(L8_11)
  L7_10(L8_11)
  L10_13 = 0
  L7_10(L8_11, L9_12, L10_13)
  L7_10(L8_11)
  L7_10()
  L7_10(L8_11)
end
function fc_Map_SetRoomChangeEventNPC(A0_20, A1_21, A2_22, A3_23, A4_24, A5_25, A6_26, A7_27, A8_28)
  local L9_29, L10_30, L11_31, L12_32, L13_33, L14_34
  L9_29 = Npc_GetPosition
  L10_30 = A1_21
  L11_31 = L9_29(L10_30)
  L12_32 = Map_SetRoomChangeEventCircle
  L13_33 = A0_20
  L14_34 = L9_29
  L12_32(L13_33, L14_34, L11_31, A2_22, A3_23, A4_24, A5_25, A6_26, A7_27)
  L12_32 = Map_EventCollSetSE
  L13_33 = A0_20
  L14_34 = A8_28
  L12_32(L13_33, L14_34)
end
function fc_Map_SetRoomChangeEventMDL(A0_35, A1_36, A2_37, A3_38, A4_39, A5_40, A6_41, A7_42, A8_43)
  local L9_44, L10_45, L11_46, L12_47, L13_48, L14_49
  L9_44 = Model_GetPosition
  L10_45 = A1_36
  L11_46 = L9_44(L10_45)
  L12_47 = Map_SetRoomChangeEventCircle
  L13_48 = A0_35
  L14_49 = L9_44
  L12_47(L13_48, L14_49, L11_46, A2_37, A3_38, A4_39, A5_40, A6_41, A7_42)
  L12_47 = Map_EventCollSetSE
  L13_48 = A0_35
  L14_49 = A8_43
  L12_47(L13_48, L14_49)
end
function fc_Map_SetRoomChangeEventPTK(A0_50, A1_51, A2_52, A3_53, A4_54, A5_55, A6_56, A7_57, A8_58)
  local L9_59, L10_60, L11_61, L12_62, L13_63, L14_64
  L9_59 = Particle_GetPosition
  L10_60 = A1_51
  L11_61 = L9_59(L10_60)
  L12_62 = Map_SetRoomChangeEventCircle
  L13_63 = A0_50
  L14_64 = L9_59
  L12_62(L13_63, L14_64, L11_61, A2_52, A3_53, A4_54, A5_55, A6_56, A7_57)
  L12_62 = Map_EventCollSetSE
  L13_63 = A0_50
  L14_64 = A8_58
  L12_62(L13_63, L14_64)
end
function fc_Map_SetCallLuaFuncEventCirclePTK(A0_65, A1_66, A2_67, A3_68)
  local L4_69, L5_70, L6_71, L7_72, L8_73, L9_74
  L4_69 = Particle_GetPosition
  L5_70 = A1_66
  L6_71 = L4_69(L5_70)
  L7_72 = Map_SetCallLuaFuncEventCircle
  L8_73 = A0_65
  L9_74 = L4_69
  L7_72(L8_73, L9_74, L6_71, A3_68, A2_67)
end
function fc_GetRandomNextArea()
  local L0_75, L1_76, L2_77, L3_78, L4_79
  L0_75 = GetRandomDungeonFloor
  L0_75 = L0_75()
  L0_75 = L0_75 + 1
  L1_76 = DPRINT
  L2_77 = "randomdungeonfloor = "
  L3_78 = L0_75
  L2_77 = L2_77 .. L3_78
  L1_76(L2_77)
  L1_76 = 0
  L2_77 = {
    L3_78,
    L4_79,
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      -1
    },
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      -1
    },
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      -1
    },
    {
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      123,
      130,
      137,
      -1
    },
    {
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      -1
    },
    {
      128,
      135,
      142,
      122,
      129,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      138,
      145,
      125,
      -1
    },
    {
      122,
      129,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      138,
      145,
      125,
      132,
      143,
      146,
      -1
    },
    {
      119,
      120,
      121,
      122,
      123,
      124,
      125,
      126,
      127,
      128,
      129,
      130,
      131,
      132,
      133,
      134,
      135,
      136,
      137,
      138,
      139,
      140,
      141,
      142,
      143,
      144,
      145,
      146,
      -1
    }
  }
  L3_78 = {
    L4_79,
    126,
    133,
    140,
    -1
  }
  L4_79 = 119
  L4_79 = {
    119,
    126,
    133,
    140,
    120,
    127,
    134,
    -1
  }
  if L0_75 == 10 then
    L1_76 = 109
  elseif L0_75 == 20 then
    L1_76 = 110
  elseif L0_75 == 30 then
    L1_76 = 111
  elseif L0_75 == 40 then
    L1_76 = 112
  elseif L0_75 == 50 then
    L1_76 = 113
  elseif L0_75 == 60 then
    L1_76 = 114
  elseif L0_75 == 70 then
    L1_76 = 115
  elseif L0_75 == 80 then
    L1_76 = 116
  elseif L0_75 == 90 then
    L1_76 = 117
  elseif L0_75 == 100 then
    L1_76 = 118
  else
    L3_78 = 1
    L4_79 = math
    L4_79 = L4_79.floor
    L4_79 = L4_79(L0_75 / 10)
    L4_79 = L4_79 + 1
    DPRINT("tableNo = " .. L4_79)
    while L2_77[L4_79][L3_78] ~= -1 do
      L3_78 = L3_78 + 1
    end
    L1_76 = L2_77[L4_79][Rand_GetInt(L3_78 - 2) + 1]
    DPRINT("area = " .. L1_76)
  end
  return L1_76
end
function fc_Map_SetRandomRoomChangeEventPTK(A0_80, A1_81, A2_82, A3_83)
  local L4_84, L5_85, L6_86, L7_87
  L4_84 = Particle_GetPosition
  L5_85 = A1_81
  L6_86 = L4_84(L5_85)
  L7_87 = fc_GetRandomNextArea
  L7_87 = L7_87()
  Map_SetRoomChangeEventCircle(A0_80, L4_84, L6_86, A2_82, L7_87, 0, 0, 0, 0)
  Map_EventCollSetSE(A0_80, 16777223)
end
function fc_SetRandomMapAmbientType()
  local L0_88, L1_89, L2_90, L3_91
  L0_88 = {
    L1_89,
    L2_90,
    L3_91,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  }
  L1_89 = 0
  L2_90 = 1
  L3_91 = 2
  L1_89 = GetRandomDungeonFloor
  L1_89 = L1_89()
  L1_89 = L1_89 + 1
  L2_90 = SetRandomDungeonFloor
  L3_91 = L1_89
  L2_90(L3_91)
  L2_90 = math
  L2_90 = L2_90.floor
  L3_91 = L1_89 - 1
  L3_91 = L3_91 / 10
  L2_90 = L2_90(L3_91)
  L2_90 = L2_90 + 1
  L3_91 = L0_88[L2_90]
  DPRINT("ambient = " .. L3_91)
  Map_SetMapAmbientType(L3_91)
end
function fc_Map_nendotakadai1()
  FadeOut(16)
  Wait_Fade()
  Player_SetPosition(-1.1, 4.4, 7.8)
  Player_SetRotateY(90)
  Camera_SetMode(0)
  FadeIn(16)
  Wait_Fade()
end
function fc_Map_nendotakadai2()
  FadeOut(16)
  Wait_Fade()
  Player_SetPosition(-6.7, 0, 7.8)
  Player_SetRotateY(-90)
  Camera_SetMode(0)
  FadeIn(16)
  Wait_Fade()
end
function fc_IsCoolType(A0_92)
  local L2_93, L3_94, L4_95, L5_96, L6_97, L7_98
  L2_93 = A0_92
  L3_94 = false
  for L7_98 = 0, 100 do
    if cool_type[L7_98] == L2_93 then
      L3_94 = true
      break
    end
    if cool_type[L7_98] == -1 then
      break
    end
  end
  return L3_94
end
function fc_SetMotionEX(A0_99, A1_100, A2_101, A3_102)
  local L4_103, L5_104, L6_105, L7_106, L8_107, L9_108
  L4_103 = -1
  L5_104 = -1
  L6_105 = -1
  L7_106 = -1
  L8_107 = -1
  L9_108 = Npc_GetCharID
  L9_108 = L9_108(A0_99)
  for _FORV_14_ = 1, 1000 do
    if motion_set[_FORV_14_][1] == A1_100 then
      if fc_IsCoolType(L9_108) == true then
        L4_103 = motion_cool_set[_FORV_14_][1]
        L5_104 = motion_cool_set[_FORV_14_][2]
        L6_105 = motion_cool_set[_FORV_14_][3]
        L7_106 = motion_cool_set[_FORV_14_][4]
        L8_107 = motion_cool_set[_FORV_14_][5]
        break
      end
      L4_103 = motion_set[_FORV_14_][1]
      L5_104 = motion_set[_FORV_14_][2]
      L6_105 = motion_set[_FORV_14_][3]
      L7_106 = motion_set[_FORV_14_][4]
      L8_107 = motion_set[_FORV_14_][5]
      break
    end
    if motion_set[_FORV_14_][1] == -1 then
      break
    end
  end
  if L4_103 ~= -1 then
    Npc_SetMotion(A0_99, L4_103, A2_101, A3_102)
    Npc_SetFace(A0_99, L5_104, L6_105)
    Npc_SetHand(A0_99, L7_106, L8_107)
    DPRINT("motion_id = " .. A1_100)
  else
    Npc_SetMotion(A0_99, A1_100, A2_101, A3_102)
    DPRINT("**error** " .. A1_100 .. " is no set motion")
  end
end
function fc_SetTalkMotionEX(A0_109, A1_110, A2_111, A3_112, A4_113)
  local L5_114, L6_115, L7_116, L8_117, L9_118, L10_119, L11_120
  L5_114 = -1
  L6_115 = -1
  L7_116 = -1
  L8_117 = -1
  L9_118 = -1
  L10_119 = A4_113 == nil and true or A4_113
  L11_120 = Actor_GetCharID
  L11_120 = L11_120(A0_109)
  for _FORV_16_ = 1, 1000 do
    if motion_set[_FORV_16_][1] == A1_110 then
      if fc_IsCoolType(L11_120) == true then
        L5_114 = motion_cool_set[_FORV_16_][1]
        L6_115 = motion_cool_set[_FORV_16_][2]
        L7_116 = motion_cool_set[_FORV_16_][3]
        L8_117 = motion_cool_set[_FORV_16_][4]
        L9_118 = motion_cool_set[_FORV_16_][5]
        break
      end
      L5_114 = motion_set[_FORV_16_][1]
      L6_115 = motion_set[_FORV_16_][2]
      L7_116 = motion_set[_FORV_16_][3]
      L8_117 = motion_set[_FORV_16_][4]
      L9_118 = motion_set[_FORV_16_][5]
      break
    end
    if motion_set[_FORV_16_][1] == -1 then
      break
    end
  end
  if L5_114 ~= -1 then
    Actor_SetTalkMotion(A0_109, L5_114, A2_111, A3_112, L10_119)
    Actor_SetEye(A0_109, L6_115)
    Actor_SetMouth(A0_109, L7_116)
    Actor_SetHand(A0_109, L8_117, L9_118)
  else
    Actor_SetTalkMotion(A0_109, A1_110, A2_111, A3_112, L10_119)
    DPRINT("**error** " .. A1_110 .. " is no set motion")
  end
end
function fc_SetCommonMotion(A0_121, A1_122, A2_123, A3_124)
  local L4_125, L5_126, L6_127, L7_128, L8_129
  L4_125 = -1
  L5_126 = -1
  L6_127 = -1
  L7_128 = -1
  L8_129 = -1
  for _FORV_13_ = 1, 1000 do
    if char_set[A1_122 + 1][_FORV_13_][1] == Npc_GetCharID(A0_121) or char_set[A1_122 + 1][_FORV_13_][1] == -1 then
      L4_125 = char_set[A1_122 + 1][_FORV_13_][2]
      L5_126 = char_set[A1_122 + 1][_FORV_13_][3]
      L6_127 = char_set[A1_122 + 1][_FORV_13_][4]
      L7_128 = char_set[A1_122 + 1][_FORV_13_][5]
      L8_129 = char_set[A1_122 + 1][_FORV_13_][6]
      break
    end
  end
  DPRINT("motion_id = " .. L4_125)
  Npc_SetMotion(A0_121, L4_125, A2_123, A3_124)
  Npc_SetFace(A0_121, L5_126, L6_127)
  Npc_SetHand(A0_121, L7_128, L8_129)
end
function fc_EndCommonMotion(A0_130, A1_131, A2_132, A3_133)
  local L4_134, L5_135, L6_136, L7_137, L8_138
  L4_134 = -1
  L5_135 = -1
  L6_136 = -1
  L7_137 = -1
  L8_138 = -1
  for _FORV_13_ = 1, 1000 do
    if char_reset[A1_131 + 1][_FORV_13_][1] == Npc_GetCharID(A0_130) or char_reset[A1_131 + 1][_FORV_13_][1] == -1 then
      L4_134 = char_reset[A1_131 + 1][_FORV_13_][2]
      L5_135 = char_reset[A1_131 + 1][_FORV_13_][3]
      L6_136 = char_reset[A1_131 + 1][_FORV_13_][4]
      L7_137 = char_reset[A1_131 + 1][_FORV_13_][5]
      L8_138 = char_reset[A1_131 + 1][_FORV_13_][6]
      break
    end
  end
  Npc_SetMotion(A0_130, L4_134, A2_132, A3_133)
  Npc_SetFace(A0_130, L5_135, L6_136)
  Npc_SetHand(A0_130, L7_137, L8_138)
end
function fc_SetCommonTalkMotion(A0_139, A1_140, A2_141, A3_142, A4_143)
  local L5_144, L6_145, L7_146, L8_147, L9_148, L10_149
  L5_144 = -1
  L6_145 = -1
  L7_146 = -1
  L8_147 = -1
  L9_148 = -1
  L10_149 = A4_143 == nil and true or A4_143
  for _FORV_15_ = 1, 1000 do
    if char_set[A1_140 + 1][_FORV_15_][1] == Actor_GetCharID(A0_139) or char_set[A1_140 + 1][_FORV_15_][1] == -1 then
      L5_144 = char_set[A1_140 + 1][_FORV_15_][2]
      L6_145 = char_set[A1_140 + 1][_FORV_15_][3]
      L7_146 = char_set[A1_140 + 1][_FORV_15_][4]
      L8_147 = char_set[A1_140 + 1][_FORV_15_][5]
      L9_148 = char_set[A1_140 + 1][_FORV_15_][6]
      break
    end
  end
  Actor_SetTalkMotion(A0_139, L5_144, A2_141, A3_142, L10_149)
  Actor_SetEye(A0_139, L6_145)
  Actor_SetMouth(A0_139, L7_146)
  Actor_SetHand(A0_139, L8_147, L9_148)
  DPRINT("ID " .. L5_144)
end
function fc_EndCommonTalkMotion(A0_150, A1_151, A2_152, A3_153, A4_154)
  local L5_155, L6_156, L7_157, L8_158, L9_159, L10_160
  L5_155 = -1
  L6_156 = -1
  L7_157 = -1
  L8_158 = -1
  L9_159 = -1
  L10_160 = A4_154 == nil and true or A4_154
  for _FORV_15_ = 1, 1000 do
    if char_reset[A1_151 + 1][_FORV_15_][1] == Actor_GetCharID(A0_150) or char_reset[A1_151 + 1][_FORV_15_][1] == -1 then
      L5_155 = char_reset[A1_151 + 1][_FORV_15_][2]
      L6_156 = char_reset[A1_151 + 1][_FORV_15_][3]
      L7_157 = char_reset[A1_151 + 1][_FORV_15_][4]
      L8_158 = char_reset[A1_151 + 1][_FORV_15_][5]
      L9_159 = char_reset[A1_151 + 1][_FORV_15_][6]
      break
    end
  end
  Actor_SetTalkMotion(A0_150, L5_155, A2_152, A3_153, L10_160)
  Actor_SetEye(A0_150, L6_156)
  Actor_SetMouth(A0_150, L7_157)
  Actor_SetHand(A0_150, L8_158, L9_159)
  DPRINT("ID " .. L5_155)
end
function fc_Map_SetEncountLoop(A0_161, A1_162, A2_163, A3_164)
  while true do
    Map_SetEncount(A0_161, A1_162, false)
    if GetBattleResult() == 3 then
      BGFilterFadeOut(0.1)
      Wait_BGFilterFade()
      FadeIn(16)
      Wait_Fade()
      if A3_164 == true then
        Message_WindowSystemOpen()
      else
        Message_WindowOpen(1)
      end
      Wait_MessageWindow()
      SetMes("BTL_00", "[TALK ]\230\136\166\233\151\152\227\130\146\227\130\132\227\130\138\231\155\180\227\129\151\227\129\190\227\129\153\227\128\130")
      Message_WindowClose()
      Message_Clear()
      Wait_MessageWindow()
      FadeOut(16)
      Wait_Fade()
      BGFilterFadeIn(0.1)
      Wait_BGFilterFade()
    else
      break
    end
  end
  if A2_163 == true then
    FadeIn(16)
    Wait_Fade()
  end
end
function fc_SetMesBranch(A0_165, A1_166, A2_167)
  local L3_168
  L3_168 = Search_MsgChar
  L3_168 = L3_168(A1_166, A2_167)
  fc_CharBranch(A0_165, L3_168)
end
function fc_SetClearEvent()
  local L0_169, L1_170, L2_171, L3_172, L4_173, L5_174, L6_175
  L0_169 = 10
  L1_170 = Particle_Create
  L2_171 = 20
  L3_172 = 0
  L1_170(L2_171, L3_172, L4_173)
  L1_170 = PlaySE
  L2_171 = 16777237
  L1_170(L2_171)
  L1_170 = Player_GetPosition
  L3_172 = L1_170()
  L4_173(L5_174, L6_175, L2_171, L3_172)
  for _FORV_7_ = 4, L0_169 - 1 do
    if _FORV_7_ < 8 then
      for _FORV_11_ = 0, 7 do
        L2_171 = L2_171 + 0.002857142857142857 * (_FORV_7_ - 4)
        Player_SetOffsetPosition(0, L2_171, 0)
        Wait_Timer(0.01 - 0.0025 * (_FORV_7_ - 8))
      end
    else
      for _FORV_11_ = 0, 5 do
        L2_171 = L2_171 + 0.005 * (_FORV_7_ - 4)
        Player_SetOffsetPosition(0, L2_171, 0)
        Wait_Timer(0.01)
      end
    end
  end
  L4_173(L5_174, L6_175, 1, 1)
  L4_173()
  L4_173(L5_174)
  L4_173(L5_174, L6_175, 0)
  L4_173(L5_174)
  L4_173(L5_174)
  L4_173(L5_174)
  L4_173()
  L4_173(L5_174)
  L4_173(L5_174)
end
function fc_lock_event()
  Message_WindowOpen(1)
  Wait_MessageWindow()
  SetMes("LCK_000", "\233\150\139\227\129\139\227\129\170\227\129\132\226\128\166\227\128\130\n\227\130\171\227\130\174\227\129\140\227\129\139\227\129\139\227\129\163\227\129\166\227\129\132\227\130\139\227\129\191\227\129\159\227\129\132\227\129\160\227\128\130")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
function floor_change_entrance()
  Message_WindowOpen(1)
  Wait_MessageWindow()
  SetMes("MOP_000", "\227\130\168\227\131\179\227\131\136\227\131\169\227\131\179\227\130\185\227\129\171\230\136\187\227\130\138\227\129\190\227\129\153\227\129\139?")
  Player_SetMotion(0, 0.2, true)
  Message_SetBranch("\227\129\175\227\129\132", "\227\129\132\227\129\132\227\129\136", 1)
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if Message_GetBranchResult() == 0 then
    PlaySE(16777223)
    Map_ChangeRoom(108, -2.04, 0, 0, -90)
  end
end
function floor_change_next()
  Message_WindowOpen(1)
  Wait_MessageWindow()
  SetMes("MOP_001", "\229\156\176\228\184\139\231\169\186\230\180\158\227\129\174\229\165\165\227\129\171\233\128\178\227\129\191\227\129\190\227\129\153\227\129\139?")
  Player_SetMotion(0, 0.2, true)
  Message_SetBranch("\227\129\175\227\129\132", "\227\129\132\227\129\132\227\129\136", 1)
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if Message_GetBranchResult() == 0 then
    OffSystemFlag(0)
    PlaySE(16777223)
    Map_ChangeRoom(fc_GetRandomNextArea(), 0, 0, 0, -90)
  end
end
function common_load_func()
  Map_LoadModelSet(4)
  Map_BattleBGSet(0)
  SetMapBGM(2)
  if 2 > GetChapter() then
    Model_Load(20, 7)
  end
  if GetChapter() < 3 then
    Model_Load(21, 7)
  end
end
function common_init_func()
  Map_SetRoomChangeEventRect(0, -2.6, -19.5, -2.1, -17.7, 5, -3, 0, -3.9, 90)
  Map_SetRoomChangeEventRect(1, -2.6, -12.6, -2.1, -10.8, 5, -3, 0, 3.2, 90)
  Map_SetRoomChangeEventRect(2, -2.6, -9.5, -2.1, -7.7, 6, -3, 0, -3.9, 90)
  Map_SetRoomChangeEventRect(3, -2.6, -2.6, -2.1, -0.8, 6, -3, 0, 3.2, 90)
  Map_SetRoomChangeEventRect(4, -2.6, 0.5, -2.1, 2.3, 7, -3, 0, -3.9, 90)
  Map_SetRoomChangeEventRect(5, -2.6, 7.4, -2.1, 9.2, 7, -3, 0, 3.2, 90)
  if 13 <= GetChapter() then
    Map_SetRoomChangeEventRect(6, -2.6, 10.5, -2.1, 12.3, 8, -3, 0, -3.9, 90)
    Map_SetRoomChangeEventRect(7, -2.6, 17.4, -2.1, 19.2, 8, -3, 0, 3.2, 90)
  else
    Map_SetCallLuaFuncCheckEventRect(6, -2.6, 10.5, -2.1, 12.3, "fc_lock_event", 0)
    Map_SetCallLuaFuncCheckEventRect(7, -2.6, 17.4, -2.1, 19.2, "fc_lock_event", 0)
  end
  Map_SetRoomChangeEventRect(8, -2.2, -23.5, -1.5, -20.9, 0, -1.6, 0, -26.5, -90)
  Map_SetRoomChangeEventRect(9, -2.2, 20.5, -1.5, 23.3, 0, -1.6, 0, 25.5, -90)
  Map_EventCollSetSE(8, 16777219)
  Map_EventCollSetSE(9, 16777219)
  if 2 <= GetChapter() then
    Map_SetRoomChangeEventRect(10, -2.2, -27.3, -1.5, -25, 9, -3, 0, -22.1, -90)
    Map_EventCollSetSE(10, 16777219)
  else
    Model_SetPosition(20, -3, 0, -26)
    Model_SetRotateY(20, -90)
  end
  if 3 <= GetChapter() then
    Map_SetRoomChangeEventRect(11, -2.2, 24.7, -1.4, 27.3, 9, -3, 0, 21.9, -90)
    Map_EventCollSetSE(11, 16777219)
  else
    Model_SetPosition(21, -3, 0, 26)
    Model_SetRotateY(21, -90)
  end
end
function common_npc_load_func()
  Npc_Load(20, 33554453)
  Npc_Load(21, 33554446)
  Npc_Load(22, 33554454)
  Npc_Load(23, 33554447)
  Npc_Load(24, 33554448)
end
function common_npc_init_func()
  Npc_SetPosition(20, -2.8, 0, 3.1)
  Npc_SetRotateY(20, -60)
  Npc_SetMessageScriptFunc(20, "npc_message_func_00")
  Npc_SetPosition(21, -2.9, 0, 4.1)
  Npc_SetRotateY(21, -105)
  Npc_SetMessageScriptFunc(21, "npc_message_func_01")
  Npc_SetPosition(22, -6.13, 0, -20.26)
  Npc_SetRotateY(22, 180)
  Npc_SetPosition(22, -6.13, 0, -4.41)
  Npc_SetWaitTimeQueue(22, 2.5)
  Npc_SetMoveQueue(22, 0.9, -6.13, 0, -20.26)
  Npc_SetWaitTimeQueue(22, 2.5)
  Npc_SetMessageScriptFunc(22, "npc_message_func_02")
  Npc_SetMessageScriptFunc(22, "npc_message_func_02")
  Npc_SetPosition(23, -2.98, 0, -24.22)
  Npc_SetRotateY(23, -90)
  Npc_SetMessageScriptFunc(23, "npc_message_func_03")
  Npc_SetPosition(24, -2.93, 0, 16.5)
  Npc_SetRotateY(24, 180)
  Npc_SetMessageScriptFunc(24, "npc_message_func_04")
end
function npc_message_func_00()
  Wait_Fade()
  Message_WindowOpen()
  Wait_MessageWindow()
  SetMes("MOV_011", "[TALK \231\148\159\229\190\146]\228\187\138\230\151\165\227\129\175\227\129\170\227\129\171\227\129\151\227\130\136\227\129\134\227\129\139\227\129\170\227\131\188\227\128\130\n\229\139\137\229\188\183\227\130\130\227\129\132\227\129\132\227\129\145\227\129\169\227\128\129\233\129\139\229\139\149\227\130\130\227\129\151\227\129\159\227\129\132\227\129\170\227\131\188\227\128\130")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
function npc_message_func_01()
  Wait_Fade()
  Message_WindowOpen()
  Wait_MessageWindow()
  SetMes("MOV_012", "[TALK \231\148\159\229\190\146]\227\129\170\227\129\171\227\129\139\227\129\138\227\130\130\227\129\151\227\130\141\227\129\132\228\186\139\227\129\138\227\129\147\227\130\137\227\129\170\227\129\132\227\129\139\227\129\170\227\131\188\227\128\130\n\227\129\159\227\129\168\227\129\136\227\129\176\227\128\129\230\128\170\227\129\151\227\129\132\228\186\139\228\187\182\227\129\168\227\129\139\226\128\166!")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
function npc_message_func_02()
  Wait_Fade()
  Message_WindowOpen()
  Wait_MessageWindow()
  SetMes("MOV_012_01", "[TALK \231\148\159\229\190\146]\230\176\151\230\140\129\227\129\161\227\129\140\233\171\152\227\129\182\227\130\139\227\129\168\227\128\129\232\186\171\228\189\147\227\129\171\227\129\157\227\130\140\227\129\140\232\161\168\227\130\140\227\130\139\227\130\136\227\129\173!\n\227\129\170\227\130\147\227\129\139\227\129\147\227\129\134\226\128\166\227\128\130\229\138\155\227\129\140\227\129\130\227\129\181\227\130\140\227\129\166\227\129\143\227\130\139\230\132\159\227\129\152!!!")
  SetMes("MOV_012_02", "[TALK \231\148\159\229\190\146]\227\129\136?\227\128\128\232\168\128\227\129\163\227\129\166\227\130\139\230\132\143\229\145\179\227\129\140\227\130\143\227\129\139\227\130\147\227\129\170\227\129\132?\n\232\166\129\227\129\153\227\130\139\227\129\171\227\128\129\230\176\151\230\140\129\227\129\161\227\129\167\229\188\183\227\129\143\227\129\170\227\130\140\227\130\139\227\129\163\227\129\166\227\129\147\227\129\168\227\129\160\227\130\136!")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
function npc_message_func_03()
  Wait_Fade()
  Message_WindowOpen()
  Wait_MessageWindow()
  SetMes("MOV_012_03", "[TALK \231\148\159\229\190\146]\227\130\136\227\129\132\227\129\147\227\129\175\229\174\154\232\166\143\227\130\146\230\140\175\227\130\138\227\129\190\227\130\143\227\129\151\227\129\159\227\130\137\227\129\132\227\129\145\227\129\170\227\129\132\227\130\147\227\129\160\227\130\136?\n\227\129\170\227\130\147\227\129\160\227\129\139\226\128\166\227\129\157\227\130\147\227\129\170\228\186\186\227\129\140\227\129\132\227\130\139\227\129\145\227\129\169\226\128\166\227\128\130\n\229\141\177\227\129\170\227\129\132\227\130\147\227\129\160\227\129\139\227\130\137\227\129\173\227\129\163!")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
function npc_message_func_04()
  Wait_Fade()
  Message_WindowOpen()
  Wait_MessageWindow()
  SetMes("MOV_012_04", "[TALK \231\148\159\229\190\146][COL SYS_NAM]\233\173\133\229\138\155[COL SYS_DEF]\227\129\140\233\171\152\227\129\145\227\130\140\227\129\176\233\171\152\227\129\132\227\129\187\227\129\169\227\128\129\n[COL SYS_NAM]\227\131\145\227\131\149\227\130\169\227\131\188\227\131\158\227\131\179\227\130\185\230\138\128[COL SYS_DEF]\227\129\174\229\168\129\229\138\155\227\129\140\229\188\183\227\129\143\227\129\170\227\130\139\227\130\147\227\129\160\227\129\163\227\129\166\227\131\188\227\128\130\n[COL SYS_NAM]\227\129\177\227\129\181\227\129\137\227\131\188\227\129\190\227\131\188[COL SYS_DEF]\227\129\171\227\129\168\227\129\163\227\129\166\227\128\129\227\129\153\227\129\148\227\129\143\229\164\167\228\186\139\227\129\170\232\131\189\229\138\155\227\129\160\227\129\173!!")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
DPRINT("st00_s004.luc")
function load_func()
  DPRINT("st00_s004.luc" .. "::load_func()")
  common_load_func()
  if CheckLocalFlag(32) == false then
    Npc_Load(1, 10)
    Npc_Load(2, 12)
    Npc_Load(3, 14)
    Npc_Load(4, 5)
    Npc_Load(0, 16777532)
    Particle_LoadResourceFile(9)
    Particle_LoadResourceFile(23)
  else
    common_npc_load_func()
  end
end
function init_func()
  local L0_176, L1_177, L2_178
  L0_176 = DPRINT
  L1_177 = "st00_s004.luc"
  L2_178 = "::init_func()"
  L1_177 = L1_177 .. L2_178
  L0_176(L1_177)
  L0_176 = common_init_func
  L0_176()
  L0_176 = CheckLocalFlag
  L1_177 = 32
  L0_176 = L0_176(L1_177)
  if L0_176 == false then
    L0_176 = DonotStartFadeIn
    L0_176()
    L0_176 = Npc_SetPosition
    L1_177 = 4
    L2_178 = -4.2
    L0_176(L1_177, L2_178, 0, -10.45)
    L0_176 = Npc_SetRotateY
    L1_177 = 4
    L2_178 = 0
    L0_176(L1_177, L2_178)
    L0_176 = Npc_SetPosition
    L1_177 = 1
    L2_178 = -3.5
    L0_176(L1_177, L2_178, 0, -3.9)
    L0_176 = Npc_SetInterRotateY_To_Npc
    L1_177 = 1
    L2_178 = 4
    L0_176(L1_177, L2_178, 1)
    L0_176 = Npc_SetPosition
    L1_177 = 2
    L2_178 = -4.5
    L0_176(L1_177, L2_178, 0, -2.6)
    L0_176 = Npc_SetInterRotateY_To_Npc
    L1_177 = 2
    L2_178 = 4
    L0_176(L1_177, L2_178, 1)
    L0_176 = Npc_SetPosition
    L1_177 = 3
    L2_178 = -6.1
    L0_176(L1_177, L2_178, 0, -3.2)
    L0_176 = Npc_SetInterRotateY_To_Npc
    L1_177 = 3
    L2_178 = 4
    L0_176(L1_177, L2_178, 1)
    L0_176 = Npc_SetPosition
    L1_177 = 0
    L2_178 = -3.79
    L0_176(L1_177, L2_178, 0, -7.01)
    L0_176 = Npc_GetPosition
    L1_177 = 3
    L2_178 = L0_176(L1_177)
    Npc_SetInterRotateY_To_Pos(0, L0_176 - 1.5, L2_178, 1)
    Npc_SetVisible(0, false)
    Camera_SetMode(3)
    Camera_SetRotate(324)
    Camera_SetHeight(4)
    Camera_SetFov(7)
    Camera_SetTargetPosition(-6.17, 0.73, -4.9)
    Player_SetVisible(false)
  else
    L0_176 = common_npc_init_func
    L0_176()
  end
end
function main_func()
  local L0_179, L1_180, L2_181, L3_182, L4_183, L5_184, L6_185, L7_186, L8_187
  L0_179 = DPRINT
  L1_180 = "st00_s004.luc"
  L2_181 = "::main_func()"
  L1_180 = L1_180 .. L2_181
  L0_179(L1_180)
  L0_179 = CheckLocalFlag
  L1_180 = 32
  L0_179 = L0_179(L1_180)
  if L0_179 == true then
  else
    L0_179 = Map_SetTalk
    L1_180 = "script/main_scenario/ch04_NendoWorld_main01/talk_00.lbn"
    L0_179(L1_180)
    L0_179 = Npc_SetVisible
    L1_180 = 3
    L2_181 = false
    L0_179(L1_180, L2_181)
    L0_179 = FadeIn
    L1_180 = 16
    L0_179(L1_180)
    L0_179 = Wait_Fade
    L0_179()
    L0_179 = Npc_GetPosition
    L1_180 = 4
    L2_181 = L0_179(L1_180)
    L3_182 = Npc_SetMoveSpeed
    L4_183 = 4
    L5_184 = 2
    L3_182(L4_183, L5_184)
    L3_182 = Npc_SetMovePoints
    L4_183 = 4
    L5_184 = L0_179
    L6_185 = L1_180
    L7_186 = L2_181
    L8_187 = L0_179
    L3_182(L4_183, L5_184, L6_185, L7_186, L8_187, L1_180, L2_181 + 2, false)
    L3_182 = Message_WindowOpen
    L3_182()
    L3_182 = Wait_MessageWindow
    L3_182()
    L3_182 = SetMes
    L4_183 = "MES_77"
    L5_184 = "[TALK \227\131\169\227\130\164\227\131\128\227\131\188]\231\173\148\227\129\136\227\129\175\231\176\161\229\141\152\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = Camera_SetMoveSpeed
    L4_183 = 3
    L3_182(L4_183)
    L3_182 = Camera_SetMode
    L4_183 = 3
    L3_182(L4_183)
    L3_182 = Camera_SetMovePoints
    L4_183 = -6.17
    L5_184 = 0.73
    L6_185 = -4.9
    L7_186 = -6.17
    L8_187 = 1.43
    L3_182(L4_183, L5_184, L6_185, L7_186, L8_187, -4.9)
    L3_182 = Wait_Timer
    L4_183 = 0.5
    L3_182(L4_183)
    L3_182 = SetEventBGM
    L4_183 = 10
    L3_182(L4_183)
    L3_182 = PlaySE
    L4_183 = 33554474
    L3_182(L4_183)
    L3_182 = Particle_Create
    L4_183 = 1
    L5_184 = 23
    L6_185 = 0
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_GetPosition
    L4_183 = 4
    L5_184 = L3_182(L4_183)
    L2_181 = L5_184
    L1_180 = L4_183
    L0_179 = L3_182
    L3_182 = Particle_SetPosition
    L4_183 = 1
    L5_184 = L0_179
    L6_185 = L1_180
    L7_186 = L2_181
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_SetMotion
    L4_183 = 4
    L5_184 = 18
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_77_00"
    L5_184 = "[TALK \227\131\169\227\130\164\227\131\128\227\131\188]\230\176\151\227\129\171\229\133\165\227\130\137\227\129\170\227\129\132\227\129\139\227\130\137\227\129\167\227\129\153\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = Wait_CameraMove
    L3_182()
    L3_182 = Wait_Timer
    L4_183 = 0.5
    L3_182(L4_183)
    L3_182 = Wait_ParticleAnimation
    L4_183 = 1
    L3_182(L4_183)
    L3_182 = Particle_Delete
    L4_183 = 1
    L3_182(L4_183)
    L3_182 = Camera_SetRotate
    L4_183 = 212
    L3_182(L4_183)
    L3_182 = Camera_SetFov
    L4_183 = 10
    L3_182(L4_183)
    L3_182 = Camera_SetTargetPosition
    L4_183 = -6.82
    L5_184 = 1.57
    L6_185 = -7.5
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_SetVisible
    L4_183 = 3
    L5_184 = true
    L3_182(L4_183, L5_184)
    L3_182 = Npc_SetVisible
    L4_183 = 4
    L5_184 = false
    L3_182(L4_183, L5_184)
    L3_182 = Npc_SetPosition
    L4_183 = 4
    L5_184 = -4.2
    L6_185 = 0
    L7_186 = -7.45
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_SetInterRotateY_To_Npc
    L4_183 = 4
    L5_184 = 3
    L6_185 = 1
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_SetMotion
    L4_183 = 4
    L5_184 = 19
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 4
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = fc_SetCommonMotion
    L4_183 = 1
    L5_184 = 3
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 1
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_78"
    L5_184 = "[TALK \227\129\144\227\129\190\229\173\144]\227\129\136\227\129\136!?\n\227\130\130\227\129\151\227\129\139\227\129\151\227\129\166[COL SYS_CHR]\227\131\169\227\130\164\227\131\128\227\131\188[COL SYS_DEF]\227\129\161\227\130\131\227\130\147\227\128\129\n\229\173\166\229\156\146\227\129\140\229\171\140\227\129\132\227\129\160\227\129\163\227\129\159\227\129\144\227\129\190\227\129\139!?"
    L3_182(L4_183, L5_184)
    L3_182 = Npc_ShowPopupIcon
    L4_183 = 2
    L5_184 = 2
    L3_182(L4_183, L5_184)
    L3_182 = SetMes
    L4_183 = "MES_79"
    L5_184 = "[TALK \233\149\183\233\150\128]\227\129\147\227\129\174\229\160\180\229\144\136\227\128\129\229\189\188\229\165\179\227\130\130\231\178\190\231\165\158\230\148\175\233\133\141\227\130\146\229\143\151\227\129\145\227\129\166\227\129\132\227\130\139\227\129\168\n\232\128\131\227\129\136\227\130\139\227\129\174\227\129\140\229\166\165\229\189\147\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = Message_WindowClose
    L3_182()
    L3_182 = Message_Clear
    L3_182()
    L3_182 = Wait_MessageWindow
    L3_182()
    L3_182 = Npc_HidePopupIcon
    L4_183 = 2
    L3_182(L4_183)
    L3_182 = Npc_SetVisible
    L4_183 = 4
    L5_184 = true
    L3_182(L4_183, L5_184)
    L3_182 = Camera_SetRotate
    L4_183 = 274
    L3_182(L4_183)
    L3_182 = Camera_SetFov
    L4_183 = 7
    L3_182(L4_183)
    L3_182 = Camera_SetTargetPosition
    L4_183 = -7.3
    L5_184 = 1.31
    L6_185 = -7.1
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = fc_SetMotionEX
    L4_183 = 1
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Camera_SetFov
    L4_183 = 13
    L5_184 = 5
    L3_182(L4_183, L5_184)
    L3_182 = Camera_SetRotate
    L4_183 = 224
    L5_184 = 5
    L3_182(L4_183, L5_184)
    L3_182 = Wait_Timer
    L4_183 = 1
    L3_182(L4_183)
    L3_182 = Message_WindowOpen
    L3_182()
    L3_182 = Wait_MessageWindow
    L3_182()
    L3_182 = Npc_GetPosition
    L4_183 = 4
    L5_184 = L3_182(L4_183)
    L2_181 = L5_184
    L1_180 = L4_183
    L0_179 = L3_182
    L3_182 = Npc_SetMoveSpeed
    L4_183 = 4
    L5_184 = 0.5
    L3_182(L4_183, L5_184)
    L3_182 = Npc_SetMovePoints
    L4_183 = 4
    L5_184 = L0_179
    L6_185 = L1_180
    L7_186 = L2_181
    L8_187 = L0_179 - 0.5
    L3_182(L4_183, L5_184, L6_185, L7_186, L8_187, L1_180, L2_181 + 1.5, false)
    L3_182 = SetMes
    L4_183 = "MES_80_00"
    L5_184 = "[TALK \227\131\169\227\130\164\227\131\128\227\131\188]\227\129\147\227\129\147\227\129\171\227\129\175\229\150\156\227\129\179\227\130\132\229\184\140\230\156\155\227\129\140\230\186\162\227\130\140\227\129\166\227\129\132\227\129\190\227\129\153\227\128\130\n\227\129\147\227\130\147\227\129\170\231\155\174\233\154\156\227\130\138\227\129\170\229\160\180\230\137\128\227\128\129\n\230\148\190\231\189\174\227\129\151\227\129\166\227\129\138\227\129\143\227\130\143\227\129\145\227\129\171\227\129\175\227\129\132\227\129\141\227\129\190\227\129\155\227\130\147\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = Wait_NpcMove
    L4_183 = 4
    L3_182(L4_183)
    L3_182 = Npc_SetInterRotateY_To_Npc
    L4_183 = 1
    L5_184 = 4
    L6_185 = 10
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_SetInterRotateY_To_Npc
    L4_183 = 2
    L5_184 = 4
    L6_185 = 20
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_SetInterRotateY_To_Npc
    L4_183 = 3
    L5_184 = 4
    L6_185 = 8
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_GetPosition
    L4_183 = 3
    L5_184 = L3_182(L4_183)
    L2_181 = L5_184
    L1_180 = L4_183
    L0_179 = L3_182
    L3_182 = Npc_SetInterRotateY_To_Pos
    L4_183 = 4
    L5_184 = L0_179 - 0.5
    L6_185 = L2_181
    L7_186 = 10
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Wait_NpcRotate
    L4_183 = 4
    L3_182(L4_183)
    L3_182 = SetMes
    L4_183 = "MES_80_01"
    L5_184 = "[TALK \227\131\169\227\130\164\227\131\128\227\131\188][COL SYS_CHR]\227\131\141\227\130\172\227\130\175\227\131\169\227\130\164[COL SYS_DEF]\230\167\152\227\129\174\227\129\159\227\130\129\227\129\171\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = fc_SetCommonMotion
    L4_183 = 4
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 4
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_81"
    L5_184 = "[TALK \227\131\169\227\130\164\227\131\128\227\131\188]\227\129\157\227\130\140\227\129\171\227\128\129\227\129\147\227\129\134\227\130\132\227\129\163\227\129\166\228\187\178\233\150\147\229\144\140\229\163\171\227\130\146\230\136\166\227\130\143\227\129\155\227\130\139\227\129\174\227\130\130\n\230\165\189\227\129\151\227\129\132\227\129\167\227\129\153\227\129\139\227\130\137\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = Wait_Timer
    L4_183 = 0.5
    L3_182(L4_183)
    L3_182 = Npc_GetPosition
    L4_183 = 3
    L5_184 = L3_182(L4_183)
    L2_181 = L5_184
    L1_180 = L4_183
    L0_179 = L3_182
    L3_182 = Npc_SetMoveSpeed
    L4_183 = 3
    L5_184 = 2
    L3_182(L4_183, L5_184)
    L3_182 = Npc_SetMovePoints
    L4_183 = 3
    L5_184 = L0_179
    L6_185 = L1_180
    L7_186 = L2_181
    L8_187 = L0_179 + 0.1
    L3_182(L4_183, L5_184, L6_185, L7_186, L8_187, L1_180, L2_181 - 0.5, false)
    L3_182 = Wait_NpcMove
    L4_183 = 3
    L3_182(L4_183)
    L3_182 = fc_SetCommonMotion
    L4_183 = 3
    L5_184 = 1
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 3
    L5_184 = 0
    L6_185 = 0.3
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_ShowPopupIcon
    L4_183 = 3
    L5_184 = 14
    L3_182(L4_183, L5_184)
    L3_182 = SetMes
    L4_183 = "MES_82"
    L5_184 = "[TALK \227\130\162\227\131\171\227\131\149]\230\156\172\229\189\147\227\129\171\232\182\163\229\145\179\227\129\174\230\130\170\227\129\132\233\128\163\228\184\173\227\129\160\227\129\173\227\128\130\n\231\155\174\227\130\146\232\166\154\227\129\190\227\129\149\227\129\155\227\129\166\227\129\130\227\129\146\227\130\139\227\130\136!"
    L3_182(L4_183, L5_184)
    L3_182 = Message_WindowClose
    L3_182()
    L3_182 = Message_Clear
    L3_182()
    L3_182 = Wait_MessageWindow
    L3_182()
    L3_182 = fc_SetMotionEX
    L4_183 = 3
    L5_184 = 16777396
    L6_185 = 0.3
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Wait_Timer
    L4_183 = 0.6
    L3_182(L4_183)
    L3_182 = Npc_PauseMotion
    L4_183 = 3
    L5_184 = true
    L3_182(L4_183, L5_184)
    L3_182 = SetEventBGM
    L4_183 = -1
    L3_182(L4_183)
    L3_182 = Map_SetEncount
    L4_183 = eEnemyPartyScenario
    L5_184 = 26
    L6_185 = false
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = fc_SetMotionEX
    L4_183 = 4
    L5_184 = 16777410
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = fc_SetMotionEX
    L4_183 = 0
    L5_184 = 16777410
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Wait_Timer
    L4_183 = 1
    L3_182(L4_183)
    L3_182 = Npc_SetPosition
    L4_183 = 4
    L5_184 = -4.2
    L6_185 = 0
    L7_186 = -8.45
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_SetRotateY
    L4_183 = 4
    L5_184 = 0
    L3_182(L4_183, L5_184)
    L3_182 = Camera_SetRotate
    L4_183 = 290
    L3_182(L4_183)
    L3_182 = Camera_SetFov
    L4_183 = 10.5
    L3_182(L4_183)
    L3_182 = Camera_SetTargetPosition
    L4_183 = -8.55
    L5_184 = 1.73
    L6_185 = -5.37
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = Npc_SetInterRotateY_To_Npc
    L4_183 = 0
    L5_184 = 3
    L6_185 = 1
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = FadeIn
    L4_183 = 16
    L3_182(L4_183)
    L3_182 = Wait_Fade
    L3_182()
    L3_182 = Wait_Timer
    L4_183 = 1
    L3_182(L4_183)
    L3_182 = PlaySE
    L4_183 = 33554444
    L3_182(L4_183)
    L3_182 = Particle_Create
    L4_183 = 0
    L5_184 = 9
    L6_185 = 0
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = PlaySE
    L4_183 = 16777250
    L3_182(L4_183)
    L3_182 = Npc_GetPosition
    L4_183 = 0
    L5_184 = L3_182(L4_183)
    L2_181 = L5_184
    L1_180 = L4_183
    L0_179 = L3_182
    L3_182 = Particle_SetPosition
    L4_183 = 0
    L5_184 = L0_179
    L6_185 = L1_180
    L7_186 = L2_181
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Wait_Timer
    L4_183 = 1
    L3_182(L4_183)
    L3_182 = FadeOut
    L4_183 = 4
    L5_184 = 1
    L6_185 = 1
    L7_186 = 1
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Wait_Fade
    L3_182()
    L3_182 = Wait_Timer
    L4_183 = 0.1
    L3_182(L4_183)
    L3_182 = Npc_SetVisible
    L4_183 = 0
    L5_184 = true
    L3_182(L4_183, L5_184)
    L3_182 = FadeIn
    L4_183 = 4
    L3_182(L4_183)
    L3_182 = Wait_Fade
    L3_182()
    L3_182 = Wait_ParticleAnimation
    L4_183 = PTK_00
    L3_182(L4_183)
    L3_182 = Particle_Delete
    L4_183 = PTK_00
    L3_182(L4_183)
    L3_182 = Message_WindowOpen
    L3_182()
    L3_182 = Wait_MessageWindow
    L3_182()
    L3_182 = fc_SetMotionEX
    L4_183 = 0
    L5_184 = 16777411
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 0
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_83"
    L5_184 = "[TALK \227\131\162\227\131\179\227\130\185\227\130\191\227\131\188]\227\129\161\227\129\163!\n\227\129\190\227\129\160\227\129\160!\227\128\128\227\129\190\227\129\160\227\130\170\227\131\172\227\129\159\227\129\161\227\129\175\232\178\160\227\129\145\227\129\166\227\129\173\227\130\167!"
    L3_182(L4_183, L5_184)
    L3_182 = Camera_SetRotate
    L4_183 = 216
    L3_182(L4_183)
    L3_182 = Camera_SetFov
    L4_183 = 15
    L3_182(L4_183)
    L3_182 = Camera_SetTargetPosition
    L4_183 = -7.75
    L5_184 = 1.31
    L6_185 = -9.12
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = fc_SetCommonMotion
    L4_183 = 1
    L5_184 = 3
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 1
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_84"
    L5_184 = "[TALK \227\129\144\227\129\190\229\173\144]\227\129\134\227\130\143!?\n[COL SYS_CHR]\227\131\169\227\130\164\227\131\128\227\131\188[COL SYS_DEF]\227\129\161\227\130\131\227\130\147\227\129\139\227\130\137\227\131\162\227\131\179\227\130\185\227\130\191\227\131\188\227\129\140\n\229\135\186\227\129\166\227\129\141\227\129\159\227\129\144\227\129\190!"
    L3_182(L4_183, L5_184)
    L3_182 = Npc_ShowPopupIcon
    L4_183 = 2
    L5_184 = 3
    L3_182(L4_183, L5_184)
    L3_182 = SetMes
    L4_183 = "MES_85"
    L5_184 = "[TALK \233\149\183\233\150\128]\231\178\190\231\165\158\230\148\175\233\133\141\227\129\174\227\129\191\227\129\167\227\129\170\227\129\143\227\128\129\n\230\134\145\228\190\157\232\131\189\229\138\155\227\129\174\227\129\130\227\130\139\227\129\147\227\129\168\227\130\146\231\162\186\232\170\141\227\128\130"
    L3_182(L4_183, L5_184)
    L3_182 = fc_EndCommonMotion
    L4_183 = 1
    L5_184 = 3
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = fc_SetMotionEX
    L4_183 = 3
    L5_184 = 16777398
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Npc_RequestMotion
    L4_183 = 3
    L5_184 = 0
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_86"
    L5_184 = "[TALK \227\130\162\227\131\171\227\131\149]\229\191\131\227\129\176\227\129\139\227\130\138\227\129\139\227\128\129\228\189\147\227\129\190\227\129\167\228\185\151\227\129\163\229\143\150\227\130\139\227\129\168\227\129\175\227\128\129\n\227\129\169\227\129\147\227\129\190\227\129\167\227\130\130\229\141\145\230\128\175\227\129\170\230\137\139\227\129\176\227\129\139\227\130\138\228\189\191\227\129\134\n\233\128\163\228\184\173\227\129\160\227\129\173!"
    L3_182(L4_183, L5_184)
    L3_182 = fc_SetCommonMotion
    L4_183 = 0
    L5_184 = 5
    L6_185 = 0.2
    L7_186 = true
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = SetMes
    L4_183 = "MES_87"
    L5_184 = "[TALK \227\131\162\227\131\179\227\130\185\227\130\191\227\131\188]\232\168\128\227\129\163\227\129\166\227\130\141!\n\231\181\182\229\175\190\230\179\163\227\129\139\227\129\155\227\129\166\227\130\132\227\130\139\227\129\139\227\130\137\227\129\170!"
    L3_182(L4_183, L5_184)
    L3_182 = Message_WindowClose
    L3_182()
    L3_182 = Message_Clear
    L3_182()
    L3_182 = Wait_MessageWindow
    L3_182()
    L3_182 = fc_SetMotionEX
    L4_183 = 0
    L5_184 = 16777394
    L6_185 = 0.2
    L7_186 = false
    L3_182(L4_183, L5_184, L6_185, L7_186)
    L3_182 = Wait_Timer
    L4_183 = 0.5
    L3_182(L4_183)
    L3_182 = PlaySE
    L4_183 = 33554444
    L3_182(L4_183)
    L3_182 = Particle_Create
    L4_183 = 0
    L5_184 = 9
    L6_185 = 0
    L3_182(L4_183, L5_184, L6_185)
    L3_182 = PlaySE
    L4_183 = 16777250
    L3_182(L4_183)
    L3_182 = Npc_GetPosition
    L4_183 = NPC_03
    L5_184 = L3_182(L4_183)
    L6_185 = Particle_SetPosition
    L7_186 = 0
    L8_187 = L3_182
    L6_185(L7_186, L8_187, L4_183, L5_184)
    L6_185 = FadeOut
    L7_186 = 4
    L8_187 = 1
    L6_185(L7_186, L8_187, 1, 1)
    L6_185 = Wait_Fade
    L6_185()
    L6_185 = Wait_Timer
    L7_186 = 0.1
    L6_185(L7_186)
    L6_185 = Npc_SetVisible
    L7_186 = 0
    L8_187 = false
    L6_185(L7_186, L8_187)
    L6_185 = FadeIn
    L7_186 = 4
    L6_185(L7_186)
    L6_185 = Wait_Fade
    L6_185()
    L6_185 = Wait_ParticleAnimation
    L7_186 = PTK_00
    L6_185(L7_186)
    L6_185 = Particle_Delete
    L7_186 = PTK_00
    L6_185(L7_186)
    L6_185 = Npc_HidePopupIcon
    L7_186 = 2
    L6_185(L7_186)
    L6_185 = Npc_HidePopupIcon
    L7_186 = 3
    L6_185(L7_186)
    L6_185 = FadeOut
    L7_186 = 16
    L6_185(L7_186)
    L6_185 = Wait_Fade
    L6_185()
    L6_185 = Map_SetTalk
    L7_186 = "script/main_scenario/ch04_NendoWorld_main01/talk_01.lbn"
    L6_185(L7_186)
    L6_185 = Npc_SetPosition
    L7_186 = 4
    L8_187 = -3
    L6_185(L7_186, L8_187, 0, -5.99)
    L6_185 = Npc_SetRotateY
    L7_186 = 4
    L8_187 = -52
    L6_185(L7_186, L8_187)
    L6_185 = Camera_SetRotate
    L7_186 = 226
    L6_185(L7_186)
    L6_185 = Camera_SetFov
    L7_186 = 15
    L6_185(L7_186)
    L6_185 = Camera_SetTargetPosition
    L7_186 = -3.99
    L8_187 = 0.33
    L6_185(L7_186, L8_187, -4.31)
    L6_185 = FadeIn
    L7_186 = 16
    L6_185(L7_186)
    L6_185 = Wait_Fade
    L6_185()
    L6_185 = fc_SetCommonMotion
    L7_186 = 1
    L8_187 = 6
    L6_185(L7_186, L8_187, 0.2, true)
    L6_185 = fc_SetCommonMotion
    L7_186 = 3
    L8_187 = 0
    L6_185(L7_186, L8_187, 0.2, true)
    L6_185 = Npc_ShowPopupIcon
    L7_186 = 1
    L8_187 = 4
    L6_185(L7_186, L8_187)
    L6_185 = Npc_ShowPopupIconSilent
    L7_186 = 3
    L8_187 = 4
    L6_185(L7_186, L8_187)
    L6_185 = Message_WindowOpen
    L7_186 = 1
    L6_185(L7_186)
    L6_185 = Wait_MessageWindow
    L6_185()
    L6_185 = PlaySE
    L7_186 = 33554465
    L6_185(L7_186)
    L6_185 = SetMes
    L7_186 = "MES_98"
    L8_187 = "[COL SYS_CHR]\227\131\169\227\130\164\227\131\128\227\131\188[COL SYS_DEF]\227\129\140\228\187\178\233\150\147\227\129\171\227\129\170\227\129\163\227\129\159!"
    L6_185(L7_186, L8_187)
    L6_185 = Message_WindowClose
    L6_185()
    L6_185 = Message_Clear
    L6_185()
    L6_185 = Wait_MessageWindow
    L6_185()
    L6_185 = FadeOut
    L7_186 = 16
    L6_185(L7_186)
    L6_185 = Wait_Fade
    L6_185()
    L6_185 = Player_SetVisible
    L7_186 = true
    L6_185(L7_186)
    L6_185 = Npc_HidePopupIcon
    L7_186 = 1
    L6_185(L7_186)
    L6_185 = Npc_HidePopupIcon
    L7_186 = 2
    L6_185(L7_186)
    L6_185 = Npc_HidePopupIcon
    L7_186 = 3
    L6_185(L7_186)
    L6_185 = Npc_HidePopupIcon
    L7_186 = 0
    L6_185(L7_186)
    L6_185 = Npc_Delete
    L7_186 = 1
    L6_185(L7_186)
    L6_185 = Npc_Delete
    L7_186 = 2
    L6_185(L7_186)
    L6_185 = Npc_Delete
    L7_186 = 3
    L6_185(L7_186)
    L6_185 = Npc_Delete
    L7_186 = 0
    L6_185(L7_186)
    L6_185 = Npc_Delete
    L7_186 = 4
    L6_185(L7_186)
    L6_185 = OnLocalFlag
    L7_186 = 32
    L6_185(L7_186)
    L6_185 = Camera_SetMode
    L7_186 = 0
    L6_185(L7_186)
    L6_185 = Camera_MapRestore
    L6_185()
    L6_185 = AddPartyMember
    L7_186 = 5
    L8_187 = true
    L6_185(L7_186, L8_187, true)
    L6_185 = Wait_Load
    L6_185()
    L6_185 = FadeIn
    L7_186 = 16
    L6_185(L7_186)
    L6_185 = Wait_Fade
    L6_185()
  end
end
