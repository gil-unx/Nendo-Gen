local L0_0
L0_0 = {
  0,
  2,
  7,
  12,
  5,
  -1
}
cool_type = L0_0
L0_0 = {
  {
    0,
    255,
    255,
    0,
    0
  },
  {
    8,
    255,
    255,
    0,
    0
  },
  {
    16777329,
    255,
    255,
    0,
    0
  },
  {
    16777401,
    9,
    0,
    0,
    0
  },
  {
    16777404,
    1,
    0,
    2,
    2
  },
  {
    16777405,
    255,
    255,
    0,
    0
  },
  {
    16777406,
    255,
    255,
    0,
    0
  },
  {
    16777407,
    255,
    255,
    0,
    0
  },
  {
    16777408,
    3,
    3,
    2,
    2
  },
  {
    16777409,
    255,
    255,
    0,
    0
  },
  {
    16777410,
    9,
    6,
    2,
    2
  },
  {
    16777411,
    255,
    255,
    0,
    0
  },
  {
    16777414,
    255,
    255,
    2,
    2
  },
  {
    16777412,
    255,
    255,
    2,
    2
  },
  {
    16777415,
    255,
    255,
    2,
    2
  },
  {
    16777413,
    255,
    255,
    2,
    2
  },
  {
    16777399,
    255,
    255,
    0,
    0
  },
  {
    16777402,
    255,
    255,
    2,
    2
  },
  {
    16777403,
    255,
    255,
    0,
    0
  },
  {
    16777418,
    0,
    1,
    2,
    0
  },
  {
    16777419,
    255,
    255,
    0,
    0
  },
  {
    16777420,
    0,
    1,
    2,
    2
  },
  {
    16777314,
    0,
    0,
    2,
    2
  },
  {
    16777315,
    2,
    0,
    2,
    2
  },
  {
    16777423,
    2,
    3,
    0,
    0
  },
  {
    16777424,
    255,
    255,
    0,
    0
  },
  {
    16777427,
    2,
    2,
    0,
    0
  },
  {
    16777428,
    255,
    255,
    0,
    0
  },
  {
    16777429,
    2,
    2,
    2,
    2
  },
  {
    16777430,
    255,
    255,
    0,
    0
  },
  {
    16777431,
    255,
    255,
    0,
    0
  },
  {
    16777432,
    255,
    255,
    0,
    0
  },
  {
    16777433,
    2,
    4,
    2,
    2
  },
  {
    -1,
    -1,
    -1,
    -1,
    -1
  }
}
motion_set = L0_0
L0_0 = {
  {
    0,
    255,
    255,
    0,
    0
  },
  {
    8,
    255,
    255,
    0,
    0
  },
  {
    16777329,
    255,
    255,
    0,
    0
  },
  {
    16777401,
    255,
    255,
    0,
    0
  },
  {
    16777404,
    255,
    255,
    2,
    2
  },
  {
    16777405,
    255,
    255,
    0,
    0
  },
  {
    16777406,
    255,
    255,
    0,
    0
  },
  {
    16777407,
    255,
    255,
    0,
    0
  },
  {
    16777408,
    1,
    0,
    2,
    2
  },
  {
    16777409,
    255,
    255,
    0,
    0
  },
  {
    16777410,
    1,
    0,
    2,
    2
  },
  {
    16777411,
    255,
    255,
    0,
    0
  },
  {
    16777414,
    255,
    255,
    2,
    2
  },
  {
    16777412,
    255,
    255,
    2,
    2
  },
  {
    16777415,
    255,
    255,
    2,
    2
  },
  {
    16777413,
    255,
    255,
    2,
    2
  },
  {
    16777399,
    255,
    255,
    0,
    0
  },
  {
    16777402,
    255,
    255,
    2,
    2
  },
  {
    16777403,
    255,
    255,
    0,
    0
  },
  {
    16777418,
    0,
    1,
    2,
    0
  },
  {
    16777419,
    255,
    255,
    0,
    0
  },
  {
    16777420,
    0,
    1,
    2,
    2
  },
  {
    16777314,
    0,
    0,
    2,
    2
  },
  {
    16777315,
    2,
    0,
    2,
    2
  },
  {
    16777423,
    2,
    3,
    0,
    0
  },
  {
    16777424,
    255,
    255,
    0,
    0
  },
  {
    16777427,
    2,
    2,
    0,
    0
  },
  {
    16777428,
    255,
    255,
    0,
    0
  },
  {
    16777429,
    2,
    2,
    2,
    2
  },
  {
    16777430,
    255,
    255,
    0,
    0
  },
  {
    16777431,
    255,
    255,
    0,
    0
  },
  {
    16777432,
    255,
    255,
    0,
    0
  },
  {
    16777433,
    2,
    4,
    2,
    2
  },
  {
    -1,
    -1,
    -1,
    -1,
    -1
  }
}
motion_cool_set = L0_0
L0_0 = {
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      10,
      0,
      1,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      12,
      2,
      4,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      14,
      9,
      6,
      2,
      2
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      9,
      8,
      3,
      2,
      2
    }
  },
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      16,
      2,
      1,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      18,
      2,
      4,
      0,
      3
    }
  },
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      20,
      2,
      2,
      0,
      0
    }
  },
  {
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      22,
      2,
      0,
      0,
      0
    }
  }
}
char_set = L0_0
L0_0 = {
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      11,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      13,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      15,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      0,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      17,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      19,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      21,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      23,
      255,
      255,
      0,
      0
    }
  }
}
char_reset = L0_0
function L0_0(A0_1)
  local L1_2, L2_3
  L1_2 = DPRINT
  L2_3 = "fc_TreasureFunc()"
  L1_2(L2_3)
  L1_2 = AddTreasure
  L2_3 = A0_1
  L1_2 = L1_2(L2_3)
  L2_3 = A0_1
  Model_SetMotion(L2_3, 1, 0, false)
  Wait_ModelMotion(L2_3)
  Message_WindowOpen(1)
  Wait_MessageWindow()
  if L1_2 == true then
    PlaySE(16777222)
    SetMes("TRE_000", "[COL SYS_NAM][STR TREASURE_NAME][COL SYS_DEF]\227\130\146\230\137\139\227\129\171\229\133\165\227\130\140\227\129\190\227\129\151\227\129\159\227\128\130\n")
  else
    SetMes("TRE_001", "[COL SYS_NAM][STR TREASURE_NAME][COL SYS_DEF]\227\130\146\232\166\139\227\129\164\227\129\145\227\129\190\227\129\151\227\129\159\227\128\130\n\226\128\166\227\129\151\227\129\139\227\129\151\227\128\129\227\129\147\227\129\174\227\130\162\227\130\164\227\131\134\227\131\160\227\129\175\227\130\130\227\129\134\230\140\129\227\129\161\229\136\135\227\130\140\227\129\190\227\129\155\227\130\147\227\128\130")
  end
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if L1_2 == false then
    Model_SetMotion(L2_3, 0, 1, false)
    Wait_ModelMotion(L2_3)
  end
end
fc_TreasureFunc = L0_0
function L0_0()
  Message_WindowOpen(1)
  Wait_MessageWindow()
  SetMes("EXT_000", "\227\131\158\227\131\131\227\131\151\227\129\174\229\164\150\227\129\171\229\135\186\227\129\190\227\129\153\227\129\140\227\130\136\227\130\141\227\129\151\227\129\132\227\129\167\227\129\153\227\129\139\239\188\159")
  Message_SetBranch("\227\129\175\227\129\132", "\227\129\132\227\129\132\227\129\136", 1)
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if Message_GetBranchResult() == 0 then
    OffSystemFlag(0)
    OffSystemFlag(2)
    OffSystemFlag(1)
    OffSystemFlag(1)
    Map_ExitToIntermission()
  elseif Message_GetBranchResult() == 1 then
  end
end
fc_ExitFunc = L0_0
function L0_0()
  local L0_4, L1_5, L2_6, L3_7, L4_8, L5_9, L6_10, L7_11, L8_12, L9_13, L10_14, L11_15, L12_16, L13_17, L14_18, L15_19, L16_20
  L0_4 = {
    L1_5,
    L2_6,
    L3_7,
    L4_8,
    L5_9,
    L6_10,
    L7_11,
    L8_12
  }
  L1_5 = -90
  L2_6 = -45
  L3_7 = 0
  L4_8 = 45
  L5_9 = 90
  L6_10 = 135
  L1_5 = {
    L2_6,
    L3_7,
    L4_8,
    L5_9,
    L6_10,
    L7_11
  }
  L2_6 = -90
  L3_7 = -30
  L4_8 = 30
  L5_9 = 90
  L6_10 = 150
  L2_6 = {
    L3_7,
    L4_8,
    L5_9,
    L6_10
  }
  L3_7 = -90
  L4_8 = 0
  L5_9 = 90
  L6_10 = 180
  L3_7 = 10
  L4_8 = 0
  L5_9 = 0
  L6_10 = 0
  for L10_14 = 4, L3_7 - 1 do
    if L10_14 == 4 then
      L14_18 = 1
      L11_15(L12_16, L13_17, L14_18)
      L11_15(L12_16)
      L14_18 = Particle_SetPosition
      L15_19 = 20
      L16_20 = L11_15
      L14_18(L15_19, L16_20, L12_16, L13_17)
    end
    if L10_14 < 2 then
      for L14_18 = 0, 3 do
        L15_19 = Player_SetRotateY
        L16_20 = L14_18 + 1
        L16_20 = L2_6[L16_20]
        L15_19(L16_20)
        L15_19 = DPRINT
        L16_20 = L14_18 + 1
        L16_20 = L0_4[L16_20]
        L15_19(L16_20)
        L15_19 = Wait_Timer
        L16_20 = 0.1 * L10_14
        L16_20 = 0.3 - L16_20
        L15_19(L16_20)
      end
    elseif L10_14 < 4 then
      for L14_18 = 0, 5 do
        L15_19 = Player_SetRotateY
        L16_20 = L14_18 + 1
        L16_20 = L1_5[L16_20]
        L15_19(L16_20)
        L15_19 = DPRINT
        L16_20 = L14_18 + 1
        L16_20 = L1_5[L16_20]
        L15_19(L16_20)
        L15_19 = Wait_Timer
        L16_20 = L10_14 - 2
        L16_20 = 0.05 * L16_20
        L16_20 = 0.1 - L16_20
        L15_19(L16_20)
      end
    elseif L10_14 < 8 then
      for L14_18 = 0, 7 do
        L15_19 = Player_SetRotateY
        L16_20 = L14_18 + 1
        L16_20 = L0_4[L16_20]
        L15_19(L16_20)
        L15_19 = DPRINT
        L16_20 = L14_18 + 1
        L16_20 = L0_4[L16_20]
        L15_19(L16_20)
        L15_19 = Wait_Timer
        L16_20 = L10_14 - 8
        L16_20 = 0.0025 * L16_20
        L16_20 = 0.01 - L16_20
        L15_19(L16_20)
      end
    else
      for L14_18 = 0, 5 do
        L15_19 = Player_SetRotateY
        L16_20 = L14_18 + 1
        L16_20 = L1_5[L16_20]
        L15_19(L16_20)
        L15_19 = DPRINT
        L16_20 = L14_18 + 1
        L16_20 = L1_5[L16_20]
        L15_19(L16_20)
        L15_19 = Wait_Timer
        L16_20 = 0.01
        L15_19(L16_20)
      end
    end
    L5_9 = L11_15 + L12_16
    L14_18 = L6_10
    L11_15(L12_16, L13_17, L14_18)
  end
  L7_11(L8_12)
  L10_14 = 1
  L7_11(L8_12, L9_13, L10_14, L11_15)
  L7_11()
  L7_11(L8_12)
  L7_11(L8_12)
  L10_14 = 0
  L7_11(L8_12, L9_13, L10_14)
  L7_11(L8_12)
  L7_11()
  L7_11(L8_12)
end
fc_EscapeDungeonFunc = L0_0
function L0_0(A0_21, A1_22, A2_23, A3_24, A4_25, A5_26, A6_27, A7_28, A8_29)
  local L9_30, L10_31, L11_32, L12_33, L13_34, L14_35
  L9_30 = Npc_GetPosition
  L10_31 = A1_22
  L11_32 = L9_30(L10_31)
  L12_33 = Map_SetRoomChangeEventCircle
  L13_34 = A0_21
  L14_35 = L9_30
  L12_33(L13_34, L14_35, L11_32, A2_23, A3_24, A4_25, A5_26, A6_27, A7_28)
  L12_33 = Map_EventCollSetSE
  L13_34 = A0_21
  L14_35 = A8_29
  L12_33(L13_34, L14_35)
end
fc_Map_SetRoomChangeEventNPC = L0_0
function L0_0(A0_36, A1_37, A2_38, A3_39, A4_40, A5_41, A6_42, A7_43, A8_44)
  local L9_45, L10_46, L11_47, L12_48, L13_49, L14_50
  L9_45 = Model_GetPosition
  L10_46 = A1_37
  L11_47 = L9_45(L10_46)
  L12_48 = Map_SetRoomChangeEventCircle
  L13_49 = A0_36
  L14_50 = L9_45
  L12_48(L13_49, L14_50, L11_47, A2_38, A3_39, A4_40, A5_41, A6_42, A7_43)
  L12_48 = Map_EventCollSetSE
  L13_49 = A0_36
  L14_50 = A8_44
  L12_48(L13_49, L14_50)
end
fc_Map_SetRoomChangeEventMDL = L0_0
function L0_0(A0_51, A1_52, A2_53, A3_54, A4_55, A5_56, A6_57, A7_58, A8_59)
  local L9_60, L10_61, L11_62, L12_63, L13_64, L14_65
  L9_60 = Particle_GetPosition
  L10_61 = A1_52
  L11_62 = L9_60(L10_61)
  L12_63 = Map_SetRoomChangeEventCircle
  L13_64 = A0_51
  L14_65 = L9_60
  L12_63(L13_64, L14_65, L11_62, A2_53, A3_54, A4_55, A5_56, A6_57, A7_58)
  L12_63 = Map_EventCollSetSE
  L13_64 = A0_51
  L14_65 = A8_59
  L12_63(L13_64, L14_65)
end
fc_Map_SetRoomChangeEventPTK = L0_0
function L0_0(A0_66, A1_67, A2_68, A3_69)
  local L4_70, L5_71, L6_72, L7_73, L8_74, L9_75
  L4_70 = Particle_GetPosition
  L5_71 = A1_67
  L6_72 = L4_70(L5_71)
  L7_73 = Map_SetCallLuaFuncEventCircle
  L8_74 = A0_66
  L9_75 = L4_70
  L7_73(L8_74, L9_75, L6_72, A3_69, A2_68)
end
fc_Map_SetCallLuaFuncEventCirclePTK = L0_0
function L0_0()
  local L0_76, L1_77, L2_78, L3_79, L4_80
  L0_76 = GetRandomDungeonFloor
  L0_76 = L0_76()
  L0_76 = L0_76 + 1
  L1_77 = DPRINT
  L2_78 = "randomdungeonfloor = "
  L3_79 = L0_76
  L2_78 = L2_78 .. L3_79
  L1_77(L2_78)
  L1_77 = 0
  L2_78 = {
    L3_79,
    L4_80,
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      -1
    },
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      -1
    },
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      -1
    },
    {
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      123,
      130,
      137,
      -1
    },
    {
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      -1
    },
    {
      128,
      135,
      142,
      122,
      129,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      138,
      145,
      125,
      -1
    },
    {
      122,
      129,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      138,
      145,
      125,
      132,
      143,
      146,
      -1
    },
    {
      119,
      120,
      121,
      122,
      123,
      124,
      125,
      126,
      127,
      128,
      129,
      130,
      131,
      132,
      133,
      134,
      135,
      136,
      137,
      138,
      139,
      140,
      141,
      142,
      143,
      144,
      145,
      146,
      -1
    }
  }
  L3_79 = {
    L4_80,
    126,
    133,
    140,
    -1
  }
  L4_80 = 119
  L4_80 = {
    119,
    126,
    133,
    140,
    120,
    127,
    134,
    -1
  }
  if L0_76 == 10 then
    L1_77 = 109
  elseif L0_76 == 20 then
    L1_77 = 110
  elseif L0_76 == 30 then
    L1_77 = 111
  elseif L0_76 == 40 then
    L1_77 = 112
  elseif L0_76 == 50 then
    L1_77 = 113
  elseif L0_76 == 60 then
    L1_77 = 114
  elseif L0_76 == 70 then
    L1_77 = 115
  elseif L0_76 == 80 then
    L1_77 = 116
  elseif L0_76 == 90 then
    L1_77 = 117
  elseif L0_76 == 100 then
    L1_77 = 118
  else
    L3_79 = 1
    L4_80 = math
    L4_80 = L4_80.floor
    L4_80 = L4_80(L0_76 / 10)
    L4_80 = L4_80 + 1
    DPRINT("tableNo = " .. L4_80)
    while L2_78[L4_80][L3_79] ~= -1 do
      L3_79 = L3_79 + 1
    end
    L1_77 = L2_78[L4_80][Rand_GetInt(L3_79 - 2) + 1]
    DPRINT("area = " .. L1_77)
  end
  return L1_77
end
fc_GetRandomNextArea = L0_0
function L0_0(A0_81, A1_82, A2_83, A3_84)
  local L4_85, L5_86, L6_87, L7_88
  L4_85 = Particle_GetPosition
  L5_86 = A1_82
  L6_87 = L4_85(L5_86)
  L7_88 = fc_GetRandomNextArea
  L7_88 = L7_88()
  Map_SetRoomChangeEventCircle(A0_81, L4_85, L6_87, A2_83, L7_88, 0, 0, 0, 0)
  Map_EventCollSetSE(A0_81, 16777223)
end
fc_Map_SetRandomRoomChangeEventPTK = L0_0
function L0_0()
  local L0_89, L1_90, L2_91, L3_92
  L0_89 = {
    L1_90,
    L2_91,
    L3_92,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  }
  L1_90 = 0
  L2_91 = 1
  L3_92 = 2
  L1_90 = GetRandomDungeonFloor
  L1_90 = L1_90()
  L1_90 = L1_90 + 1
  L2_91 = SetRandomDungeonFloor
  L3_92 = L1_90
  L2_91(L3_92)
  L2_91 = math
  L2_91 = L2_91.floor
  L3_92 = L1_90 - 1
  L3_92 = L3_92 / 10
  L2_91 = L2_91(L3_92)
  L2_91 = L2_91 + 1
  L3_92 = L0_89[L2_91]
  DPRINT("ambient = " .. L3_92)
  Map_SetMapAmbientType(L3_92)
end
fc_SetRandomMapAmbientType = L0_0
function L0_0()
  FadeOut(16)
  Wait_Fade()
  Player_SetPosition(-1.1, 4.4, 7.8)
  Player_SetRotateY(90)
  Camera_SetMode(0)
  FadeIn(16)
  Wait_Fade()
end
fc_Map_nendotakadai1 = L0_0
function L0_0()
  FadeOut(16)
  Wait_Fade()
  Player_SetPosition(-6.7, 0, 7.8)
  Player_SetRotateY(-90)
  Camera_SetMode(0)
  FadeIn(16)
  Wait_Fade()
end
fc_Map_nendotakadai2 = L0_0
function L0_0(A0_93)
  local L2_94, L3_95, L4_96, L5_97, L6_98, L7_99
  L2_94 = A0_93
  L3_95 = false
  for L7_99 = 0, 100 do
    if cool_type[L7_99] == L2_94 then
      L3_95 = true
      break
    end
    if cool_type[L7_99] == -1 then
      break
    end
  end
  return L3_95
end
fc_IsCoolType = L0_0
function L0_0(A0_100, A1_101, A2_102, A3_103)
  local L4_104, L5_105, L6_106, L7_107, L8_108, L9_109
  L4_104 = -1
  L5_105 = -1
  L6_106 = -1
  L7_107 = -1
  L8_108 = -1
  L9_109 = Npc_GetCharID
  L9_109 = L9_109(A0_100)
  for _FORV_14_ = 1, 1000 do
    if motion_set[_FORV_14_][1] == A1_101 then
      if fc_IsCoolType(L9_109) == true then
        L4_104 = motion_cool_set[_FORV_14_][1]
        L5_105 = motion_cool_set[_FORV_14_][2]
        L6_106 = motion_cool_set[_FORV_14_][3]
        L7_107 = motion_cool_set[_FORV_14_][4]
        L8_108 = motion_cool_set[_FORV_14_][5]
        break
      end
      L4_104 = motion_set[_FORV_14_][1]
      L5_105 = motion_set[_FORV_14_][2]
      L6_106 = motion_set[_FORV_14_][3]
      L7_107 = motion_set[_FORV_14_][4]
      L8_108 = motion_set[_FORV_14_][5]
      break
    end
    if motion_set[_FORV_14_][1] == -1 then
      break
    end
  end
  if L4_104 ~= -1 then
    Npc_SetMotion(A0_100, L4_104, A2_102, A3_103)
    Npc_SetFace(A0_100, L5_105, L6_106)
    Npc_SetHand(A0_100, L7_107, L8_108)
    DPRINT("motion_id = " .. A1_101)
  else
    Npc_SetMotion(A0_100, A1_101, A2_102, A3_103)
    DPRINT("**error** " .. A1_101 .. " is no set motion")
  end
end
fc_SetMotionEX = L0_0
function L0_0(A0_110, A1_111, A2_112, A3_113, A4_114)
  local L5_115, L6_116, L7_117, L8_118, L9_119, L10_120, L11_121
  L5_115 = -1
  L6_116 = -1
  L7_117 = -1
  L8_118 = -1
  L9_119 = -1
  L10_120 = A4_114 == nil and true or A4_114
  L11_121 = Actor_GetCharID
  L11_121 = L11_121(A0_110)
  for _FORV_16_ = 1, 1000 do
    if motion_set[_FORV_16_][1] == A1_111 then
      if fc_IsCoolType(L11_121) == true then
        L5_115 = motion_cool_set[_FORV_16_][1]
        L6_116 = motion_cool_set[_FORV_16_][2]
        L7_117 = motion_cool_set[_FORV_16_][3]
        L8_118 = motion_cool_set[_FORV_16_][4]
        L9_119 = motion_cool_set[_FORV_16_][5]
        break
      end
      L5_115 = motion_set[_FORV_16_][1]
      L6_116 = motion_set[_FORV_16_][2]
      L7_117 = motion_set[_FORV_16_][3]
      L8_118 = motion_set[_FORV_16_][4]
      L9_119 = motion_set[_FORV_16_][5]
      break
    end
    if motion_set[_FORV_16_][1] == -1 then
      break
    end
  end
  if L5_115 ~= -1 then
    Actor_SetTalkMotion(A0_110, L5_115, A2_112, A3_113, L10_120)
    Actor_SetEye(A0_110, L6_116)
    Actor_SetMouth(A0_110, L7_117)
    Actor_SetHand(A0_110, L8_118, L9_119)
  else
    Actor_SetTalkMotion(A0_110, A1_111, A2_112, A3_113, L10_120)
    DPRINT("**error** " .. A1_111 .. " is no set motion")
  end
end
fc_SetTalkMotionEX = L0_0
function L0_0(A0_122, A1_123, A2_124, A3_125)
  local L4_126, L5_127, L6_128, L7_129, L8_130
  L4_126 = -1
  L5_127 = -1
  L6_128 = -1
  L7_129 = -1
  L8_130 = -1
  for _FORV_13_ = 1, 1000 do
    if char_set[A1_123 + 1][_FORV_13_][1] == Npc_GetCharID(A0_122) or char_set[A1_123 + 1][_FORV_13_][1] == -1 then
      L4_126 = char_set[A1_123 + 1][_FORV_13_][2]
      L5_127 = char_set[A1_123 + 1][_FORV_13_][3]
      L6_128 = char_set[A1_123 + 1][_FORV_13_][4]
      L7_129 = char_set[A1_123 + 1][_FORV_13_][5]
      L8_130 = char_set[A1_123 + 1][_FORV_13_][6]
      break
    end
  end
  DPRINT("motion_id = " .. L4_126)
  Npc_SetMotion(A0_122, L4_126, A2_124, A3_125)
  Npc_SetFace(A0_122, L5_127, L6_128)
  Npc_SetHand(A0_122, L7_129, L8_130)
end
fc_SetCommonMotion = L0_0
function L0_0(A0_131, A1_132, A2_133, A3_134)
  local L4_135, L5_136, L6_137, L7_138, L8_139
  L4_135 = -1
  L5_136 = -1
  L6_137 = -1
  L7_138 = -1
  L8_139 = -1
  for _FORV_13_ = 1, 1000 do
    if char_reset[A1_132 + 1][_FORV_13_][1] == Npc_GetCharID(A0_131) or char_reset[A1_132 + 1][_FORV_13_][1] == -1 then
      L4_135 = char_reset[A1_132 + 1][_FORV_13_][2]
      L5_136 = char_reset[A1_132 + 1][_FORV_13_][3]
      L6_137 = char_reset[A1_132 + 1][_FORV_13_][4]
      L7_138 = char_reset[A1_132 + 1][_FORV_13_][5]
      L8_139 = char_reset[A1_132 + 1][_FORV_13_][6]
      break
    end
  end
  Npc_SetMotion(A0_131, L4_135, A2_133, A3_134)
  Npc_SetFace(A0_131, L5_136, L6_137)
  Npc_SetHand(A0_131, L7_138, L8_139)
end
fc_EndCommonMotion = L0_0
function L0_0(A0_140, A1_141, A2_142, A3_143, A4_144)
  local L5_145, L6_146, L7_147, L8_148, L9_149, L10_150
  L5_145 = -1
  L6_146 = -1
  L7_147 = -1
  L8_148 = -1
  L9_149 = -1
  L10_150 = A4_144 == nil and true or A4_144
  for _FORV_15_ = 1, 1000 do
    if char_set[A1_141 + 1][_FORV_15_][1] == Actor_GetCharID(A0_140) or char_set[A1_141 + 1][_FORV_15_][1] == -1 then
      L5_145 = char_set[A1_141 + 1][_FORV_15_][2]
      L6_146 = char_set[A1_141 + 1][_FORV_15_][3]
      L7_147 = char_set[A1_141 + 1][_FORV_15_][4]
      L8_148 = char_set[A1_141 + 1][_FORV_15_][5]
      L9_149 = char_set[A1_141 + 1][_FORV_15_][6]
      break
    end
  end
  Actor_SetTalkMotion(A0_140, L5_145, A2_142, A3_143, L10_150)
  Actor_SetEye(A0_140, L6_146)
  Actor_SetMouth(A0_140, L7_147)
  Actor_SetHand(A0_140, L8_148, L9_149)
  DPRINT("ID " .. L5_145)
end
fc_SetCommonTalkMotion = L0_0
function L0_0(A0_151, A1_152, A2_153, A3_154, A4_155)
  local L5_156, L6_157, L7_158, L8_159, L9_160, L10_161
  L5_156 = -1
  L6_157 = -1
  L7_158 = -1
  L8_159 = -1
  L9_160 = -1
  L10_161 = A4_155 == nil and true or A4_155
  for _FORV_15_ = 1, 1000 do
    if char_reset[A1_152 + 1][_FORV_15_][1] == Actor_GetCharID(A0_151) or char_reset[A1_152 + 1][_FORV_15_][1] == -1 then
      L5_156 = char_reset[A1_152 + 1][_FORV_15_][2]
      L6_157 = char_reset[A1_152 + 1][_FORV_15_][3]
      L7_158 = char_reset[A1_152 + 1][_FORV_15_][4]
      L8_159 = char_reset[A1_152 + 1][_FORV_15_][5]
      L9_160 = char_reset[A1_152 + 1][_FORV_15_][6]
      break
    end
  end
  Actor_SetTalkMotion(A0_151, L5_156, A2_153, A3_154, L10_161)
  Actor_SetEye(A0_151, L6_157)
  Actor_SetMouth(A0_151, L7_158)
  Actor_SetHand(A0_151, L8_159, L9_160)
  DPRINT("ID " .. L5_156)
end
fc_EndCommonTalkMotion = L0_0
function L0_0(A0_162, A1_163, A2_164, A3_165)
  while true do
    Map_SetEncount(A0_162, A1_163, false)
    if GetBattleResult() == 3 then
      BGFilterFadeOut(0.1)
      Wait_BGFilterFade()
      FadeIn(16)
      Wait_Fade()
      if A3_165 == true then
        Message_WindowSystemOpen()
      else
        Message_WindowOpen(1)
      end
      Wait_MessageWindow()
      SetMes("BTL_00", "[TALK ]\230\136\166\233\151\152\227\130\146\227\130\132\227\130\138\231\155\180\227\129\151\227\129\190\227\129\153\227\128\130")
      Message_WindowClose()
      Message_Clear()
      Wait_MessageWindow()
      FadeOut(16)
      Wait_Fade()
      BGFilterFadeIn(0.1)
      Wait_BGFilterFade()
    else
      break
    end
  end
  if A2_164 == true then
    FadeIn(16)
    Wait_Fade()
  end
end
fc_Map_SetEncountLoop = L0_0
function L0_0(A0_166, A1_167, A2_168)
  local L3_169
  L3_169 = Search_MsgChar
  L3_169 = L3_169(A1_167, A2_168)
  fc_CharBranch(A0_166, L3_169)
end
fc_SetMesBranch = L0_0
function L0_0()
  local L0_170, L1_171, L2_172, L3_173, L4_174, L5_175, L6_176
  L0_170 = 10
  L1_171 = Particle_Create
  L2_172 = 20
  L3_173 = 0
  L1_171(L2_172, L3_173, L4_174)
  L1_171 = PlaySE
  L2_172 = 16777237
  L1_171(L2_172)
  L1_171 = Player_GetPosition
  L3_173 = L1_171()
  L4_174(L5_175, L6_176, L2_172, L3_173)
  for _FORV_7_ = 4, L0_170 - 1 do
    if _FORV_7_ < 8 then
      for _FORV_11_ = 0, 7 do
        L2_172 = L2_172 + 0.002857142857142857 * (_FORV_7_ - 4)
        Player_SetOffsetPosition(0, L2_172, 0)
        Wait_Timer(0.01 - 0.0025 * (_FORV_7_ - 8))
      end
    else
      for _FORV_11_ = 0, 5 do
        L2_172 = L2_172 + 0.005 * (_FORV_7_ - 4)
        Player_SetOffsetPosition(0, L2_172, 0)
        Wait_Timer(0.01)
      end
    end
  end
  L4_174(L5_175, L6_176, 1, 1)
  L4_174()
  L4_174(L5_175)
  L4_174(L5_175, L6_176, 0)
  L4_174(L5_175)
  L4_174(L5_175)
  L4_174(L5_175)
  L4_174()
  L4_174(L5_175)
  L4_174(L5_175)
end
fc_SetClearEvent = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::section_end_func")
  InvalidTimer(0)
  InvalidTimer(1)
  StopVoice()
  Chara_HidePopupIcon(0)
  if Chara_IsLoopMotion(0) == 0 and Chara_IsMotionEnd(0) == 0 then
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
  end
  CharaFace_Default(0)
  Chara_SetWeapon(0, 0)
  if Chara_SetRecoveryMotion(0, 0.4) == 1 then
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    Chara_SetRecoveryEndMotion(0, 0.4)
  end
  if Chara_SetRecoveryMotion(0, 0.4) == 1 then
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    Chara_SetRecoveryEndMotion(0, 0.4)
  end
  if Chara_IsSleeping(0) == 1 then
    Chara_WakeUp(0)
  end
  if Chara_IsSitting(0) == 1 then
    Chara_Stand(0)
    Chara_SitOptionMotion(0, 0, 0.4)
    PlayNdchSE(50331652)
  end
  Chara_SetMotion(0, 0, 0.4, 1)
  return 0
end
section_end_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_cmn")
end
init_random_cmn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_cmn")
  section_end_func()
end
start_random_cmn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_cmn")
end
update_random_cmn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_wander_yawn")
  Chara_SetPosition(0, 0, 0, 0)
  Chara_SetRotateY(0, 0)
end
init_random_wander_yawn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_wander_yawn")
end
start_random_wander_yawn = L0_0
function L0_0()
  local L0_177, L1_178, L2_179, L3_180, L4_181
  L0_177 = Debug_DrawMes
  L1_178 = "ndch_random.luc::update_random_wander_yawn"
  L0_177(L1_178)
  L0_177 = Chara_IsMoving
  L1_178 = 0
  L0_177 = L0_177(L1_178)
  L1_178 = Chara_IsLoopMotion
  L2_179 = 0
  L1_178 = L1_178(L2_179)
  if L0_177 == 0 then
    L2_179 = Rand_GetInt
    L3_180 = 0
    L4_181 = 3
    L2_179 = L2_179(L3_180, L4_181)
    if L2_179 ~= 3 or L1_178 == 0 then
      L3_180 = Rand_GetFloat
      L4_181 = -2
      L3_180 = L3_180(L4_181, 2)
      L4_181 = Rand_GetFloat
      L4_181 = L4_181(-1, 1.5)
      Chara_SetMovePoints(0, 0.03, 0, L3_180, 0, L4_181)
    else
      L3_180 = CharaFace_Custom
      L4_181 = 0
      L3_180(L4_181, 3, 4)
      L3_180 = Chara_SetMotion
      L4_181 = 0
      L3_180(L4_181, 19, 0.4, 0)
      L3_180 = Wait_CharaMotion
      L4_181 = 0
      L3_180(L4_181)
      L3_180 = Suspend
      L3_180 = L3_180()
      if L3_180 == -1 then
        L3_180 = -1
        return L3_180
      end
      L3_180 = CharaFace_Default
      L4_181 = 0
      L3_180(L4_181)
    end
  end
end
update_random_wander_yawn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_wander_look")
  Chara_SetPosition(0, 0, 0, 0)
  Chara_SetRotateY(0, 0)
end
init_random_wander_look = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_wander_look")
end
start_random_wander_look = L0_0
function L0_0()
  local L0_182, L1_183, L2_184, L3_185, L4_186, L5_187
  L0_182 = Debug_DrawMes
  L1_183 = "ndch_random.luc::update_random_wander_look"
  L0_182(L1_183)
  L0_182 = Chara_IsMoving
  L1_183 = 0
  L0_182 = L0_182(L1_183)
  L1_183 = Chara_IsLoopMotion
  L2_184 = 0
  L1_183 = L1_183(L2_184)
  L2_184 = 1
  if L1_183 == 0 then
    L3_185 = Chara_IsMotionEnd
    L4_186 = 0
    L3_185 = L3_185(L4_186)
    L2_184 = L3_185
  end
  if L0_182 == 0 and L2_184 == 1 then
    L3_185 = Rand_GetInt
    L4_186 = 0
    L5_187 = 3
    L3_185 = L3_185(L4_186, L5_187)
    if L3_185 ~= 3 or L1_183 == 0 then
      L4_186 = Rand_GetFloat
      L5_187 = -2
      L4_186 = L4_186(L5_187, 2)
      L5_187 = Rand_GetFloat
      L5_187 = L5_187(-1, 1.5)
      Chara_SetMovePoints(0, 0.03, 0, L4_186, 0, L5_187)
    else
      L4_186 = Rand_GetInt
      L5_187 = 0
      L4_186 = L4_186(L5_187, 2)
      if L3_185 == 0 then
        L5_187 = Chara_SetMotion
        L5_187(0, 75, 0.4, 0)
        L5_187 = Wait_CharaMotion
        L5_187(0)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
        L5_187 = Chara_SetMotion
        L5_187(0, 76, 0.4, 1)
        L5_187 = Wait_Timer
        L5_187(0, 1)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
        L5_187 = Chara_SetMotion
        L5_187(0, 77, 0.4, 0)
        L5_187 = Wait_CharaMotion
        L5_187(0)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
      elseif L3_185 == 1 then
        L5_187 = Chara_SetMotion
        L5_187(0, 72, 0.4, 0)
        L5_187 = Wait_CharaMotion
        L5_187(0)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
        L5_187 = Chara_SetMotion
        L5_187(0, 73, 0.4, 1)
        L5_187 = Wait_Timer
        L5_187(0, 1)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
        L5_187 = Chara_SetMotion
        L5_187(0, 74, 0.4, 0)
        L5_187 = Wait_CharaMotion
        L5_187(0)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
      else
        L5_187 = Chara_SetMotion
        L5_187(0, 78, 0.4, 0)
        L5_187 = Wait_CharaMotion
        L5_187(0)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
        L5_187 = Chara_SetMotion
        L5_187(0, 79, 0.4, 1)
        L5_187 = Wait_Timer
        L5_187(0, 1)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
        L5_187 = Chara_SetMotion
        L5_187(0, 80, 0.4, 0)
        L5_187 = Wait_CharaMotion
        L5_187(0)
        L5_187 = Suspend
        L5_187 = L5_187()
        if L5_187 == -1 then
          L5_187 = -1
          return L5_187
        end
      end
    end
  end
end
update_random_wander_look = L0_0
function L0_0()
  local L0_188
  L0_188 = Debug_DrawMes
  L0_188("ndch_random.luc::init_random_nap")
  L0_188 = Chara_SetPosition
  L0_188(0, 1, 0, -2)
  L0_188 = Chara_SetRotateY
  L0_188(0, 225)
  L0_188 = Chara_SetMotion
  L0_188(0, 22, 0, 1)
  L0_188 = Chara_Sit
  L0_188(0)
  L0_188 = Chara_SitOptionMotion
  L0_188(0, 1, 0)
  L0_188 = Rand_GetFloat
  L0_188 = L0_188(20, 40)
  SetTimer(0, L0_188)
end
init_random_nap = L0_0
function L0_0()
  local L0_189
  L0_189 = Debug_DrawMes
  L0_189("ndch_random.luc::start_random_nap")
  L0_189 = Chara_SetMovePoints
  L0_189(0, 0.03, 0, 1, 0, -2)
  L0_189 = Wait_CharaMove
  L0_189(0)
  L0_189 = Suspend
  L0_189 = L0_189()
  if L0_189 == -1 then
    L0_189 = -1
    return L0_189
  end
  L0_189 = Chara_SetMoveRotateY
  L0_189(0, 5, 225)
  L0_189 = Wait_CharaMove
  L0_189(0)
  L0_189 = Suspend
  L0_189 = L0_189()
  if L0_189 == -1 then
    L0_189 = -1
    return L0_189
  end
  L0_189 = Chara_Sit
  L0_189(0)
  L0_189 = PlayNdchSE
  L0_189(50331651)
  L0_189 = Chara_SitOptionMotion
  L0_189(0, 1, 0.4)
  L0_189 = Chara_SetMotion
  L0_189(0, 21, 0.4, 0)
  L0_189 = Wait_CharaMotion
  L0_189(0)
  L0_189 = Suspend
  L0_189 = L0_189()
  if L0_189 == -1 then
    L0_189 = -1
    return L0_189
  end
  L0_189 = Chara_SetMotion
  L0_189(0, 22, 0.4, 1)
  L0_189 = Rand_GetFloat
  L0_189 = L0_189(20, 40)
  SetTimer(0, L0_189)
end
start_random_nap = L0_0
function L0_0()
  local L0_190, L1_191, L2_192
  L0_190 = Debug_DrawMes
  L1_191 = "ndch_random.luc::update_random_nap"
  L0_190(L1_191)
  L0_190 = Chara_IsSleeping
  L1_191 = 0
  L0_190 = L0_190(L1_191)
  if L0_190 == 1 then
    L1_191 = Chara_IsShowingPopupIcon
    L2_192 = 0
    L1_191 = L1_191(L2_192)
    if L1_191 == 0 then
      L2_192 = Chara_ExpressPopupIcon
      L2_192(0, 15, 0.2, 3)
    end
  end
  L1_191 = IsTimeUp
  L2_192 = 0
  L1_191 = L1_191(L2_192)
  if L1_191 == 1 then
    if L0_190 == 1 then
      L2_192 = Chara_HidePopupIcon
      L2_192(0)
      L2_192 = Chara_SetMotion
      L2_192(0, 28, 0.4, 0)
      L2_192 = Wait_CharaMotion
      L2_192(0)
      L2_192 = Suspend
      L2_192 = L2_192()
      if L2_192 == -1 then
        L2_192 = -1
        return L2_192
      end
      L2_192 = Chara_SetMotion
      L2_192(0, 22, 0.4, 1)
      L2_192 = Chara_WakeUp
      L2_192(0)
      L2_192 = CharaFace_Default
      L2_192(0)
      L2_192 = Rand_GetFloat
      L2_192 = L2_192(20, 40)
      SetTimer(0, L2_192)
    else
      L2_192 = Chara_SetMotion
      L2_192(0, 27, 0.4, 1)
      L2_192 = Chara_Sleep
      L2_192(0)
      L2_192 = CharaFace_Custom
      L2_192(0, 11, 8)
      L2_192 = SetTimer
      L2_192(0, 8)
    end
  end
end
update_random_nap = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_sit")
  Chara_SetPosition(0, 1, 0, -2)
  Chara_SetRotateY(0, 225)
  Chara_Sit(0)
  Chara_SetMotion(0, 22, 0, 1)
  Chara_SitOptionMotion(0, 1, 0)
  SetTimer(0, 10)
end
init_random_sit = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_sit")
  Chara_SetMovePoints(0, 0.03, 0, 1, 0, -2)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 225)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_Sit(0)
  PlayNdchSE(50331651)
  Chara_SitOptionMotion(0, 1, 0.4)
  Chara_SetMotion(0, 21, 0.4, 0)
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMotion(0, 22, 0.4, 1)
  SetTimer(0, 10)
end
start_random_sit = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_sit")
  if IsTimeUp(0) == 1 then
    Chara_SetMotion(0, 30, 0.4, 0)
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    Chara_SetMotion(0, 22, 0.4, 1)
    SetTimer(0, 10)
  end
end
update_random_sit = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_melancholy_yawn")
  Chara_SetPosition(0, 4, 0, -2)
  Chara_SetRotateY(0, 135)
  SetTimer(0, 10)
end
init_random_melancholy_yawn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_melancholy_yawn")
  Chara_SetMovePoints(0, 0.03, 0, 4, 0, -2)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 135)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  SetTimer(0, 10)
end
start_random_melancholy_yawn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_melancholy_yawn")
  if IsTimeUp(0) == 1 then
    CharaFace_Custom(0, 3, 4)
    Chara_SetMotion(0, 19, 0.4, 0)
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    CharaFace_Default(0)
    SetTimer(0, 10)
  end
end
update_random_melancholy_yawn = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_melancholy_look")
  Chara_SetPosition(0, 4, 0, -2)
  Chara_SetRotateY(0, 135)
  SetTimer(0, 10)
end
init_random_melancholy_look = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_melancholy_look")
  Chara_SetMovePoints(0, 0.03, 0, 4, 0, -2)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 135)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  SetTimer(0, 10)
end
start_random_melancholy_look = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_melancholy_look")
  if IsTimeUp(0) == 1 then
    if Rand_GetInt(0, 1) == 0 then
      Chara_SetMotion(0, 75, 0.4, 0)
      Wait_CharaMotion(0)
      if Suspend() == -1 then
        return -1
      end
      Chara_SetMotion(0, 76, 0.4, 1)
      Wait_Timer(0, 1)
      if Suspend() == -1 then
        return -1
      end
      Chara_SetMotion(0, 77, 0.4, 0)
      Wait_CharaMotion(0)
      if Suspend() == -1 then
        return -1
      end
    else
      Chara_SetMotion(0, 81, 0.4, 0)
      Wait_CharaMotion(0)
      if Suspend() == -1 then
        return -1
      end
      Chara_SetMotion(0, 82, 0.4, 1)
      Wait_Timer(0, 1)
      if Suspend() == -1 then
        return -1
      end
      Chara_SetMotion(0, 83, 0.4, 0)
      Wait_CharaMotion(0)
      if Suspend() == -1 then
        return -1
      end
    end
    SetTimer(0, 10)
  end
end
update_random_melancholy_look = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_blossom_view")
  Chara_SetPosition(0, -1, 0, -1.8)
  Chara_SetRotateY(0, 135)
  Chara_SetMotion(0, 25, 0, 1)
  Chara_Sit(0)
  Chara_SitOptionMotion(0, 1, 0)
  SetTimer(0, 10)
end
init_random_blossom_view = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_blossom_view")
  Chara_SetMovePoints(0, 0.03, 0, -1, 0, -1.8)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 135)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_Sit(0)
  PlayNdchSE(50331651)
  Chara_SitOptionMotion(0, 1, 0.4)
  Chara_SetMotion(0, 21, 0.4, 0)
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMotion(0, 24, 0.4, 0)
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMotion(0, 25, 0.4, 1)
  SetTimer(0, 10)
end
start_random_blossom_view = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_blossom_view")
  if IsTimeUp(0) == 1 then
    SetTimer(0, 10)
    Chara_ExpressPopupIcon(0, 6, 1, 1)
  end
end
update_random_blossom_view = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_swing")
  Chara_SetPosition(0, 0, 0, 0)
  Chara_SetRotateY(0, 315)
  Chara_SetWeapon(0, 1)
  Chara_SetSwingMotion(0, 0)
end
init_random_swing = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_swing")
  Chara_SetMovePoints(0, 0.03, 0, 0, 0, 0)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 315)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetWeapon(0, 1)
  Chara_SetSwingMotion(0, 0.4)
end
start_random_swing = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_swing")
end
update_random_swing = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_dance")
  Chara_SetPosition(0, 0, 0, 0)
  Chara_SetRotateY(0, 0)
end
init_random_dance = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_dance")
end
start_random_dance = L0_0
function L0_0()
  local L0_193, L1_194, L2_195, L3_196, L4_197
  L0_193 = Debug_DrawMes
  L1_194 = "ndch_random.luc::update_random_dance"
  L0_193(L1_194)
  L0_193 = IsValidTimer
  L1_194 = 0
  L0_193 = L0_193(L1_194)
  L1_194 = 0
  if L0_193 == 1 then
    L2_195 = IsTimeUp
    L3_196 = 0
    L2_195 = L2_195(L3_196)
    if L2_195 == 1 then
      L1_194 = 1
      L3_196 = CharaFace_Default
      L4_197 = 0
      L3_196(L4_197)
      L3_196 = InvalidTimer
      L4_197 = 0
      L3_196(L4_197)
    end
  else
    L2_195 = Chara_IsMoving
    L3_196 = 0
    L2_195 = L2_195(L3_196)
    if L2_195 == 0 then
      L1_194 = 1
    end
  end
  if L1_194 == 1 then
    L2_195 = Rand_GetInt
    L3_196 = 0
    L4_197 = 3
    L2_195 = L2_195(L3_196, L4_197)
    if L2_195 ~= 3 then
      L3_196 = Rand_GetFloat
      L4_197 = -2
      L3_196 = L3_196(L4_197, 2)
      L4_197 = Rand_GetFloat
      L4_197 = L4_197(-1, 1.5)
      Chara_SetMovePoints(0, 0.03, 0, L3_196, 0, L4_197)
    else
      L3_196 = Chara_SetMoveRotateY
      L4_197 = 0
      L3_196(L4_197, 5, 0)
      L3_196 = Wait_CharaMove
      L4_197 = 0
      L3_196(L4_197)
      L3_196 = Suspend
      L3_196 = L3_196()
      if L3_196 == -1 then
        L3_196 = -1
        return L3_196
      end
      L3_196 = CharaFace_Custom
      L4_197 = 0
      L3_196(L4_197, 6, 1)
      L3_196 = Rand_GetInt
      L4_197 = 0
      L3_196 = L3_196(L4_197, 5)
      if L3_196 == 0 then
        L4_197 = Chara_SetMotion
        L4_197(0, 58, 0.4, 0)
      elseif L3_196 == 1 then
        L4_197 = Chara_SetMotion
        L4_197(0, 63, 0.4, 0)
      elseif L3_196 == 2 then
        L4_197 = Chara_SetMotion
        L4_197(0, 57, 0.4, 0)
      elseif L3_196 == 3 then
        L4_197 = Chara_SetMotion
        L4_197(0, 59, 0.4, 0)
      elseif L3_196 == 4 then
        L4_197 = Chara_SetMotion
        L4_197(0, 66, 0.4, 0)
      else
        L4_197 = Chara_SetMotion
        L4_197(0, 53, 0.4, 0)
      end
      L4_197 = Chara_IsLoopMotion
      L4_197 = L4_197(0)
      if L4_197 == 1 then
        SetTimer(0, 3)
      else
        Wait_CharaMotion(0)
        if Suspend() == -1 then
          return -1
        end
        if L3_196 == 0 then
          Chara_SetMotion(0, 58, 0.4, 0)
        elseif L3_196 == 1 then
          Chara_SetMotion(0, 63, 0.4, 0)
        elseif L3_196 == 2 then
          Chara_SetMotion(0, 57, 0.4, 0)
        elseif L3_196 == 3 then
          Chara_SetMotion(0, 59, 0.4, 0)
        elseif L3_196 == 4 then
          Chara_SetMotion(0, 66, 0.4, 0)
        else
          Chara_SetMotion(0, 53, 0.4, 0)
        end
        Wait_CharaMotion(0)
        if Suspend() == -1 then
          return -1
        end
        CharaFace_Default(0)
      end
    end
  end
end
update_random_dance = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::init_random_wander_thiking")
  Chara_SetPosition(0, 0, 0, 0)
  Chara_SetRotateY(0, 0)
end
init_random_wander_thinking = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::start_random_wander_thinking")
end
start_random_wander_thinking = L0_0
function L0_0()
  local L0_198, L1_199, L2_200, L3_201, L4_202, L5_203
  L0_198 = Debug_DrawMes
  L1_199 = "ndch_random.luc::update_random_wander_thinking"
  L0_198(L1_199)
  L0_198 = Chara_IsMoving
  L1_199 = 0
  L0_198 = L0_198(L1_199)
  L1_199 = Chara_IsLoopMotion
  L2_200 = 0
  L1_199 = L1_199(L2_200)
  L2_200 = 1
  if L1_199 == 0 then
    L3_201 = Chara_IsMotionEnd
    L4_202 = 0
    L3_201 = L3_201(L4_202)
    L2_200 = L3_201
  end
  if L0_198 == 0 and L2_200 == 1 then
    L3_201 = Rand_GetInt
    L4_202 = 0
    L5_203 = 3
    L3_201 = L3_201(L4_202, L5_203)
    if L3_201 ~= 3 or L1_199 == 0 then
      L4_202 = Rand_GetFloat
      L5_203 = -2
      L4_202 = L4_202(L5_203, 2)
      L5_203 = Rand_GetFloat
      L5_203 = L5_203(-1, 1.5)
      Chara_SetMovePoints(0, 0.03, 0, L4_202, 0, L5_203)
    else
      L4_202 = Chara_SetMotion
      L5_203 = 0
      L4_202(L5_203, 75, 0.4, 0)
      L4_202 = Wait_CharaMotion
      L5_203 = 0
      L4_202(L5_203)
      L4_202 = Suspend
      L4_202 = L4_202()
      if L4_202 == -1 then
        L4_202 = -1
        return L4_202
      end
      L4_202 = Chara_SetMotion
      L5_203 = 0
      L4_202(L5_203, 76, 0.4, 1)
      L4_202 = Chara_ExpressPopupIcon
      L5_203 = 0
      L4_202(L5_203, 2, 0.5, 1)
      L4_202 = Wait_Timer
      L5_203 = 0
      L4_202(L5_203, 2)
      L4_202 = Suspend
      L4_202 = L4_202()
      if L4_202 == -1 then
        L4_202 = -1
        return L4_202
      end
      L4_202 = Rand_GetInt
      L5_203 = 0
      L4_202 = L4_202(L5_203, 3)
      if L4_202 == 0 then
        L5_203 = Chara_ExpressPopupIcon
        L5_203(0, 3, 1, 1)
        L5_203 = CharaFace_Custom
        L5_203(0, 0, 2)
        L5_203 = Wait_Timer
        L5_203(0, 1)
        L5_203 = Suspend
        L5_203 = L5_203()
        if L5_203 == -1 then
          L5_203 = -1
          return L5_203
        end
        L5_203 = CharaFace_Default
        L5_203(0)
        L5_203 = Chara_SetMotion
        L5_203(0, 77, 0.4, 0)
        L5_203 = Wait_CharaMotion
        L5_203(0)
        L5_203 = Suspend
        L5_203 = L5_203()
        if L5_203 == -1 then
          L5_203 = -1
          return L5_203
        end
      else
        L5_203 = Chara_SetMotion
        L5_203(0, 77, 0.4, 0)
        L5_203 = Wait_CharaMotion
        L5_203(0)
        L5_203 = Suspend
        L5_203 = L5_203()
        if L5_203 == -1 then
          L5_203 = -1
          return L5_203
        end
        L5_203 = Chara_ExpressPopupIcon
        L5_203(0, 10, 0.5, 1)
        L5_203 = CharaFace_Custom
        L5_203(0, 1, 0)
        L5_203 = Chara_SetMotion
        L5_203(0, 11, 0.4, 0)
        L5_203 = Wait_CharaMotion
        L5_203(0)
        L5_203 = Suspend
        L5_203 = L5_203()
        if L5_203 == -1 then
          L5_203 = -1
          return L5_203
        end
        L5_203 = CharaFace_Default
        L5_203(0)
      end
    end
  end
end
update_random_wander_thinking = L0_0
function L0_0()
  local L0_204, L1_205
  L0_204 = Debug_DrawMes
  L1_205 = "ndch_random.luc::init_random_sleep"
  L0_204(L1_205)
  L0_204 = Rand_GetFloat
  L1_205 = -2
  L0_204 = L0_204(L1_205, 2)
  L1_205 = Rand_GetFloat
  L1_205 = L1_205(-1, 1.5)
  Chara_SetPosition(0, L0_204, 0, L1_205)
  Chara_SetRotateY(0, 0)
  Chara_SetMotion(0, 4, 0, 1)
  Chara_Sleep(0)
  CharaFace_Custom(0, 11, 8)
  SetTimer(0, 30)
  InvalidTimer(1)
end
init_random_sleep = L0_0
function L0_0()
  local L0_206, L1_207
  L0_206 = Debug_DrawMes
  L1_207 = "ndch_random.luc::start_random_sleep"
  L0_206(L1_207)
  L0_206 = Rand_GetFloat
  L1_207 = -2
  L0_206 = L0_206(L1_207, 2)
  L1_207 = Rand_GetFloat
  L1_207 = L1_207(-1, 1.5)
  Chara_SetMovePoints(0, 0.03, 0, L0_206, 0, L1_207)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 0)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_Sleep(0)
  Chara_SetMotion(0, 3, 0.4, 0)
  PlayNdchSE(50331653)
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMotion(0, 4, 0.4, 1)
  CharaFace_Custom(0, 11, 8)
  SetTimer(0, 30)
  InvalidTimer(1)
end
start_random_sleep = L0_0
function L0_0()
  Debug_DrawMes("ndch_random.luc::update_random_sleep")
  if Chara_IsShowingPopupIcon(0) == 0 then
    Chara_ExpressPopupIcon(0, 15, 0.2, 3)
  end
  if IsTimeUp(1) == 1 and Chara_IsExpressionless(0) == 0 then
    CharaFace_Custom(0, 11, 8)
  end
  if IsTimeUp(0) == 1 then
    SetTimer(0, 30)
    if Rand_GetInt(0, 1) == 0 then
      PlayVoice(19)
      if Chara_IsExpressionless(0) == 0 then
        CharaFace_Custom(0, 6, 8)
      end
    else
      PlayVoice(20)
      if Chara_IsExpressionless(0) == 0 then
        CharaFace_Custom(0, 4, 8)
      end
    end
    SetTimer(1, 10)
  end
end
update_random_sleep = L0_0
function L0_0()
  local L0_208
  L0_208 = Debug_DrawMes
  L0_208("ndch_script.luc::init_func")
  L0_208 = GetWanderTime
  L0_208 = L0_208()
  init_random_cmn()
  if GetWanderPattern(L0_208) == 0 then
    init_random_wander_yawn()
  elseif GetWanderPattern(L0_208) == 1 then
    init_random_wander_look()
  elseif GetWanderPattern(L0_208) == 2 then
    init_random_nap()
  elseif GetWanderPattern(L0_208) == 3 then
    init_random_sit()
  elseif GetWanderPattern(L0_208) == 4 then
    init_random_melancholy_yawn()
  elseif GetWanderPattern(L0_208) == 5 then
    init_random_melancholy_look()
  elseif GetWanderPattern(L0_208) == 6 then
    init_random_blossom_view()
  elseif GetWanderPattern(L0_208) == 7 then
    init_random_swing()
  elseif GetWanderPattern(L0_208) == 8 then
    init_random_dance()
  elseif GetWanderPattern(L0_208) == 9 then
    init_random_wander_thinking()
  elseif GetWanderPattern(L0_208) == 10 then
    init_random_sleep()
  end
  Set_Integer(0, L0_208)
end
init_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::gameover_func")
  Chara_SetPosition(0, 0, 0, 2)
  Chara_SetRotateY(0, 0)
  Wait_EmotionEffect(0)
  if Suspend() == -1 then
    return -1
  end
  if IsExistNonAnnouncedWallPaper() == 1 then
    SetSystemMes_WallPaper()
    Wait_SystemWindow()
    if Suspend() == -1 then
      return -1
    end
    AnnounceWallPaper()
  end
  if IsGameWin() == 1 then
    Chara_SetSituationMotion(0, 1, 0.4)
  else
    Chara_SetSituationMotion(0, 2, 0.4)
  end
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  Mes_WindowOpen()
  Wait_MesWindow()
  if Suspend() == -1 then
    return -1
  end
  if IsGameWin() == 1 then
    SetSituationMes(0, 13)
    PlayVoice(22)
  else
    SetSituationMes(0, 14)
    PlayVoice(21)
  end
  if Suspend() == -1 then
    return -1
  end
  Wait_Voice()
  if Suspend() == -1 then
    return -1
  end
  Mes_WindowClose()
  Mes_Clear()
  Wait_MesWindow()
  if Suspend() == -1 then
    return -1
  end
  Set_Integer(0, -1)
end
gameover_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::gameover_func")
  Chara_SetPosition(0, 0, 0, 2)
  Chara_SetRotateY(0, 0)
end
change_end_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::goodbye_func")
  Chara_FaceCamera(0, 5)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_ExpressPopupIcon(0, 0, 1, 1)
  Chara_SetSituationMotion(0, 0, 0.4)
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_HidePopupIcon(0)
  Mes_WindowOpen()
  Wait_MesWindow()
  if Suspend() == -1 then
    return -1
  end
  SetSituationMes(0, 16)
  PlayVoice(1)
  if Suspend() == -1 then
    return -1
  end
  Wait_Voice()
  if Suspend() == -1 then
    return -1
  end
  Mes_WindowClose()
  Mes_Clear()
  Wait_MesWindow()
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMotion(0, 48, 0.4, 1)
  Wait_Timer(0, 1)
  if Suspend() == -1 then
    return -1
  end
end
goodbye_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::call_func()")
  Chara_FaceCamera(0, 5)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_ExpressPopupIcon_Emotion(0, 1, 1)
  CharaFace_Emotion(0)
  Chara_SetMotion_Emotion(0, 0.4)
  Wait_CharaMotion(0)
  if Suspend() == -1 then
    return -1
  end
  CharaFace_Default(0)
  if Chara_GetEmotionState(0) == 4 then
    Chara_SetMovePoints(0, 0.075, 1, 0, 0, 2)
  elseif Chara_GetEmotionState(0) == 3 then
    Chara_SetMovePoints(0, 0.06, 1, 0, 0, 2)
  elseif Chara_GetEmotionState(0) == 2 then
    Chara_SetMovePoints(0, 0.045, 0, 0, 0, 2)
  elseif Chara_GetEmotionState(0) == 1 then
    Chara_SetMovePoints(0, 0.03, 0, 0, 0, 2)
  elseif Chara_GetEmotionState(0) == 0 then
    Chara_SetMovePoints(0, 0.015, 0, 0, 0, 2)
  end
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  Chara_SetMoveRotateY(0, 5, 0)
  Wait_CharaMove(0)
  if Suspend() == -1 then
    return -1
  end
  SetDefaultCamera()
  Wait_CameraMove()
  if Suspend() == -1 then
    return -1
  end
  if Chara_GetEmotionState(0) == 4 and IsPresentTimeCome() == 1 then
    GetPresent()
    Chara_ExpressPopupIcon(0, 6, 1, 1)
    CharaFace_Situation(0, 1)
    Chara_SetMotion(0, 7, 0.4, 0)
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    Chara_SetMotion(0, 8, 0.4, 1)
    PlayNdchSE(50331654)
    Chara_HidePopupIcon(0)
    Mes_WindowOpen()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
    SetSituationMes(0, 15)
    PlayVoice(16)
    if Suspend() == -1 then
      return -1
    end
    Wait_Voice()
    if Suspend() == -1 then
      return -1
    end
    Mes_WindowClose()
    Mes_Clear()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
    SetSystemMes_Present()
    Wait_SystemWindow()
    if Suspend() == -1 then
      return -1
    end
    Chara_SetMotion(0, 9, 0.4, 0)
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
  else
    CharaFace_Emotion(0)
    if Chara_GetEmotionState(0) == 4 then
      Chara_SetMotion(0, 13, 0.4, 0)
    elseif Chara_GetEmotionState(0) == 3 then
      Chara_SetMotion(0, 20, 0.4, 0)
    elseif Chara_GetEmotionState(0) == 2 then
      Chara_SetMotion(0, 20, 0.4, 0)
    elseif Chara_GetEmotionState(0) == 1 then
      Chara_SetMotion(0, 0, 0.4, 1)
    elseif Chara_GetEmotionState(0) == 0 then
      Chara_SetMotion(0, 0, 0.4, 1)
    end
    Mes_WindowOpen()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
    if Chara_GetEmotionState(0) == 4 then
      SetSituationMes(0, 0)
    elseif Chara_GetEmotionState(0) == 3 then
      SetSituationMes(0, 1)
    elseif Chara_GetEmotionState(0) == 2 then
      SetSituationMes(0, 2)
    elseif Chara_GetEmotionState(0) == 1 then
      SetSituationMes(0, 3)
    elseif Chara_GetEmotionState(0) == 0 then
      SetSituationMes(0, 4)
    end
    PlayVoice(0)
    if Suspend() == -1 then
      return -1
    end
    Wait_Voice()
    if Suspend() == -1 then
      return -1
    end
    Mes_WindowClose()
    Mes_Clear()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
  end
  CharaFace_Default(0)
end
call_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::back_func()")
  section_end_func()
end
back_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::talk_func()")
  Chara_SetMotion(0, 20, 0.4, 0)
  Mes_WindowOpen()
  Wait_MesWindow()
  if Suspend() == -1 then
    return -1
  end
  if Chara_GetEmotionState(0) == 4 then
    SetSituationMes(0, 5)
  elseif Chara_GetEmotionState(0) == 3 then
    SetSituationMes(0, 6)
  elseif Chara_GetEmotionState(0) == 2 then
    SetSituationMes(0, 7)
  elseif Chara_GetEmotionState(0) == 1 then
    SetSituationMes(0, 8)
  elseif Chara_GetEmotionState(0) == 0 then
    SetSituationMes(0, 9)
  end
  if Suspend() == -1 then
    return -1
  end
  Mes_WindowClose()
  Mes_Clear()
  Wait_MesWindow()
  if Suspend() == -1 then
    return -1
  end
end
talk_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::wait_init_func")
end
wait_init_func = L0_0
function L0_0()
  local L0_209, L1_210, L2_211, L3_212
  L0_209 = Debug_DrawMes
  L1_210 = "ndch_script.luc::wait_update_func"
  L0_209(L1_210)
  L0_209 = Get_Integer
  L1_210 = 0
  L0_209 = L0_209(L1_210)
  L1_210 = nil
  L2_211 = GetWanderTime
  L2_211 = L2_211()
  L1_210 = L2_211
  L2_211 = GetWanderPattern
  L3_212 = L1_210
  L2_211 = L2_211(L3_212)
  if L0_209 ~= L1_210 then
    L3_212 = section_end_func
    L3_212 = L3_212()
    Debug_SetBreakPoint(L3_212)
    if L3_212 == -1 and Suspend() == -1 then
      return -1
    end
    if L2_211 == 0 then
      start_random_wander_yawn()
    elseif L2_211 == 1 then
      start_random_wander_look()
    elseif L2_211 == 2 then
      start_random_nap()
    elseif L2_211 == 3 then
      start_random_sit()
    elseif L2_211 == 4 then
      start_random_melancholy_yawn()
    elseif L2_211 == 5 then
      start_random_melancholy_look()
    elseif L2_211 == 6 then
      start_random_blossom_view()
    elseif L2_211 == 7 then
      start_random_swing()
    elseif L2_211 == 8 then
      start_random_dance()
    elseif L2_211 == 9 then
      start_random_wander_thinking()
    elseif L2_211 == 10 then
      start_random_sleep()
    end
  else
    L3_212 = update_random_cmn
    L3_212()
    if L2_211 == 0 then
      L3_212 = update_random_wander_yawn
      L3_212()
    elseif L2_211 == 1 then
      L3_212 = update_random_wander_look
      L3_212()
    elseif L2_211 == 2 then
      L3_212 = update_random_nap
      L3_212()
    elseif L2_211 == 3 then
      L3_212 = update_random_sit
      L3_212()
    elseif L2_211 == 4 then
      L3_212 = update_random_melancholy_yawn
      L3_212()
    elseif L2_211 == 5 then
      L3_212 = update_random_melancholy_look
      L3_212()
    elseif L2_211 == 6 then
      L3_212 = update_random_blossom_view
      L3_212()
    elseif L2_211 == 7 then
      L3_212 = update_random_swing
      L3_212()
    elseif L2_211 == 8 then
      L3_212 = update_random_dance
      L3_212()
    elseif L2_211 == 9 then
      L3_212 = update_random_wander_thinking
      L3_212()
    elseif L2_211 == 10 then
      L3_212 = update_random_sleep
      L3_212()
    end
  end
  L3_212 = Set_Integer
  L3_212(0, L1_210)
end
wait_update_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::wait_exit_func")
  section_end_func()
  Set_Integer(0, -1)
end
wait_exit_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::communication_init_func")
  SetTimer(0, 5)
end
communication_init_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::communication_update_func()")
  if IsTimeUp(0) == 1 then
    if Rand_GetInt(0, 1) == 0 then
      Chara_SetSituationMotion(0, 5, 0.4)
      PlayVoice(18)
      Mes_WindowOpen()
      Wait_MesWindow()
      if Suspend() == -1 then
        return -1
      end
      SetSituationMes(0, 10)
    else
      Chara_SetSituationMotion(0, 6, 0.4)
      PlayVoice(13)
      Mes_WindowOpen()
      Wait_MesWindow()
      if Suspend() == -1 then
        return -1
      end
      SetSituationMes(0, 11)
    end
    if Suspend() == -1 then
      return -1
    end
    Wait_Voice()
    if Suspend() == -1 then
      return -1
    end
    Mes_WindowClose()
    Mes_Clear()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    SetTimer(0, 5)
    CharaFace_Default(0)
  end
end
communication_update_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::communication_exit_func")
  InvalidTimer(0)
end
communication_exit_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::minigame_init_func")
  SetTimer(0, 5)
end
minigame_init_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::minigame_update_func()")
  if IsTimeUp(0) == 1 then
    Chara_SetMotion(0, 20, 0.4, 0)
    Mes_WindowOpen()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
    SetSituationMes(0, 12)
    if Suspend() == -1 then
      return -1
    end
    Mes_WindowClose()
    Mes_Clear()
    Wait_MesWindow()
    if Suspend() == -1 then
      return -1
    end
    SetTimer(0, 5)
  end
end
minigame_update_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::minigame_exit_func")
  InvalidTimer(0)
end
minigame_exit_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::viewer_init_func")
  SetTimer(0, 30)
  SetTimer(1, 45)
end
viewer_init_func = L0_0
function L0_0()
  local L0_213
  L0_213 = Debug_DrawMes
  L0_213("ndch_script.luc::viewer_update_func()")
  L0_213 = Chara_SetViewerRareMotion
  L0_213 = L0_213(0, 0.4)
  if L0_213 >= 0 then
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    if L0_213(0, 0.4) == 0 then
      Chara_SetMotion(0, 0, 0.4, 1)
      Wait_Timer(0, 2)
      if Suspend() == -1 then
        return -1
      end
    end
    Chara_SetMotion(0, L0_213, 0.4, 0)
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    CharaFace_Default(0)
    Chara_SetMotion(0, 0, 0.4, 1)
    SetTimer(0, 30)
  end
  if IsTimeUp(0) == 1 then
    Chara_SetViewerNormalMotion(0, 0.4)
    Wait_CharaMotion(0)
    if Suspend() == -1 then
      return -1
    end
    CharaFace_Default(0)
    Chara_SetMotion(0, 0, 0.4, 1)
    SetTimer(0, 30)
  end
  if IsTimeUp(1) == 1 then
    Chara_ExpressPopupIcon_Emotion(0, 1, 2)
    SetTimer(1, 45)
  end
end
viewer_update_func = L0_0
function L0_0()
  Debug_DrawMes("ndch_script.luc::viewer_exit_func")
  InvalidTimer(0)
  InvalidTimer(1)
end
viewer_exit_func = L0_0
