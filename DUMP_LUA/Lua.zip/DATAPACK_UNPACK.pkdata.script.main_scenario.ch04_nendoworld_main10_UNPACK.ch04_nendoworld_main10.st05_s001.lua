cool_type = {
  0,
  2,
  7,
  12,
  5,
  -1
}
motion_set = {
  {
    0,
    255,
    255,
    0,
    0
  },
  {
    8,
    255,
    255,
    0,
    0
  },
  {
    16777329,
    255,
    255,
    0,
    0
  },
  {
    16777401,
    9,
    0,
    0,
    0
  },
  {
    16777404,
    1,
    0,
    2,
    2
  },
  {
    16777405,
    255,
    255,
    0,
    0
  },
  {
    16777406,
    255,
    255,
    0,
    0
  },
  {
    16777407,
    255,
    255,
    0,
    0
  },
  {
    16777408,
    3,
    3,
    2,
    2
  },
  {
    16777409,
    255,
    255,
    0,
    0
  },
  {
    16777410,
    9,
    6,
    2,
    2
  },
  {
    16777411,
    255,
    255,
    0,
    0
  },
  {
    16777414,
    255,
    255,
    2,
    2
  },
  {
    16777412,
    255,
    255,
    2,
    2
  },
  {
    16777415,
    255,
    255,
    2,
    2
  },
  {
    16777413,
    255,
    255,
    2,
    2
  },
  {
    16777399,
    255,
    255,
    0,
    0
  },
  {
    16777402,
    255,
    255,
    2,
    2
  },
  {
    16777403,
    255,
    255,
    0,
    0
  },
  {
    16777418,
    0,
    1,
    2,
    0
  },
  {
    16777419,
    255,
    255,
    0,
    0
  },
  {
    16777420,
    0,
    1,
    2,
    2
  },
  {
    16777314,
    0,
    0,
    2,
    2
  },
  {
    16777315,
    2,
    0,
    2,
    2
  },
  {
    16777423,
    2,
    3,
    0,
    0
  },
  {
    16777424,
    255,
    255,
    0,
    0
  },
  {
    16777427,
    2,
    2,
    0,
    0
  },
  {
    16777428,
    255,
    255,
    0,
    0
  },
  {
    16777429,
    2,
    2,
    2,
    2
  },
  {
    16777430,
    255,
    255,
    0,
    0
  },
  {
    16777431,
    255,
    255,
    0,
    0
  },
  {
    16777432,
    255,
    255,
    0,
    0
  },
  {
    16777433,
    2,
    4,
    2,
    2
  },
  {
    -1,
    -1,
    -1,
    -1,
    -1
  }
}
motion_cool_set = {
  {
    0,
    255,
    255,
    0,
    0
  },
  {
    8,
    255,
    255,
    0,
    0
  },
  {
    16777329,
    255,
    255,
    0,
    0
  },
  {
    16777401,
    255,
    255,
    0,
    0
  },
  {
    16777404,
    255,
    255,
    2,
    2
  },
  {
    16777405,
    255,
    255,
    0,
    0
  },
  {
    16777406,
    255,
    255,
    0,
    0
  },
  {
    16777407,
    255,
    255,
    0,
    0
  },
  {
    16777408,
    1,
    0,
    2,
    2
  },
  {
    16777409,
    255,
    255,
    0,
    0
  },
  {
    16777410,
    1,
    0,
    2,
    2
  },
  {
    16777411,
    255,
    255,
    0,
    0
  },
  {
    16777414,
    255,
    255,
    2,
    2
  },
  {
    16777412,
    255,
    255,
    2,
    2
  },
  {
    16777415,
    255,
    255,
    2,
    2
  },
  {
    16777413,
    255,
    255,
    2,
    2
  },
  {
    16777399,
    255,
    255,
    0,
    0
  },
  {
    16777402,
    255,
    255,
    2,
    2
  },
  {
    16777403,
    255,
    255,
    0,
    0
  },
  {
    16777418,
    0,
    1,
    2,
    0
  },
  {
    16777419,
    255,
    255,
    0,
    0
  },
  {
    16777420,
    0,
    1,
    2,
    2
  },
  {
    16777314,
    0,
    0,
    2,
    2
  },
  {
    16777315,
    2,
    0,
    2,
    2
  },
  {
    16777423,
    2,
    3,
    0,
    0
  },
  {
    16777424,
    255,
    255,
    0,
    0
  },
  {
    16777427,
    2,
    2,
    0,
    0
  },
  {
    16777428,
    255,
    255,
    0,
    0
  },
  {
    16777429,
    2,
    2,
    2,
    2
  },
  {
    16777430,
    255,
    255,
    0,
    0
  },
  {
    16777431,
    255,
    255,
    0,
    0
  },
  {
    16777432,
    255,
    255,
    0,
    0
  },
  {
    16777433,
    2,
    4,
    2,
    2
  },
  {
    -1,
    -1,
    -1,
    -1,
    -1
  }
}
char_set = {
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      10,
      0,
      1,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      12,
      2,
      4,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      14,
      9,
      6,
      2,
      2
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      9,
      8,
      3,
      2,
      2
    }
  },
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      16,
      2,
      1,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      18,
      2,
      4,
      0,
      3
    }
  },
  {
    {
      0,
      8,
      255,
      255,
      0,
      0
    },
    {
      2,
      8,
      255,
      255,
      0,
      0
    },
    {
      7,
      8,
      255,
      255,
      0,
      0
    },
    {
      12,
      8,
      255,
      255,
      0,
      0
    },
    {
      5,
      8,
      255,
      255,
      0,
      0
    },
    {
      -1,
      20,
      2,
      2,
      0,
      0
    }
  },
  {
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      22,
      2,
      0,
      0,
      0
    }
  }
}
char_reset = {
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      11,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      13,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      15,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      0,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      17,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      19,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      0,
      0,
      255,
      255,
      0,
      0
    },
    {
      2,
      0,
      255,
      255,
      0,
      0
    },
    {
      7,
      0,
      255,
      255,
      0,
      0
    },
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      5,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      21,
      255,
      255,
      0,
      0
    }
  },
  {
    {
      12,
      0,
      255,
      255,
      0,
      0
    },
    {
      -1,
      23,
      255,
      255,
      0,
      0
    }
  }
}
function fc_TreasureFunc(A0_0)
  local L1_1, L2_2
  L1_1 = DPRINT
  L2_2 = "fc_TreasureFunc()"
  L1_1(L2_2)
  L1_1 = AddTreasure
  L2_2 = A0_0
  L1_1 = L1_1(L2_2)
  L2_2 = A0_0
  Model_SetMotion(L2_2, 1, 0, false)
  Wait_ModelMotion(L2_2)
  Message_WindowOpen(1)
  Wait_MessageWindow()
  if L1_1 == true then
    PlaySE(16777222)
    SetMes("TRE_000", "[COL SYS_NAM][STR TREASURE_NAME][COL SYS_DEF]\227\130\146\230\137\139\227\129\171\229\133\165\227\130\140\227\129\190\227\129\151\227\129\159\227\128\130\n")
  else
    SetMes("TRE_001", "[COL SYS_NAM][STR TREASURE_NAME][COL SYS_DEF]\227\130\146\232\166\139\227\129\164\227\129\145\227\129\190\227\129\151\227\129\159\227\128\130\n\226\128\166\227\129\151\227\129\139\227\129\151\227\128\129\227\129\147\227\129\174\227\130\162\227\130\164\227\131\134\227\131\160\227\129\175\227\130\130\227\129\134\230\140\129\227\129\161\229\136\135\227\130\140\227\129\190\227\129\155\227\130\147\227\128\130")
  end
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if L1_1 == false then
    Model_SetMotion(L2_2, 0, 1, false)
    Wait_ModelMotion(L2_2)
  end
end
function fc_ExitFunc()
  Message_WindowOpen(1)
  Wait_MessageWindow()
  SetMes("EXT_000", "\227\131\158\227\131\131\227\131\151\227\129\174\229\164\150\227\129\171\229\135\186\227\129\190\227\129\153\227\129\140\227\130\136\227\130\141\227\129\151\227\129\132\227\129\167\227\129\153\227\129\139\239\188\159")
  Message_SetBranch("\227\129\175\227\129\132", "\227\129\132\227\129\132\227\129\136", 1)
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
  if Message_GetBranchResult() == 0 then
    OffSystemFlag(0)
    OffSystemFlag(2)
    OffSystemFlag(1)
    OffSystemFlag(1)
    Map_ExitToIntermission()
  elseif Message_GetBranchResult() == 1 then
  end
end
function fc_EscapeDungeonFunc()
  local L0_3, L1_4, L2_5, L3_6, L4_7, L5_8, L6_9, L7_10, L8_11, L9_12, L10_13, L11_14, L12_15, L13_16, L14_17, L15_18, L16_19
  L0_3 = {
    L1_4,
    L2_5,
    L3_6,
    L4_7,
    L5_8,
    L6_9,
    L7_10,
    L8_11
  }
  L1_4 = -90
  L2_5 = -45
  L3_6 = 0
  L4_7 = 45
  L5_8 = 90
  L6_9 = 135
  L1_4 = {
    L2_5,
    L3_6,
    L4_7,
    L5_8,
    L6_9,
    L7_10
  }
  L2_5 = -90
  L3_6 = -30
  L4_7 = 30
  L5_8 = 90
  L6_9 = 150
  L2_5 = {
    L3_6,
    L4_7,
    L5_8,
    L6_9
  }
  L3_6 = -90
  L4_7 = 0
  L5_8 = 90
  L6_9 = 180
  L3_6 = 10
  L4_7 = 0
  L5_8 = 0
  L6_9 = 0
  for L10_13 = 4, L3_6 - 1 do
    if L10_13 == 4 then
      L14_17 = 1
      L11_14(L12_15, L13_16, L14_17)
      L11_14(L12_15)
      L14_17 = Particle_SetPosition
      L15_18 = 20
      L16_19 = L11_14
      L14_17(L15_18, L16_19, L12_15, L13_16)
    end
    if L10_13 < 2 then
      for L14_17 = 0, 3 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L2_5[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L0_3[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = 0.1 * L10_13
        L16_19 = 0.3 - L16_19
        L15_18(L16_19)
      end
    elseif L10_13 < 4 then
      for L14_17 = 0, 5 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = L10_13 - 2
        L16_19 = 0.05 * L16_19
        L16_19 = 0.1 - L16_19
        L15_18(L16_19)
      end
    elseif L10_13 < 8 then
      for L14_17 = 0, 7 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L0_3[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L0_3[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = L10_13 - 8
        L16_19 = 0.0025 * L16_19
        L16_19 = 0.01 - L16_19
        L15_18(L16_19)
      end
    else
      for L14_17 = 0, 5 do
        L15_18 = Player_SetRotateY
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = DPRINT
        L16_19 = L14_17 + 1
        L16_19 = L1_4[L16_19]
        L15_18(L16_19)
        L15_18 = Wait_Timer
        L16_19 = 0.01
        L15_18(L16_19)
      end
    end
    L5_8 = L11_14 + L12_15
    L14_17 = L6_9
    L11_14(L12_15, L13_16, L14_17)
  end
  L7_10(L8_11)
  L10_13 = 1
  L7_10(L8_11, L9_12, L10_13, L11_14)
  L7_10()
  L7_10(L8_11)
  L7_10(L8_11)
  L10_13 = 0
  L7_10(L8_11, L9_12, L10_13)
  L7_10(L8_11)
  L7_10()
  L7_10(L8_11)
end
function fc_Map_SetRoomChangeEventNPC(A0_20, A1_21, A2_22, A3_23, A4_24, A5_25, A6_26, A7_27, A8_28)
  local L9_29, L10_30, L11_31, L12_32, L13_33, L14_34
  L9_29 = Npc_GetPosition
  L10_30 = A1_21
  L11_31 = L9_29(L10_30)
  L12_32 = Map_SetRoomChangeEventCircle
  L13_33 = A0_20
  L14_34 = L9_29
  L12_32(L13_33, L14_34, L11_31, A2_22, A3_23, A4_24, A5_25, A6_26, A7_27)
  L12_32 = Map_EventCollSetSE
  L13_33 = A0_20
  L14_34 = A8_28
  L12_32(L13_33, L14_34)
end
function fc_Map_SetRoomChangeEventMDL(A0_35, A1_36, A2_37, A3_38, A4_39, A5_40, A6_41, A7_42, A8_43)
  local L9_44, L10_45, L11_46, L12_47, L13_48, L14_49
  L9_44 = Model_GetPosition
  L10_45 = A1_36
  L11_46 = L9_44(L10_45)
  L12_47 = Map_SetRoomChangeEventCircle
  L13_48 = A0_35
  L14_49 = L9_44
  L12_47(L13_48, L14_49, L11_46, A2_37, A3_38, A4_39, A5_40, A6_41, A7_42)
  L12_47 = Map_EventCollSetSE
  L13_48 = A0_35
  L14_49 = A8_43
  L12_47(L13_48, L14_49)
end
function fc_Map_SetRoomChangeEventPTK(A0_50, A1_51, A2_52, A3_53, A4_54, A5_55, A6_56, A7_57, A8_58)
  local L9_59, L10_60, L11_61, L12_62, L13_63, L14_64
  L9_59 = Particle_GetPosition
  L10_60 = A1_51
  L11_61 = L9_59(L10_60)
  L12_62 = Map_SetRoomChangeEventCircle
  L13_63 = A0_50
  L14_64 = L9_59
  L12_62(L13_63, L14_64, L11_61, A2_52, A3_53, A4_54, A5_55, A6_56, A7_57)
  L12_62 = Map_EventCollSetSE
  L13_63 = A0_50
  L14_64 = A8_58
  L12_62(L13_63, L14_64)
end
function fc_Map_SetCallLuaFuncEventCirclePTK(A0_65, A1_66, A2_67, A3_68)
  local L4_69, L5_70, L6_71, L7_72, L8_73, L9_74
  L4_69 = Particle_GetPosition
  L5_70 = A1_66
  L6_71 = L4_69(L5_70)
  L7_72 = Map_SetCallLuaFuncEventCircle
  L8_73 = A0_65
  L9_74 = L4_69
  L7_72(L8_73, L9_74, L6_71, A3_68, A2_67)
end
function fc_GetRandomNextArea()
  local L0_75, L1_76, L2_77, L3_78, L4_79
  L0_75 = GetRandomDungeonFloor
  L0_75 = L0_75()
  L0_75 = L0_75 + 1
  L1_76 = DPRINT
  L2_77 = "randomdungeonfloor = "
  L3_78 = L0_75
  L2_77 = L2_77 .. L3_78
  L1_76(L2_77)
  L1_76 = 0
  L2_77 = {
    L3_78,
    L4_79,
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      -1
    },
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      -1
    },
    {
      119,
      126,
      133,
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      -1
    },
    {
      140,
      120,
      127,
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      123,
      130,
      137,
      -1
    },
    {
      134,
      141,
      121,
      128,
      135,
      142,
      129,
      122,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      -1
    },
    {
      128,
      135,
      142,
      122,
      129,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      138,
      145,
      125,
      -1
    },
    {
      122,
      129,
      136,
      143,
      123,
      130,
      137,
      144,
      124,
      131,
      138,
      145,
      125,
      132,
      143,
      146,
      -1
    },
    {
      119,
      120,
      121,
      122,
      123,
      124,
      125,
      126,
      127,
      128,
      129,
      130,
      131,
      132,
      133,
      134,
      135,
      136,
      137,
      138,
      139,
      140,
      141,
      142,
      143,
      144,
      145,
      146,
      -1
    }
  }
  L3_78 = {
    L4_79,
    126,
    133,
    140,
    -1
  }
  L4_79 = 119
  L4_79 = {
    119,
    126,
    133,
    140,
    120,
    127,
    134,
    -1
  }
  if L0_75 == 10 then
    L1_76 = 109
  elseif L0_75 == 20 then
    L1_76 = 110
  elseif L0_75 == 30 then
    L1_76 = 111
  elseif L0_75 == 40 then
    L1_76 = 112
  elseif L0_75 == 50 then
    L1_76 = 113
  elseif L0_75 == 60 then
    L1_76 = 114
  elseif L0_75 == 70 then
    L1_76 = 115
  elseif L0_75 == 80 then
    L1_76 = 116
  elseif L0_75 == 90 then
    L1_76 = 117
  elseif L0_75 == 100 then
    L1_76 = 118
  else
    L3_78 = 1
    L4_79 = math
    L4_79 = L4_79.floor
    L4_79 = L4_79(L0_75 / 10)
    L4_79 = L4_79 + 1
    DPRINT("tableNo = " .. L4_79)
    while L2_77[L4_79][L3_78] ~= -1 do
      L3_78 = L3_78 + 1
    end
    L1_76 = L2_77[L4_79][Rand_GetInt(L3_78 - 2) + 1]
    DPRINT("area = " .. L1_76)
  end
  return L1_76
end
function fc_Map_SetRandomRoomChangeEventPTK(A0_80, A1_81, A2_82, A3_83)
  local L4_84, L5_85, L6_86, L7_87
  L4_84 = Particle_GetPosition
  L5_85 = A1_81
  L6_86 = L4_84(L5_85)
  L7_87 = fc_GetRandomNextArea
  L7_87 = L7_87()
  Map_SetRoomChangeEventCircle(A0_80, L4_84, L6_86, A2_82, L7_87, 0, 0, 0, 0)
  Map_EventCollSetSE(A0_80, 16777223)
end
function fc_SetRandomMapAmbientType()
  local L0_88, L1_89, L2_90, L3_91
  L0_88 = {
    L1_89,
    L2_90,
    L3_91,
    3,
    4,
    5,
    6,
    7,
    8,
    9
  }
  L1_89 = 0
  L2_90 = 1
  L3_91 = 2
  L1_89 = GetRandomDungeonFloor
  L1_89 = L1_89()
  L1_89 = L1_89 + 1
  L2_90 = SetRandomDungeonFloor
  L3_91 = L1_89
  L2_90(L3_91)
  L2_90 = math
  L2_90 = L2_90.floor
  L3_91 = L1_89 - 1
  L3_91 = L3_91 / 10
  L2_90 = L2_90(L3_91)
  L2_90 = L2_90 + 1
  L3_91 = L0_88[L2_90]
  DPRINT("ambient = " .. L3_91)
  Map_SetMapAmbientType(L3_91)
end
function fc_Map_nendotakadai1()
  FadeOut(16)
  Wait_Fade()
  Player_SetPosition(-1.1, 4.4, 7.8)
  Player_SetRotateY(90)
  Camera_SetMode(0)
  FadeIn(16)
  Wait_Fade()
end
function fc_Map_nendotakadai2()
  FadeOut(16)
  Wait_Fade()
  Player_SetPosition(-6.7, 0, 7.8)
  Player_SetRotateY(-90)
  Camera_SetMode(0)
  FadeIn(16)
  Wait_Fade()
end
function fc_IsCoolType(A0_92)
  local L2_93, L3_94, L4_95, L5_96, L6_97, L7_98
  L2_93 = A0_92
  L3_94 = false
  for L7_98 = 0, 100 do
    if cool_type[L7_98] == L2_93 then
      L3_94 = true
      break
    end
    if cool_type[L7_98] == -1 then
      break
    end
  end
  return L3_94
end
function fc_SetMotionEX(A0_99, A1_100, A2_101, A3_102)
  local L4_103, L5_104, L6_105, L7_106, L8_107, L9_108
  L4_103 = -1
  L5_104 = -1
  L6_105 = -1
  L7_106 = -1
  L8_107 = -1
  L9_108 = Npc_GetCharID
  L9_108 = L9_108(A0_99)
  for _FORV_14_ = 1, 1000 do
    if motion_set[_FORV_14_][1] == A1_100 then
      if fc_IsCoolType(L9_108) == true then
        L4_103 = motion_cool_set[_FORV_14_][1]
        L5_104 = motion_cool_set[_FORV_14_][2]
        L6_105 = motion_cool_set[_FORV_14_][3]
        L7_106 = motion_cool_set[_FORV_14_][4]
        L8_107 = motion_cool_set[_FORV_14_][5]
        break
      end
      L4_103 = motion_set[_FORV_14_][1]
      L5_104 = motion_set[_FORV_14_][2]
      L6_105 = motion_set[_FORV_14_][3]
      L7_106 = motion_set[_FORV_14_][4]
      L8_107 = motion_set[_FORV_14_][5]
      break
    end
    if motion_set[_FORV_14_][1] == -1 then
      break
    end
  end
  if L4_103 ~= -1 then
    Npc_SetMotion(A0_99, L4_103, A2_101, A3_102)
    Npc_SetFace(A0_99, L5_104, L6_105)
    Npc_SetHand(A0_99, L7_106, L8_107)
    DPRINT("motion_id = " .. A1_100)
  else
    Npc_SetMotion(A0_99, A1_100, A2_101, A3_102)
    DPRINT("**error** " .. A1_100 .. " is no set motion")
  end
end
function fc_SetTalkMotionEX(A0_109, A1_110, A2_111, A3_112, A4_113)
  local L5_114, L6_115, L7_116, L8_117, L9_118, L10_119, L11_120
  L5_114 = -1
  L6_115 = -1
  L7_116 = -1
  L8_117 = -1
  L9_118 = -1
  L10_119 = A4_113 == nil and true or A4_113
  L11_120 = Actor_GetCharID
  L11_120 = L11_120(A0_109)
  for _FORV_16_ = 1, 1000 do
    if motion_set[_FORV_16_][1] == A1_110 then
      if fc_IsCoolType(L11_120) == true then
        L5_114 = motion_cool_set[_FORV_16_][1]
        L6_115 = motion_cool_set[_FORV_16_][2]
        L7_116 = motion_cool_set[_FORV_16_][3]
        L8_117 = motion_cool_set[_FORV_16_][4]
        L9_118 = motion_cool_set[_FORV_16_][5]
        break
      end
      L5_114 = motion_set[_FORV_16_][1]
      L6_115 = motion_set[_FORV_16_][2]
      L7_116 = motion_set[_FORV_16_][3]
      L8_117 = motion_set[_FORV_16_][4]
      L9_118 = motion_set[_FORV_16_][5]
      break
    end
    if motion_set[_FORV_16_][1] == -1 then
      break
    end
  end
  if L5_114 ~= -1 then
    Actor_SetTalkMotion(A0_109, L5_114, A2_111, A3_112, L10_119)
    Actor_SetEye(A0_109, L6_115)
    Actor_SetMouth(A0_109, L7_116)
    Actor_SetHand(A0_109, L8_117, L9_118)
  else
    Actor_SetTalkMotion(A0_109, A1_110, A2_111, A3_112, L10_119)
    DPRINT("**error** " .. A1_110 .. " is no set motion")
  end
end
function fc_SetCommonMotion(A0_121, A1_122, A2_123, A3_124)
  local L4_125, L5_126, L6_127, L7_128, L8_129
  L4_125 = -1
  L5_126 = -1
  L6_127 = -1
  L7_128 = -1
  L8_129 = -1
  for _FORV_13_ = 1, 1000 do
    if char_set[A1_122 + 1][_FORV_13_][1] == Npc_GetCharID(A0_121) or char_set[A1_122 + 1][_FORV_13_][1] == -1 then
      L4_125 = char_set[A1_122 + 1][_FORV_13_][2]
      L5_126 = char_set[A1_122 + 1][_FORV_13_][3]
      L6_127 = char_set[A1_122 + 1][_FORV_13_][4]
      L7_128 = char_set[A1_122 + 1][_FORV_13_][5]
      L8_129 = char_set[A1_122 + 1][_FORV_13_][6]
      break
    end
  end
  DPRINT("motion_id = " .. L4_125)
  Npc_SetMotion(A0_121, L4_125, A2_123, A3_124)
  Npc_SetFace(A0_121, L5_126, L6_127)
  Npc_SetHand(A0_121, L7_128, L8_129)
end
function fc_EndCommonMotion(A0_130, A1_131, A2_132, A3_133)
  local L4_134, L5_135, L6_136, L7_137, L8_138
  L4_134 = -1
  L5_135 = -1
  L6_136 = -1
  L7_137 = -1
  L8_138 = -1
  for _FORV_13_ = 1, 1000 do
    if char_reset[A1_131 + 1][_FORV_13_][1] == Npc_GetCharID(A0_130) or char_reset[A1_131 + 1][_FORV_13_][1] == -1 then
      L4_134 = char_reset[A1_131 + 1][_FORV_13_][2]
      L5_135 = char_reset[A1_131 + 1][_FORV_13_][3]
      L6_136 = char_reset[A1_131 + 1][_FORV_13_][4]
      L7_137 = char_reset[A1_131 + 1][_FORV_13_][5]
      L8_138 = char_reset[A1_131 + 1][_FORV_13_][6]
      break
    end
  end
  Npc_SetMotion(A0_130, L4_134, A2_132, A3_133)
  Npc_SetFace(A0_130, L5_135, L6_136)
  Npc_SetHand(A0_130, L7_137, L8_138)
end
function fc_SetCommonTalkMotion(A0_139, A1_140, A2_141, A3_142, A4_143)
  local L5_144, L6_145, L7_146, L8_147, L9_148, L10_149
  L5_144 = -1
  L6_145 = -1
  L7_146 = -1
  L8_147 = -1
  L9_148 = -1
  L10_149 = A4_143 == nil and true or A4_143
  for _FORV_15_ = 1, 1000 do
    if char_set[A1_140 + 1][_FORV_15_][1] == Actor_GetCharID(A0_139) or char_set[A1_140 + 1][_FORV_15_][1] == -1 then
      L5_144 = char_set[A1_140 + 1][_FORV_15_][2]
      L6_145 = char_set[A1_140 + 1][_FORV_15_][3]
      L7_146 = char_set[A1_140 + 1][_FORV_15_][4]
      L8_147 = char_set[A1_140 + 1][_FORV_15_][5]
      L9_148 = char_set[A1_140 + 1][_FORV_15_][6]
      break
    end
  end
  Actor_SetTalkMotion(A0_139, L5_144, A2_141, A3_142, L10_149)
  Actor_SetEye(A0_139, L6_145)
  Actor_SetMouth(A0_139, L7_146)
  Actor_SetHand(A0_139, L8_147, L9_148)
  DPRINT("ID " .. L5_144)
end
function fc_EndCommonTalkMotion(A0_150, A1_151, A2_152, A3_153, A4_154)
  local L5_155, L6_156, L7_157, L8_158, L9_159, L10_160
  L5_155 = -1
  L6_156 = -1
  L7_157 = -1
  L8_158 = -1
  L9_159 = -1
  L10_160 = A4_154 == nil and true or A4_154
  for _FORV_15_ = 1, 1000 do
    if char_reset[A1_151 + 1][_FORV_15_][1] == Actor_GetCharID(A0_150) or char_reset[A1_151 + 1][_FORV_15_][1] == -1 then
      L5_155 = char_reset[A1_151 + 1][_FORV_15_][2]
      L6_156 = char_reset[A1_151 + 1][_FORV_15_][3]
      L7_157 = char_reset[A1_151 + 1][_FORV_15_][4]
      L8_158 = char_reset[A1_151 + 1][_FORV_15_][5]
      L9_159 = char_reset[A1_151 + 1][_FORV_15_][6]
      break
    end
  end
  Actor_SetTalkMotion(A0_150, L5_155, A2_152, A3_153, L10_160)
  Actor_SetEye(A0_150, L6_156)
  Actor_SetMouth(A0_150, L7_157)
  Actor_SetHand(A0_150, L8_158, L9_159)
  DPRINT("ID " .. L5_155)
end
function fc_Map_SetEncountLoop(A0_161, A1_162, A2_163, A3_164)
  while true do
    Map_SetEncount(A0_161, A1_162, false)
    if GetBattleResult() == 3 then
      BGFilterFadeOut(0.1)
      Wait_BGFilterFade()
      FadeIn(16)
      Wait_Fade()
      if A3_164 == true then
        Message_WindowSystemOpen()
      else
        Message_WindowOpen(1)
      end
      Wait_MessageWindow()
      SetMes("BTL_00", "[TALK ]\230\136\166\233\151\152\227\130\146\227\130\132\227\130\138\231\155\180\227\129\151\227\129\190\227\129\153\227\128\130")
      Message_WindowClose()
      Message_Clear()
      Wait_MessageWindow()
      FadeOut(16)
      Wait_Fade()
      BGFilterFadeIn(0.1)
      Wait_BGFilterFade()
    else
      break
    end
  end
  if A2_163 == true then
    FadeIn(16)
    Wait_Fade()
  end
end
function fc_SetMesBranch(A0_165, A1_166, A2_167)
  local L3_168
  L3_168 = Search_MsgChar
  L3_168 = L3_168(A1_166, A2_167)
  fc_CharBranch(A0_165, L3_168)
end
function fc_SetClearEvent()
  local L0_169, L1_170, L2_171, L3_172, L4_173, L5_174, L6_175
  L0_169 = 10
  L1_170 = Particle_Create
  L2_171 = 20
  L3_172 = 0
  L1_170(L2_171, L3_172, L4_173)
  L1_170 = PlaySE
  L2_171 = 16777237
  L1_170(L2_171)
  L1_170 = Player_GetPosition
  L3_172 = L1_170()
  L4_173(L5_174, L6_175, L2_171, L3_172)
  for _FORV_7_ = 4, L0_169 - 1 do
    if _FORV_7_ < 8 then
      for _FORV_11_ = 0, 7 do
        L2_171 = L2_171 + 0.002857142857142857 * (_FORV_7_ - 4)
        Player_SetOffsetPosition(0, L2_171, 0)
        Wait_Timer(0.01 - 0.0025 * (_FORV_7_ - 8))
      end
    else
      for _FORV_11_ = 0, 5 do
        L2_171 = L2_171 + 0.005 * (_FORV_7_ - 4)
        Player_SetOffsetPosition(0, L2_171, 0)
        Wait_Timer(0.01)
      end
    end
  end
  L4_173(L5_174, L6_175, 1, 1)
  L4_173()
  L4_173(L5_174)
  L4_173(L5_174, L6_175, 0)
  L4_173(L5_174)
  L4_173(L5_174)
  L4_173(L5_174)
  L4_173()
  L4_173(L5_174)
  L4_173(L5_174)
end
function common_load_func()
  Map_LoadModelSet(62)
  Map_BattleBGSet(5)
  SetTreasure(40)
  SetMapBGM(4)
end
function common_init_func()
  fc_Map_SetRoomChangeEventPTK(0, 256, 0.7, 64, -0.4, 0, -13, 0, 16777223)
  fc_Map_SetRoomChangeEventPTK(1, 257, 0.7, 67, 12.6, 0, 0, -90, 16777223)
  if GetChapter() <= 23 then
    Map_OffEventColl(1)
    Particle_SetVisible(257, false)
  end
end
function common_npc_load_func()
  Npc_Load(20, 16777623)
end
function common_npc_init_func()
  Npc_SetPosition(20, 3.07, 0, 5.23)
  Npc_SetRotateY(20, -90)
  Npc_SetMessageScriptFunc(20, "npc_message_func_00")
  Npc_SetMoveQueue(20, 0.9, 1.13, 0, 5.23)
  Npc_SetWaitTimeQueue(20, 2)
  Npc_SetMoveQueue(20, 0.9, 1.13, 0, 7.45)
  Npc_SetWaitTimeQueue(20, 2)
  Npc_SetMoveQueue(20, 0.9, 3.07, 0, 7.45)
  Npc_SetWaitTimeQueue(20, 2.5)
  Npc_SetMoveQueue(20, 0.9, 3.07, 0, 5.23)
  Npc_SetWaitTimeQueue(20, 2.5)
end
function npc_message_func_00()
  Wait_Fade()
  Message_WindowOpen()
  Wait_MessageWindow()
  SetMes("MOV_041", "[TALK \232\184\138\227\130\138\229\173\144]\227\129\147\227\129\174[COL SYS_NAM]\231\165\158\230\174\191[COL SYS_DEF]\227\129\174\227\131\159\227\130\185\227\131\134\227\131\170\227\130\162\227\130\185\227\129\170\233\155\176\229\155\178\230\176\151\227\129\140\229\191\131\229\156\176\227\130\136\227\129\132\226\128\166\227\128\130")
  SetMes("MOV_042", "[TALK \232\184\138\227\130\138\229\173\144]\227\129\130\227\129\170\227\129\159\227\130\130\227\129\157\227\129\134\230\128\157\227\130\143\227\129\170\227\129\132?")
  Message_WindowClose()
  Message_Clear()
  Wait_MessageWindow()
end
DPRINT("st05_s001.luc")
function load_func()
  DPRINT("st05_s001.luc" .. "::load_func()")
  common_load_func()
  Npc_Load(0, 2)
  Npc_Load(1, 0)
  Npc_Load(2, 20)
  Npc_Load(7, 16777366)
  Npc_Load(3, 16)
  Npc_Load(4, 19)
  Npc_Load(5, 23)
  Npc_Load(6, 3)
  Particle_LoadResourceFile(23)
  Particle_LoadResourceFile(9)
  Particle_LoadResourceFile(11)
  SetEventBGM(-1)
end
function init_func()
  DPRINT("st05_s001.luc" .. "::init_func()")
  common_init_func()
  Npc_SetPosition(0, -8.33, 0, 10.39)
  Npc_SetRotateY(0, -106)
  Npc_SetPosition(1, -5.86, 0, 9.4)
  Npc_SetRotateY(1, -60)
  Npc_SetVisible(1, false)
  Npc_SetPosition(2, -4.73, 0, 9.91)
  Npc_SetRotateY(2, -60)
  Npc_SetVisible(2, false)
  Npc_SetPosition(7, -7.12, 0, 10.79)
  Npc_SetRotateY(7, 66.5)
  Npc_SetVisible(7, false)
  Npc_SetPosition(3, -1.19, 0, 13.79)
  Npc_SetRotateY(3, -90)
  Npc_SetVisible(3, false)
  Npc_SetPosition(4, -0.14, 0, 12.12)
  Npc_SetRotateY(4, -90)
  Npc_SetVisible(4, false)
  Npc_SetPosition(5, -6.32, 0, 8.57)
  Npc_SetRotateY(5, -50)
  Npc_SetVisible(5, false)
  Npc_SetPosition(6, -7.3, 0, 8.59)
  Npc_SetRotateY(6, -40)
  Npc_SetVisible(6, false)
  Player_SetVisible(false)
  Camera_SetMode(3)
  Camera_SetRotate(65)
  Camera_SetHeight(2.5)
  Camera_SetTargetPosition(-8.33, 0.76, 10.39)
  Camera_SetFov(13.5)
end
function main_func()
  local L0_176, L1_177, L2_178, L3_179, L4_180, L5_181, L6_182, L7_183, L8_184, L9_185, L10_186, L11_187, L12_188, L13_189, L14_190, L15_191, L16_192, L17_193
  L0_176 = DPRINT
  L1_177 = "st05_s001.luc"
  L2_178 = "::main_func()"
  L1_177 = L1_177 .. L2_178
  L0_176(L1_177)
  L0_176 = Wait_Fade
  L0_176()
  L0_176 = Wait_Timer
  L1_177 = 1
  L0_176(L1_177)
  L0_176 = Npc_SetInterRotateY
  L1_177 = 0
  L2_178 = 66.5
  L3_179 = 30
  L0_176(L1_177, L2_178, L3_179)
  L0_176 = Camera_SetFov
  L1_177 = 10.5
  L2_178 = 2
  L0_176(L1_177, L2_178)
  L0_176 = Wait_Timer
  L1_177 = 2.5
  L0_176(L1_177)
  L0_176 = Wait_NpcRotate
  L1_177 = 0
  L0_176(L1_177)
  L0_176 = FadeOut
  L1_177 = 16
  L0_176(L1_177)
  L0_176 = Wait_Fade
  L0_176()
  L0_176 = Map_SetTalk
  L1_177 = "script/main_scenario/ch04_NendoWorld_main10/talk_01.lbn"
  L0_176(L1_177)
  L0_176 = FadeIn
  L1_177 = 16
  L0_176(L1_177)
  L0_176 = Wait_Fade
  L0_176()
  L0_176 = Wait_Timer
  L1_177 = 1
  L0_176(L1_177)
  L0_176 = Npc_SetFace
  L1_177 = 7
  L2_178 = 2
  L3_179 = 0
  L0_176(L1_177, L2_178, L3_179)
  L0_176 = PlaySE
  L1_177 = 33554437
  L0_176(L1_177)
  L0_176 = Npc_SetWeaponVisible
  L1_177 = 0
  L2_178 = true
  L0_176(L1_177, L2_178)
  L0_176 = fc_SetMotionEX
  L1_177 = 0
  L2_178 = 16777230
  L3_179 = 0.2
  L4_180 = false
  L0_176(L1_177, L2_178, L3_179, L4_180)
  L0_176 = Npc_RequestMotion
  L1_177 = 0
  L2_178 = 16777220
  L3_179 = 0.2
  L4_180 = true
  L0_176(L1_177, L2_178, L3_179, L4_180)
  L0_176 = Camera_SetFov
  L1_177 = 7.5
  L2_178 = 1
  L0_176(L1_177, L2_178)
  L0_176 = Particle_Create
  L1_177 = 0
  L2_178 = 23
  L3_179 = 0
  L0_176(L1_177, L2_178, L3_179)
  L0_176 = Npc_GetPosition
  L1_177 = 0
  L2_178 = L0_176(L1_177)
  L3_179 = Particle_SetPosition
  L4_180 = 0
  L5_181 = L0_176
  L6_182 = L1_177
  L7_183 = L2_178
  L3_179(L4_180, L5_181, L6_182, L7_183)
  L3_179 = Wait_ParticleAnimation
  L4_180 = 0
  L3_179(L4_180)
  L3_179 = Particle_Delete
  L4_180 = 0
  L3_179(L4_180)
  L3_179 = Wait_Timer
  L4_180 = 2
  L3_179(L4_180)
  L3_179 = Map_SetEncount
  L4_180 = 0
  L5_181 = 39
  L6_182 = false
  L3_179(L4_180, L5_181, L6_182)
  L3_179 = SetEventBGM
  L4_180 = 3
  L3_179(L4_180)
  L3_179 = Npc_SetVisible
  L4_180 = 1
  L5_181 = true
  L3_179(L4_180, L5_181)
  L3_179 = Npc_SetVisible
  L4_180 = 2
  L5_181 = true
  L3_179(L4_180, L5_181)
  L3_179 = Camera_SetRotate
  L4_180 = 3
  L3_179(L4_180)
  L3_179 = Camera_SetHeight
  L4_180 = 2.5
  L3_179(L4_180)
  L3_179 = Camera_SetTargetPosition
  L4_180 = -6.62
  L5_181 = 0.48
  L6_182 = 10.98
  L3_179(L4_180, L5_181, L6_182)
  L3_179 = Camera_SetFov
  L4_180 = 16
  L3_179(L4_180)
  L3_179 = Npc_SetFace
  L4_180 = 2
  L5_181 = 9
  L6_182 = 0
  L3_179(L4_180, L5_181, L6_182)
  L3_179 = FadeIn
  L4_180 = 16
  L3_179(L4_180)
  L3_179 = Wait_Fade
  L3_179()
  L3_179 = Message_WindowOpen
  L3_179()
  L3_179 = Wait_MessageWindow
  L3_179()
  L3_179 = fc_SetMotionEX
  L4_180 = 1
  L5_181 = 16777229
  L6_182 = 0
  L7_183 = false
  L3_179(L4_180, L5_181, L6_182, L7_183)
  L3_179 = Npc_RequestMotion
  L4_180 = 1
  L5_181 = 0
  L6_182 = 0.3
  L7_183 = true
  L3_179(L4_180, L5_181, L6_182, L7_183)
  L3_179 = SetMes
  L4_180 = "MES_496"
  L5_181 = "[TALK \227\131\150\227\131\169\227\131\131\227\130\175\226\152\133\227\131\173\227\131\131\227\130\175\227\130\183\227\131\165\227\131\188\227\130\191\227\131\188]\227\129\149\227\129\130\227\128\129\n\231\180\132\230\157\159\233\128\154\227\130\138[COL SYS_CHR]\227\131\135\227\131\131\227\131\137\227\131\158\227\130\185\227\130\191\227\131\188[COL SYS_DEF]\227\129\174\228\189\147\227\130\146\232\191\148\227\129\151\227\129\166!"
  L3_179(L4_180, L5_181)
  L3_179 = Camera_SetRotate
  L4_180 = 63
  L3_179(L4_180)
  L3_179 = Camera_SetHeight
  L4_180 = 1.5
  L3_179(L4_180)
  L3_179 = Camera_SetTargetPosition
  L4_180 = -8.93
  L5_181 = 0.48
  L6_182 = 9.88
  L3_179(L4_180, L5_181, L6_182)
  L3_179 = Camera_SetFov
  L4_180 = 11.5
  L3_179(L4_180)
  L3_179 = fc_SetMotionEX
  L4_180 = 0
  L5_181 = 16777231
  L6_182 = 0
  L7_183 = false
  L3_179(L4_180, L5_181, L6_182, L7_183)
  L3_179 = Npc_RequestMotion
  L4_180 = 0
  L5_181 = 16777221
  L6_182 = 0.3
  L7_183 = true
  L3_179(L4_180, L5_181, L6_182, L7_183)
  L3_179 = SetMes
  L4_180 = "MES_497"
  L5_181 = "[TALK \227\131\135\227\131\131\227\131\137\227\131\158\227\130\185\227\130\191\227\131\188]\227\129\132\227\129\132\227\130\143\227\130\136\227\128\130\n\227\129\169\227\129\134\227\129\155\227\129\147\227\129\174\228\189\147\227\129\171\227\129\175\227\128\129\227\129\157\227\130\141\227\129\157\227\130\141\233\163\189\227\129\141\227\129\166\227\129\132\227\129\159\227\129\151\227\128\130"
  L3_179(L4_180, L5_181)
  L3_179 = Message_WindowClose
  L3_179()
  L3_179 = Message_Clear
  L3_179()
  L3_179 = Wait_MessageWindow
  L3_179()
  L3_179 = SetEventBGM
  L4_180 = -1
  L3_179(L4_180)
  L3_179 = Npc_SetFace
  L4_180 = 0
  L5_181 = 1
  L6_182 = 0
  L3_179(L4_180, L5_181, L6_182)
  L3_179 = Camera_SetFov
  L4_180 = 13.5
  L5_181 = 1
  L3_179(L4_180, L5_181)
  L3_179 = Wait_Timer
  L4_180 = 1
  L3_179(L4_180)
  L3_179 = Particle_Create
  L4_180 = 1
  L5_181 = 9
  L6_182 = 0
  L3_179(L4_180, L5_181, L6_182)
  L3_179 = PlaySE
  L4_180 = 33554444
  L3_179(L4_180)
  L3_179 = Npc_GetPosition
  L4_180 = 7
  L5_181 = L3_179(L4_180)
  L6_182 = Particle_SetPosition
  L7_183 = 1
  L8_184 = L3_179
  L9_185 = L4_180
  L10_186 = L5_181
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = FadeOut
  L7_183 = 4
  L8_184 = 1
  L9_185 = 1
  L10_186 = 1
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = Wait_Timer
  L7_183 = 0.1
  L6_182(L7_183)
  L6_182 = Wait_Fade
  L6_182()
  L6_182 = Npc_SetVisible
  L7_183 = 7
  L8_184 = true
  L6_182(L7_183, L8_184)
  L6_182 = fc_SetMotionEX
  L7_183 = 0
  L8_184 = 16777279
  L9_185 = 0
  L10_186 = true
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = Wait_NpcMotion
  L7_183 = 0
  L6_182(L7_183)
  L6_182 = Npc_SetFace
  L7_183 = 7
  L8_184 = 0
  L9_185 = 1
  L6_182(L7_183, L8_184, L9_185)
  L6_182 = Npc_SetMotion
  L7_183 = 7
  L8_184 = 16777221
  L9_185 = 0.2
  L10_186 = true
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = Wait_NpcMotion
  L7_183 = 7
  L6_182(L7_183)
  L6_182 = FadeIn
  L7_183 = 4
  L6_182(L7_183)
  L6_182 = Wait_Fade
  L6_182()
  L6_182 = Wait_ParticleAnimation
  L7_183 = 1
  L6_182(L7_183)
  L6_182 = Particle_Delete
  L7_183 = 1
  L6_182(L7_183)
  L6_182 = Camera_SetTargetPosition
  L7_183 = -8.93
  L8_184 = -0.08
  L9_185 = 9.88
  L6_182(L7_183, L8_184, L9_185)
  L6_182 = Camera_SetFov
  L7_183 = 8.5
  L6_182(L7_183)
  L6_182 = Wait_Timer
  L7_183 = 0.5
  L6_182(L7_183)
  L6_182 = Camera_SetMode
  L7_183 = 3
  L6_182(L7_183)
  L6_182 = Camera_SetMoveSpeed
  L7_183 = 0.8
  L6_182(L7_183)
  L6_182 = Camera_SetMovePoints
  L7_183 = -8.93
  L8_184 = -0.08
  L9_185 = 9.88
  L10_186 = -8.93
  L11_187 = 0.76
  L12_188 = 9.88
  L6_182(L7_183, L8_184, L9_185, L10_186, L11_187, L12_188)
  L6_182 = Wait_CameraMove
  L6_182()
  L6_182 = Wait_Timer
  L7_183 = 3
  L6_182(L7_183)
  L6_182 = FadeOut
  L7_183 = 16
  L6_182(L7_183)
  L6_182 = Wait_Fade
  L6_182()
  L6_182 = Map_SetTalk
  L7_183 = "script/main_scenario/ch04_NendoWorld_main10/talk_02.lbn"
  L6_182(L7_183)
  L6_182 = Npc_ChangeLoad
  L7_183 = 2
  L8_184 = 16777369
  L6_182(L7_183, L8_184)
  L6_182 = Npc_ChangeLoadStart
  L6_182()
  L6_182 = Npc_SetVisible
  L7_183 = 3
  L8_184 = true
  L6_182(L7_183, L8_184)
  L6_182 = Npc_SetVisible
  L7_183 = 4
  L8_184 = true
  L6_182(L7_183, L8_184)
  L6_182 = Npc_SetVisible
  L7_183 = 5
  L8_184 = true
  L6_182(L7_183, L8_184)
  L6_182 = Npc_SetVisible
  L7_183 = 6
  L8_184 = true
  L6_182(L7_183, L8_184)
  L6_182 = Wait_Load
  L6_182()
  L6_182 = Npc_ChangeFinish
  L7_183 = 2
  L6_182(L7_183)
  L6_182 = Npc_SetVisible
  L7_183 = 2
  L8_184 = false
  L6_182(L7_183, L8_184)
  L6_182 = Npc_SetVisible
  L7_183 = 0
  L8_184 = false
  L6_182(L7_183, L8_184)
  L6_182 = Npc_SetPosition
  L7_183 = 7
  L8_184 = -9.09
  L9_185 = 0
  L10_186 = 10.07
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = Npc_SetPosition
  L7_183 = 1
  L8_184 = -5.45
  L9_185 = 0
  L10_186 = 9.33
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = Npc_SetPosition
  L7_183 = 2
  L8_184 = -9.1
  L9_185 = 0
  L10_186 = 11.5
  L6_182(L7_183, L8_184, L9_185, L10_186)
  L6_182 = Npc_SetRotateY
  L7_183 = 2
  L8_184 = 66.5
  L6_182(L7_183, L8_184)
  L6_182 = Camera_SetRotate
  L7_183 = 327
  L6_182(L7_183)
  L6_182 = Camera_SetHeight
  L7_183 = 3
  L6_182(L7_183)
  L6_182 = Camera_SetTargetPosition
  L7_183 = -6.68
  L8_184 = 0.48
  L9_185 = 10.78
  L6_182(L7_183, L8_184, L9_185)
  L6_182 = Camera_SetFov
  L7_183 = 20.5
  L6_182(L7_183)
  L6_182 = SetEventBGM
  L7_183 = 10
  L6_182(L7_183)
  L6_182 = FadeIn
  L7_183 = 16
  L6_182(L7_183)
  L6_182 = Wait_Fade
  L6_182()
  L6_182 = Npc_SetMoveMotion
  L7_183 = 3
  L8_184 = 2
  L6_182(L7_183, L8_184)
  L6_182 = Npc_GetPosition
  L7_183 = 3
  L8_184 = L6_182(L7_183)
  L9_185 = Npc_SetMoveSpeed
  L10_186 = 3
  L11_187 = 6
  L9_185(L10_186, L11_187)
  L9_185 = Npc_SetMovePoints
  L10_186 = 3
  L11_187 = L6_182
  L12_188 = L7_183
  L13_189 = L8_184
  L14_190 = -4.09
  L15_191 = 0
  L16_192 = 12.02
  L17_193 = false
  L9_185(L10_186, L11_187, L12_188, L13_189, L14_190, L15_191, L16_192, L17_193)
  L9_185 = Npc_SetMoveMotion
  L10_186 = 4
  L11_187 = 2
  L9_185(L10_186, L11_187)
  L9_185 = Npc_GetPosition
  L10_186 = 4
  L11_187 = L9_185(L10_186)
  L12_188 = Npc_SetMoveSpeed
  L13_189 = 4
  L14_190 = 6
  L12_188(L13_189, L14_190)
  L12_188 = Npc_SetMovePoints
  L13_189 = 4
  L14_190 = L9_185
  L15_191 = L10_186
  L16_192 = L11_187
  L17_193 = -4.49
  L12_188(L13_189, L14_190, L15_191, L16_192, L17_193, 0, 10.79, false)
  L12_188 = Wait_NpcMove
  L13_189 = 3
  L12_188(L13_189)
  L12_188 = Wait_NpcMove
  L13_189 = 4
  L12_188(L13_189)
  L12_188 = Message_WindowOpen
  L12_188()
  L12_188 = Wait_MessageWindow
  L12_188()
  L12_188 = fc_SetMotionEX
  L13_189 = 3
  L14_190 = 16777229
  L15_191 = 0
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 3
  L14_190 = 0
  L15_191 = 0.3
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_498"
  L14_190 = "[TALK \227\130\164\227\131\170\227\131\164]\228\189\149\227\130\146\227\130\132\227\129\163\227\129\166\227\129\132\227\130\139\227\129\174\227\130\136!"
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIcon
  L13_189 = 1
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 5
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 6
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_SetInterRotateY
  L13_189 = 1
  L14_190 = 20
  L15_191 = 10
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Npc_SetInterRotateY
  L13_189 = 5
  L14_190 = 30
  L15_191 = 10
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Npc_SetInterRotateY
  L13_189 = 6
  L14_190 = 30
  L15_191 = 10
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Wait_NpcRotate
  L13_189 = 0
  L12_188(L13_189)
  L12_188 = Wait_NpcRotate
  L13_189 = 5
  L12_188(L13_189)
  L12_188 = Wait_NpcRotate
  L13_189 = 6
  L12_188(L13_189)
  L12_188 = Wait_Timer
  L13_189 = 0.5
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 5
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 6
  L12_188(L13_189)
  L12_188 = Wait_Timer
  L13_189 = 0.5
  L12_188(L13_189)
  L12_188 = Camera_SetRotate
  L13_189 = 307
  L12_188(L13_189)
  L12_188 = Camera_SetHeight
  L13_189 = 2
  L12_188(L13_189)
  L12_188 = Camera_SetTargetPosition
  L13_189 = -4.08
  L14_190 = 0.48
  L15_191 = 10.08
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Camera_SetFov
  L13_189 = 14.5
  L12_188(L13_189)
  L12_188 = Npc_ShowPopupIcon
  L13_189 = 1
  L14_190 = 3
  L12_188(L13_189, L14_190)
  L12_188 = SetMes
  L13_189 = "MES_499"
  L14_190 = "[TALK \227\131\150\227\131\169\227\131\131\227\130\175\226\152\133\227\131\173\227\131\131\227\130\175\227\130\183\227\131\165\227\131\188\227\130\191\227\131\188]\227\129\191\227\130\147\227\129\170\226\128\166\226\128\166!"
  L12_188(L13_189, L14_190)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Npc_ShowPopupIcon
  L13_189 = 3
  L14_190 = 14
  L12_188(L13_189, L14_190)
  L12_188 = fc_SetMotionEX
  L13_189 = 3
  L14_190 = 16777329
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 3
  L14_190 = 0
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_500"
  L14_190 = "[TALK \227\130\164\227\131\170\227\131\164]\227\130\183\227\131\188\227\131\171\227\129\174\232\167\163\230\158\144\227\130\146\227\129\151\227\129\166\227\129\132\227\130\139\233\150\147\227\129\171\227\128\129\n\230\149\181\227\129\174\230\156\172\230\139\160\229\156\176\227\129\171\228\185\151\227\130\138\232\190\188\227\130\128\227\129\170\227\130\147\227\129\166\227\128\129\n\231\132\161\232\172\128\227\129\171\227\130\130\231\168\139\227\129\140\227\129\130\227\130\139\227\129\167\227\129\151\227\130\135!"
  L12_188(L13_189, L14_190)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 3
  L12_188(L13_189)
  L12_188 = fc_SetMotionEX
  L13_189 = 1
  L14_190 = 16777334
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 1
  L14_190 = 0
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_501"
  L14_190 = "[TALK \227\131\150\227\131\169\227\131\131\227\130\175\226\152\133\227\131\173\227\131\131\227\130\175\227\130\183\227\131\165\227\131\188\227\130\191\227\131\188]\227\129\157\227\130\140\227\129\175\227\128\129\227\129\157\227\129\174\226\128\166\226\128\166\227\128\130\n\227\129\148\227\130\129\227\130\147\227\129\170\227\129\149\227\129\132\226\128\166\226\128\166"
  L12_188(L13_189, L14_190)
  L12_188 = fc_SetMotionEX
  L13_189 = 4
  L14_190 = 8
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 4
  L14_190 = 0
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_502"
  L14_190 = "[TALK \231\180\133\232\142\137\230\160\150]\227\129\167\227\130\130\227\128\129\231\167\129\227\129\159\227\129\161\227\129\140\230\157\165\227\129\159\227\129\139\227\130\137\227\129\171\227\129\175\227\128\129\n\227\130\130\227\129\134\229\174\137\229\191\131\227\130\136!"
  L12_188(L13_189, L14_190)
  L12_188 = Camera_SetRotate
  L13_189 = 257
  L12_188(L13_189)
  L12_188 = Camera_SetHeight
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Camera_SetTargetPosition
  L13_189 = -0.02
  L14_190 = 0.2
  L15_191 = 12.11
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Camera_SetFov
  L13_189 = 17.5
  L12_188(L13_189)
  L12_188 = Npc_SetFace
  L13_189 = 4
  L14_190 = 0
  L15_191 = 1
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = fc_SetMotionEX
  L13_189 = 4
  L14_190 = 16777252
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 4
  L14_190 = 16777253
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_502_00"
  L14_190 = "[TALK \231\180\133\232\142\137\230\160\150]\227\130\143\227\129\139\227\129\163\227\129\159\227\130\143\227\130\136\227\128\130\227\129\130\227\129\174\227\130\183\227\131\188\227\131\171\227\129\174\231\167\152\229\175\134\227\129\140\227\128\130\n[COL SYS_NAM]\227\131\141\227\130\172\227\130\175\227\131\169\227\130\164\232\187\141\229\155\163[COL SYS_DEF]\227\129\171\229\175\190\230\138\151\227\129\153\227\130\139\230\150\185\230\179\149\227\129\140!"
  L12_188(L13_189, L14_190)
  L12_188 = Camera_SetRotate
  L13_189 = 307
  L12_188(L13_189)
  L12_188 = Camera_SetHeight
  L13_189 = 2
  L12_188(L13_189)
  L12_188 = Camera_SetTargetPosition
  L13_189 = -4.08
  L14_190 = 0.48
  L15_191 = 10.08
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Camera_SetFov
  L13_189 = 14.5
  L12_188(L13_189)
  L12_188 = Npc_ShowPopupIcon
  L13_189 = 1
  L14_190 = 3
  L12_188(L13_189, L14_190)
  L12_188 = SetMes
  L13_189 = "MES_503"
  L14_190 = "[TALK \227\131\150\227\131\169\227\131\131\227\130\175\226\152\133\227\131\173\227\131\131\227\130\175\227\130\183\227\131\165\227\131\188\227\130\191\227\131\188]\230\156\172\229\189\147!?\227\128\128\227\129\153\227\129\148\227\129\132!"
  L12_188(L13_189, L14_190)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Camera_SetRotate
  L13_189 = 75
  L12_188(L13_189)
  L12_188 = Camera_SetHeight
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Camera_SetTargetPosition
  L13_189 = -13.55
  L14_190 = 0.2
  L15_191 = 8.85
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Camera_SetFov
  L13_189 = 21.5
  L12_188(L13_189)
  L12_188 = Npc_SetRotateY
  L13_189 = 1
  L14_190 = -60
  L12_188(L13_189, L14_190)
  L12_188 = Npc_SetRotateY
  L13_189 = 5
  L14_190 = -50
  L12_188(L13_189, L14_190)
  L12_188 = Npc_SetRotateY
  L13_189 = 6
  L14_190 = -40
  L12_188(L13_189, L14_190)
  L12_188 = Npc_SetMotion
  L13_189 = 4
  L14_190 = 0
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetEventBGM
  L13_189 = -1
  L12_188(L13_189)
  L12_188 = Npc_SetFace
  L13_189 = 7
  L14_190 = 1
  L15_191 = 0
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = fc_SetMotionEX
  L13_189 = 7
  L14_190 = 16777350
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_504"
  L14_190 = "[TALK ???]\231\167\129\227\129\159\227\129\161\227\129\171\229\175\190\230\138\151\227\129\153\227\130\139\227\129\160\227\129\168\226\128\166\226\128\166?\n\227\131\149\227\128\129\227\131\149\227\131\149\226\128\166\226\128\166\227\128\129\233\157\162\231\153\189\227\129\132\226\128\166\226\128\166"
  L12_188(L13_189, L14_190)
  L12_188 = Message_WindowClose
  L12_188()
  L12_188 = Message_Clear
  L12_188()
  L12_188 = Wait_MessageWindow
  L12_188()
  L12_188 = SetEventBGM
  L13_189 = 8
  L12_188(L13_189)
  L12_188 = Camera_SetFov
  L13_189 = 15.5
  L14_190 = 0.5
  L12_188(L13_189, L14_190)
  L12_188 = Npc_SetFace
  L13_189 = 7
  L14_190 = 2
  L15_191 = 4
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = fc_SetMotionEX
  L13_189 = 7
  L14_190 = 16777229
  L15_191 = 0
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 7
  L14_190 = 0
  L15_191 = 0.3
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Message_WindowOpen
  L12_188()
  L12_188 = Wait_MessageWindow
  L12_188()
  L12_188 = SetMes
  L13_189 = "MES_505"
  L14_190 = "[TALK ???]\227\129\132\227\129\132\230\176\151\227\129\171\227\129\170\227\130\139\227\129\170\227\130\136\229\176\143\229\168\152\227\129\169\227\130\130\227\129\140\227\130\161!\n\228\187\138\227\129\139\227\130\137\228\189\147\227\129\171\230\149\153\227\129\136\227\129\166\227\130\132\227\130\139\227\130\136!"
  L12_188(L13_189, L14_190)
  L12_188 = Wait_Timer
  L13_189 = 0.5
  L12_188(L13_189)
  L12_188 = Camera_StartShake
  L13_189 = 0.2
  L14_190 = 1
  L15_191 = 1
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = fc_SetMotionEX
  L13_189 = 7
  L14_190 = 16777266
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 7
  L14_190 = 16777267
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_505_00"
  L14_190 = "[TALK ???]\227\129\130\227\129\170\227\129\159\227\129\159\227\129\161\227\129\140\230\157\159\227\129\171\227\129\170\227\129\163\227\129\166\227\129\139\227\129\139\227\129\163\227\129\166\227\129\141\227\129\166\227\130\130\227\128\129\n\227\129\147\227\129\174\231\167\129\227\129\171\227\129\175\229\139\157\227\129\166\227\129\170\227\129\132\227\129\163\227\129\166\227\129\147\227\129\168\227\130\146\227\129\173\227\130\167\227\131\131!"
  L12_188(L13_189, L14_190)
  L12_188 = Camera_SetRotate
  L13_189 = 341
  L12_188(L13_189)
  L12_188 = Camera_SetHeight
  L13_189 = 2
  L12_188(L13_189)
  L12_188 = Camera_SetTargetPosition
  L13_189 = -6.68
  L14_190 = 0.48
  L15_191 = 10.78
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Camera_SetFov
  L13_189 = 20.5
  L12_188(L13_189)
  L12_188 = Npc_ShowPopupIcon
  L13_189 = 5
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = fc_SetMotionEX
  L13_189 = 5
  L14_190 = 16777276
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 5
  L14_190 = 16777277
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_506"
  L14_190 = "[TALK \227\131\159\227\131\171\227\131\146]\227\129\155\227\128\129\230\128\167\230\160\188\227\129\140\228\184\128\229\164\137\227\129\151\227\129\190\227\129\151\227\129\159\227\129\173!?"
  L12_188(L13_189, L14_190)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 5
  L12_188(L13_189)
  L12_188 = Npc_SetMotion
  L13_189 = 7
  L14_190 = 0
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_SetWeaponVisible
  L13_189 = 6
  L14_190 = true
  L12_188(L13_189, L14_190)
  L12_188 = fc_SetMotionEX
  L13_189 = 6
  L14_190 = 16777229
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 6
  L14_190 = 16777219
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = SetMes
  L13_189 = "MES_507"
  L14_190 = "[TALK \227\129\170\227\129\174\227\129\175]\227\130\143\227\129\159\227\129\151\227\129\159\227\129\161\227\129\160\227\129\163\227\129\166\227\128\129\n\228\187\150\228\186\186\227\130\146\229\155\176\227\130\137\227\129\155\227\129\166\229\150\156\227\129\182\227\130\136\227\129\134\227\129\170\228\186\186\227\129\170\227\130\147\227\129\139\227\129\171\227\128\129\n\231\181\182\229\175\190\227\129\171\232\178\160\227\129\145\227\129\170\227\129\132!"
  L12_188(L13_189, L14_190)
  L12_188 = Message_WindowClose
  L12_188()
  L12_188 = Message_Clear
  L12_188()
  L12_188 = Wait_MessageWindow
  L12_188()
  L12_188 = fc_SetMotionEX
  L13_189 = 5
  L14_190 = 16777335
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = fc_SetMotionEX
  L13_189 = 4
  L14_190 = 16777335
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = fc_SetMotionEX
  L13_189 = 3
  L14_190 = 16777335
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 5
  L14_190 = 16777336
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 4
  L14_190 = 16777336
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 3
  L14_190 = 16777336
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = PlaySE
  L13_189 = 33554437
  L12_188(L13_189)
  L12_188 = Npc_SetWeaponVisible
  L13_189 = 1
  L14_190 = true
  L12_188(L13_189, L14_190)
  L12_188 = fc_SetMotionEX
  L13_189 = 1
  L14_190 = 16777227
  L15_191 = 0.2
  L16_192 = false
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Npc_RequestMotion
  L13_189 = 1
  L14_190 = 16777217
  L15_191 = 0.2
  L16_192 = true
  L12_188(L13_189, L14_190, L15_191, L16_192)
  L12_188 = Wait_Timer
  L13_189 = 1.5
  L12_188(L13_189)
  L12_188 = SetEventBGM
  L13_189 = -1
  L12_188(L13_189)
  L12_188 = Npc_SetFace
  L13_189 = 7
  L14_190 = 0
  L15_191 = 0
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Message_WindowOpen
  L12_188()
  L12_188 = Wait_MessageWindow
  L12_188()
  L12_188 = SetMes
  L13_189 = "MES_508"
  L14_190 = "[TALK \227\131\141\227\130\172\227\130\175\227\131\169\227\130\164]\227\129\157\227\129\147\227\129\190\227\129\167\227\129\160\227\128\130"
  L12_188(L13_189, L14_190)
  L12_188 = Message_WindowClose
  L12_188()
  L12_188 = Message_Clear
  L12_188()
  L12_188 = Wait_MessageWindow
  L12_188()
  L12_188 = Npc_ShowPopupIcon
  L13_189 = 1
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 5
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 6
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 4
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 3
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Npc_ShowPopupIconSilent
  L13_189 = 7
  L14_190 = 0
  L12_188(L13_189, L14_190)
  L12_188 = Wait_Timer
  L13_189 = 0.5
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 5
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 6
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 4
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 3
  L12_188(L13_189)
  L12_188 = Npc_HidePopupIcon
  L13_189 = 7
  L12_188(L13_189)
  L12_188 = Wait_Timer
  L13_189 = 0.5
  L12_188(L13_189)
  L12_188 = Camera_SetRotate
  L13_189 = 71
  L12_188(L13_189)
  L12_188 = Camera_SetHeight
  L13_189 = 1
  L12_188(L13_189)
  L12_188 = Camera_SetTargetPosition
  L13_189 = -13.56
  L14_190 = 0.2
  L15_191 = 9.41
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Camera_SetFov
  L13_189 = 21.5
  L12_188(L13_189)
  L12_188 = Wait_Timer
  L13_189 = 0.5
  L12_188(L13_189)
  L12_188 = Particle_Create
  L13_189 = 0
  L14_190 = 11
  L15_191 = 0
  L12_188(L13_189, L14_190, L15_191)
  L12_188 = Npc_GetPosition
  L13_189 = 2
  L14_190 = L12_188(L13_189)
  L15_191 = Particle_SetPosition
  L16_192 = 0
  L17_193 = L12_188
  L15_191(L16_192, L17_193, L13_189, L14_190)
  L15_191 = PlaySE
  L16_192 = 33554443
  L15_191(L16_192)
  L15_191 = FadeOut
  L16_192 = 4
  L17_193 = 1
  L15_191(L16_192, L17_193, 1, 1)
  L15_191 = Wait_Fade
  L15_191()
  L15_191 = Wait_Timer
  L16_192 = 0.1
  L15_191(L16_192)
  L15_191 = Npc_SetVisible
  L16_192 = 2
  L17_193 = true
  L15_191(L16_192, L17_193)
  L15_191 = Npc_SetFace
  L16_192 = 2
  L17_193 = 1
  L15_191(L16_192, L17_193, 1)
  L15_191 = fc_SetMotionEX
  L16_192 = 2
  L17_193 = 16777314
  L15_191(L16_192, L17_193, 0.2, true)
  L15_191 = FadeIn
  L16_192 = 4
  L15_191(L16_192)
  L15_191 = Wait_Fade
  L15_191()
  L15_191 = Wait_Timer
  L16_192 = 0.5
  L15_191(L16_192)
  L15_191 = Npc_SetInterRotateY
  L16_192 = 7
  L17_193 = 30
  L15_191(L16_192, L17_193, 10)
  L15_191 = Wait_NpcRotate
  L16_192 = 7
  L15_191(L16_192)
  L15_191 = fc_SetMotionEX
  L16_192 = 7
  L17_193 = 16777431
  L15_191(L16_192, L17_193, 0.2, true)
  L15_191 = Wait_Timer
  L16_192 = 2
  L15_191(L16_192)
  L15_191 = Camera_SetTargetPosition
  L16_192 = -13.74
  L17_193 = -0.64
  L15_191(L16_192, L17_193, 9.93)
  L15_191 = Camera_SetFov
  L16_192 = 12.5
  L15_191(L16_192)
  L15_191 = Wait_Timer
  L16_192 = 0.5
  L15_191(L16_192)
  L15_191 = Camera_SetMode
  L16_192 = 3
  L15_191(L16_192)
  L15_191 = Camera_SetMoveSpeed
  L16_192 = 0.8
  L15_191(L16_192)
  L15_191 = Camera_SetMovePoints
  L16_192 = -13.74
  L17_193 = -0.64
  L15_191(L16_192, L17_193, 9.93, -13.74, 0.76, 9.93)
  L15_191 = Wait_Timer
  L16_192 = 1
  L15_191(L16_192)
  L15_191 = Npc_SetFace
  L16_192 = 2
  L17_193 = 2
  L15_191(L16_192, L17_193, 1)
  L15_191 = Wait_CameraMove
  L15_191()
  L15_191 = Wait_Timer
  L16_192 = 2
  L15_191(L16_192)
  L15_191 = FadeOut
  L16_192 = 16
  L15_191(L16_192)
  L15_191 = Wait_Fade
  L15_191()
  L15_191 = Map_SetTalk
  L16_192 = "script/main_scenario/ch04_NendoWorld_main10/talk_03.lbn"
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 3
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 4
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 5
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 6
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 2
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 1
  L15_191(L16_192)
  L15_191 = Npc_Delete
  L16_192 = 7
  L15_191(L16_192)
  L15_191 = Npc_SetVisible
  L16_192 = 0
  L17_193 = true
  L15_191(L16_192, L17_193)
  L15_191 = Npc_SetPosition
  L16_192 = 0
  L17_193 = -11.9
  L15_191(L16_192, L17_193, 0, 4.72)
  L15_191 = Npc_SetRotateY
  L16_192 = 0
  L17_193 = 0
  L15_191(L16_192, L17_193)
  L15_191 = Camera_SetRotate
  L16_192 = 3
  L15_191(L16_192)
  L15_191 = Camera_SetHeight
  L16_192 = 3
  L15_191(L16_192)
  L15_191 = Camera_SetTargetPosition
  L16_192 = -11.82
  L17_193 = 0.9
  L15_191(L16_192, L17_193, 6.26)
  L15_191 = Camera_SetFov
  L16_192 = 11.5
  L15_191(L16_192)
  L15_191 = FadeIn
  L16_192 = 16
  L15_191(L16_192)
  L15_191 = Wait_Fade
  L15_191()
  L15_191 = Npc_ShowPopupIconSilent
  L16_192 = 0
  L17_193 = 4
  L15_191(L16_192, L17_193)
  L15_191 = fc_SetMotionEX
  L16_192 = 0
  L17_193 = 8
  L15_191(L16_192, L17_193, 0.2, false)
  L15_191 = Npc_RequestMotion
  L16_192 = 0
  L17_193 = 0
  L15_191(L16_192, L17_193, 0.2, true)
  L15_191 = PlaySE
  L16_192 = 33554465
  L15_191(L16_192)
  L15_191 = Message_WindowOpen
  L16_192 = 1
  L15_191(L16_192)
  L15_191 = Wait_MessageWindow
  L15_191()
  L15_191 = SetMes
  L16_192 = "MES_509"
  L17_193 = "[COL SYS_CHR]\227\131\135\227\131\131\227\131\137\227\131\158\227\130\185\227\130\191\227\131\188[COL SYS_DEF]\227\129\140\228\187\178\233\150\147\227\129\171\227\129\170\227\129\163\227\129\159!"
  L15_191(L16_192, L17_193)
  L15_191 = Message_WindowClose
  L15_191()
  L15_191 = Message_Clear
  L15_191()
  L15_191 = Wait_MessageWindow
  L15_191()
  L15_191 = Npc_HidePopupIcon
  L16_192 = 0
  L15_191(L16_192)
  L15_191 = FadeOut
  L16_192 = 16
  L15_191(L16_192)
  L15_191 = Wait_Fade
  L15_191()
  L15_191 = Npc_Delete
  L16_192 = 0
  L15_191(L16_192)
  L15_191 = AddPartyMember
  L16_192 = 2
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 16
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 3
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 4
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 8
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 15
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 12
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = AddPartyMember
  L16_192 = 19
  L17_193 = false
  L15_191(L16_192, L17_193, false)
  L15_191 = Wait_Load
  L15_191()
  L15_191 = Camera_MapRestore
  L15_191()
  L15_191 = Camera_SetMode
  L16_192 = 0
  L15_191(L16_192)
  L15_191 = Player_SetPosition
  L16_192 = -7.01
  L17_193 = 0
  L15_191(L16_192, L17_193, 10.33)
  L15_191 = Player_SetRotateY
  L16_192 = -45
  L15_191(L16_192)
  L15_191 = Player_SetVisible
  L16_192 = true
  L15_191(L16_192)
  L15_191 = FadeIn
  L16_192 = 16
  L15_191(L16_192)
  L15_191 = Wait_Fade
  L15_191()
  L15_191 = OnLocalFlag
  L16_192 = 0
  L15_191(L16_192)
end
